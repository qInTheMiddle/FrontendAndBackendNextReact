#!/bin/bash

set -x

rm -rf temp-dist/
./node_modules/.bin/tsc --project ./tsconfig.non.incremental.json --outDir ./temp-dist
rm -rf ./dist
mv ./temp-dist ./dist