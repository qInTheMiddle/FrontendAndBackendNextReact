import Bluebird from 'bluebird';
import { NODE_ENV, PORT } from '@helpers/env.js';
import express from 'express';
import reportError from '@helpers/report.error.js';
import * as CRON_STATE from '@helpers/cron.state.js';
import init from './initialize/index.js';

Bluebird.config({ longStackTraces: true });

const app = express();
init(app);

// do not use process.on('unhandledRejection', reportError);
// because it will pass the rejected promise as the second parameter
// which will cause reportError itself to throw an error
process.on('unhandledRejection', (err) => {
  reportError(err, null, null);
});

const port = convertPortToInt(PORT);
const server = app.listen(port, () => {
  console.log(`Inboard is running ${NODE_ENV.toUpperCase()} on port ${port}!`);
  process.send?.('ready');
});

process.on('SIGINT', async () => {
  console.log(`Killing app on port ${port}`);

  await CRON_STATE.close();

  server.close(async () => {
    await Bluebird.delay(5000);
    console.log(`Killed app on port ${port} successfully. Bye!`);
    process.exit(0);
  });
});

function convertPortToInt (PORT: string) {
  return Number.parseInt(PORT, 10);
}