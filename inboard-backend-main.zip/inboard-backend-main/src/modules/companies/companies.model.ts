import mongoose from 'mongoose';
import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;
import { ICompany } from '@modules/companies/index.js';
import { CounterFor, CounterPrefix } from '@modules/counters/index.js';
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';

const companiesSchema = new Schema<ICompany>({
  createdByUserId: { type: Schema.Types.ObjectId, ref: Model.USER, required: true },

  name: { type: String, required: true, unique: true },
  slug: { type: String, required: true, unique: true },
  logo: { type: String },
  location: { type: String },
  website: { type: String },
  email: { type: String },
  phone: { type: String },
  description: {
    arabic: { type: String },
    english: { type: String }
  },
  size: { type: String },
  activatedAt: { type: Date },
  isActive: { type: Boolean },
  isDeleted: { type: Boolean, default: false }
});

companiesSchema.index({ name: 'text' });
companiesSchema.index({ slug: -1 });

injectCustomIdCreator({ schema: companiesSchema, documentName: CounterFor.COMPANY, prefix: CounterPrefix.COMPANY });

export default mongoose.model<ICompany>(Model.COMPANY, companiesSchema);