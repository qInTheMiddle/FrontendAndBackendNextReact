import Application, { ApplicationStatus } from '@modules/applications/index.js';
import CONSTANTS from '@helpers/constants.js';
import sendEmail from '@helpers/send.email.js';

async function sendApplicantEmail ({ applicationId }) {
  const application = await Application.dal.findOne({
    filter: { _id: applicationId },
    select: 'status opportunityId userId rejectionReason',
    populate: [
      { path: 'userId', select: 'firstName lastName email' },
      { path: 'opportunityId', select: 'companyName title' }
    ],
    lean: true
  });
  if (!application) {
    throw new Error(`Application ${applicationId} Not Found.`);
  }

  const user = application.userId;
  const opportunity = application.opportunityId;

  const { subject, templateId } = getEmailSubjectAndTemplateId({ status: application.status });

  if (subject && templateId) {
    await sendEmail({
      from: 'Hello Inboard<hello@inboard.sa>',
      to: user.email,
      subject,
      templateId,
      dynamicTemplateData: {
        applicationId: application._id,
        companyName: opportunity.companyName,
        opportunityTitle: opportunity.title,
        userFullName: `${user.firstName} ${user.lastName}`,
        rejectionReason: application.rejectionReason || ''
      }
    });
  }
}

export default sendApplicantEmail;

function getEmailSubjectAndTemplateId ({ status }) {
  switch (status) {
    case ApplicationStatus.AWAITING_INBOARD_INVERVIEW:
      return { subject: 'Inboard Team Interview', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.teamInterview };
    case ApplicationStatus.AWAITING_OPPORTUNITY_INVERVIEW:
      return { subject: 'Inboard Opportunity Interview', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.opportunityInterview };
    case ApplicationStatus.ACCEPTED:
      return { subject: 'Inboard Opportunity Accepted', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.applicationAccepted };
    case ApplicationStatus.REJECTED:
      return { subject: 'Inboard Opportunity Rejected', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.applicationRejected };
    default:
      return { subject: null, templateId: null };
  }
}