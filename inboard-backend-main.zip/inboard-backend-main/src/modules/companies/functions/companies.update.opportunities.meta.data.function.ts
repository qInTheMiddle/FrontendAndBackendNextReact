import Opportunity, { IOpportunity } from '@modules/opportunities/index.js';
import { UpdateQuery } from 'mongoose';
import Application, { IApplication, ApplicationStatus, APPLICATION_STATUS_ORDER } from '@modules/applications/index.js';

async function updateApplicationStatus ({ applicationId, status, rejectionReason }: IUpdateApplicationStatusParams) {
  const application = await Application.dal.findOne({
    filter: { _id: applicationId },
    select: 'status opportunityId userId',
    lean: true
  });
  if (!application) {
    return { statusCode: 404, message: 'Application Not Found.' };
  }

  const currentApplicationStatusOrder = APPLICATION_STATUS_ORDER[application.status];
  const desiredApplicationStatusOrder = APPLICATION_STATUS_ORDER[status];
  const isNextStatusValid = currentApplicationStatusOrder + 1 === desiredApplicationStatusOrder;

  if (status !== ApplicationStatus.REJECTED && !isNextStatusValid) {
    return { statusCode: 400, message: 'Invalid application status.' };
  }

  const applicationUpdate = getApplicationUpdate({ status, rejectionReason });
  await Application.dal.updateOne({
    filter: { _id: application._id },
    update: applicationUpdate
  });

  await updateOpportynityCounts({ opportunityId: application.opportunityId, status });

  return { statusCode: 204 };
}

export default updateApplicationStatus;

function getApplicationUpdate ({ status, rejectionReason }) {
  const applicationUpdate: UpdateQuery<IApplication> = { status };
  if (status === ApplicationStatus.ACCEPTED) {
    applicationUpdate.acceptedAt = new Date();
  }
  if (status === ApplicationStatus.REJECTED) {
    applicationUpdate.rejectedAt = new Date();
    applicationUpdate.rejectionReason = rejectionReason;
  }

  return applicationUpdate;
}

async function updateOpportynityCounts ({ opportunityId, status }) {
  const update: UpdateQuery<IOpportunity> = {};
  if (status !== ApplicationStatus.REJECTED && status !== ApplicationStatus.ACCEPTED) {
    return;
  }

  if (status === ApplicationStatus.ACCEPTED) {
    update.$inc = { acceptedCount: 1 };
  }
  if (status === ApplicationStatus.REJECTED) {
    update.$inc = { rejectedCount: 1 };
  }

  return await Opportunity.dal.updateOne({
    filter: { _id: opportunityId },
    update
  });
}

interface IUpdateApplicationStatusParams {
  applicationId: IApplication['_id'];
  status: IApplication['status'];
  rejectionReason?: IApplication['rejectionReason']
}