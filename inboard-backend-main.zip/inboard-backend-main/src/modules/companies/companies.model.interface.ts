import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';
import { IUser } from '@modules/users/index.js';
import { CounterPrefix } from '@modules/counters/index.js';

export interface ICompany<Populate = true> extends IMongo {

  createdByUserId: PopulatedDoc<IUser, Populate>;
  name: string;
  logo: string;
  location: string;
  website: string;
  email: string;
  phone: string;
  description: {
    arabic: string;
    english: string;
  };
  size: string;
  activatedAt: Date;
  isDeleted: boolean;
  isActive: boolean;
  customId: `${CounterPrefix.COMPANY}${number}`;
  slug: string;
}