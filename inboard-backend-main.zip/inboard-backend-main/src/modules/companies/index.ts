export * from './companies.model.interface.js';

import Model from './companies.model.js';
import DAL from '@helpers/dal.js';

const dal = new DAL(Model);

import updateOpportunitiesMetaData from './functions/companies.update.opportunities.meta.data.function.js';
import deactivateOpportunities from './functions/companies.deactivate.opportunities.function.js';

export default {
  Model,
  dal,

  updateOpportunitiesMetaData,
  deactivateOpportunities
};