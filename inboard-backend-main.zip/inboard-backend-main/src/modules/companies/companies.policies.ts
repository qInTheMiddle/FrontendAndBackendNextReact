import teamPolicies from './team/companies.team.policy.js';
import companiesPolicies from './company/companies.company.policy.js';

export default function invokeRolesPolicies (acl) {
  teamPolicies(acl);
  companiesPolicies(acl);
}