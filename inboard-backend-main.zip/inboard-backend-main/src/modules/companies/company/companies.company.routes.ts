import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.post('/api/company/companies/add/', isAllowed, jsonParser, makeCallback(controllers.add));
  app.get('/api/company/companies/view/', isAllowed, makeCallback(controllers.view));
  app.put('/api/company/companies/:companyId/update/', isAllowed, jsonParser, makeCallback(controllers.update));
}