export { default as view } from './companies.company.view.controller.js';
export { default as add } from './companies.company.add.controller.js';
export { default as update } from './companies.company.update.controller.js';