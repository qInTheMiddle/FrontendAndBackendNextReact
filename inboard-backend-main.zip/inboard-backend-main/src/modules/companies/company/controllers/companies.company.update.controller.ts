import { Request, Response } from 'express';
import slugify from 'slugify';
import Company from '@modules/companies/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    companyId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    company: Joi.object().required().keys({
      name: Joi.string().required(),
      logo: Joi.string(),
      location: Joi.string(),
      website: Joi.string(),
      email: Joi.string(),
      phone: Joi.string(),
      size: Joi.string(),
      description: Joi.object().required().keys({
        arabic: Joi.string().required(),
        english: Joi.string()
      }),
      isActive: Joi.boolean()
    })
  })
};

export default async (req: Request, res: Response) => {
  const { params, body } = validateRequest(req, validationSchema, { warn: true });

  const currentCompany = await Company.dal.findOne({
    filter: { _id: params.companyId },
    lean: true
  });

  if (currentCompany.name !== body.company.name) {
    body.company.slug = await generateSlug(body.company.name);
  }

  const updateResult = await Company.dal.updateOne({
    filter: { _id: params.companyId },
    update: body.company
  });

  if (!updateResult.modifiedCount) {
    return res.status(404).json({ message: 'company Not Found.' });
  }


  return res.status(204).json();
};

async function generateSlug (name: string) {

  const slug = slugify(name);

  const matchingSlugs = await Company.Model.countDocuments({ slug: new RegExp(`^${slug}`) });
  if (matchingSlugs) {
    return `${slug}-${matchingSlugs + 1}`;
  }

  return `${slug}`;
}