import User from '@modules/users/index.js';
import { Request, Response } from 'express';
import Company from '@modules/companies/index.js';


export default async (req: Request, res: Response) => {
  const { companyId } = req.user;

  const company = await Company.dal.findOne({
    filter: { _id: companyId },
    lean: true
  });

  if (!company) {
    return res.status(404).json({ message: 'Company Not Found.' });
  }

  const users = await User.dal.find({
    filter: { companyId },
    select: 'firstName lastName email',
    lean: true
  });

  return res.status(200).json({ company, users });
};