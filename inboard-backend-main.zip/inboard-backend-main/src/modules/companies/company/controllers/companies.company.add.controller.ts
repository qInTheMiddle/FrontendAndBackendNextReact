import Company from '@modules/companies/index.js';
import User from '@modules/users/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
import slugify from 'slugify';

const validationSchema = {
  body: Joi.object().required().keys({
    company: Joi.object().required().keys({
      name: Joi.string().required(),
      logo: Joi.string(),
      location: Joi.string(),
      website: Joi.string(),
      email: Joi.string(),
      phone: Joi.string(),
      size: Joi.string(),
      description: Joi.object().required().keys({
        arabic: Joi.string().required(),
        english: Joi.string()
      }),
      isActive: Joi.boolean()
    })
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });

  const user = await User.dal.findOne({
    filter: { _id: req.user._id },
    select: 'companyId',
    lean: true
  });

  const companyExists = await Company.dal.exists({ filter: { _id: user.companyId } });
  if (companyExists) {
    return res.status(400).json({ message: 'Company already exists for user.' });
  }

  const slug = await generateSlug(body.company.name);
  body.company.slug = slug;
  body.company.createdByUserId = req.user._id;

  const company = await Company.dal.create(body.company);

  await User.dal.updateOne({
    filter: { _id: req.user._id },
    update: { companyId: company._id }
  });

  return res.status(201).json({ companyId: company._id });
};

async function generateSlug (name: string) {

  const slug = slugify(name);

  const matchingSlugs = await Company.Model.countDocuments({ slug: new RegExp(`^${slug}`) });
  if (matchingSlugs) {
    return `${slug}-${matchingSlugs + 1}`;
  }

  return `${slug}`;
}