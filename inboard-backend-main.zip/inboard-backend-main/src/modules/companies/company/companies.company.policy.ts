export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['company-employee'],
    allows: [
      { resources: '/api/company/companies/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/company/companies/add/', permissions: 'post' },
      { resources: '/api/company/companies/view/', permissions: 'get' },
      { resources: '/api/company/companies/:companyId/update/', permissions: 'put' }
    ]
  }]);
}