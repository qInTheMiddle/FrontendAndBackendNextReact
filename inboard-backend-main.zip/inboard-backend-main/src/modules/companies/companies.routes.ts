import { Application } from 'express';
import teamRoutes from './team/companies.team.routes.js';
import companiesRoutes from './company/companies.company.routes.js';

export default function (app: Application) {
  teamRoutes(app);
  companiesRoutes(app);
}