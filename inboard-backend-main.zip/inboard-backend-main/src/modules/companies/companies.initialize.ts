import { Application } from 'express';
import { Acl } from 'acl';
import routes from './companies.routes.js';
import policies from './companies.policies.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}