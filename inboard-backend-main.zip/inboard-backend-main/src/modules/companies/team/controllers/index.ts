export { default as list } from './companies.team.list.controller.js';
export { default as view } from './companies.team.view.controller.js';
export { default as add } from './companies.team.add.controller.js';
export { default as update } from './companies.team.update.controller.js';
export { default as activate } from './companies.team.activate.controller.js';
export { default as deactivate } from './companies.team.deactivate.controller.js';