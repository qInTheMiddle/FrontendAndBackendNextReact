import { Request, Response } from 'express';
import Company from '@modules/companies/index.js';
import calculatePagesCount from '@helpers/calculate.pages.count.js';

export default async (req: Request, res: Response) => {
  const sortBy = req.params.sortBy || '-createdAt';
  const limit = Math.min(Number(req.params.limit) || 30, 100);
  const currentPage = parseInt(req.params.page) || 1;
  const { keyword } = req.query;

  const filter = {};
  if (keyword) {
    filter['$text'] = { $search: keyword };
  }

  const [companies, companiesCount] = await Promise.all([
    Company.dal.find({
      filter,
      sort: sortBy,
      populate: [
        { path: 'createdByUserId', select: 'firstName' }
      ],
      paginate: { documentsPerPage: limit, page: currentPage },
      lean: true
    }),
    Company.Model.countDocuments(req.query)
  ]);

  const pagesCount = calculatePagesCount({ documentsCount: companiesCount, documentsPerPage: limit });

  return res.status(200).json({
    companies,
    companiesCount,
    pagesCount
  });
};