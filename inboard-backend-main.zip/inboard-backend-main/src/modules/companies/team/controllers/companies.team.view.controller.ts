import { Request, Response } from 'express';
import Company from '@modules/companies/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    companyId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });

  const company = await Company.dal.findOne({
    filter: { _id: params.companyId },
    populate: [
      { path: 'createdByUserId', select: 'firstName' }
    ],
    lean: true
  });
  if (!company) {
    return res.status(404).json({ message: 'Company Not Found.' });
  }

  return res.status(200).json({ company });
};