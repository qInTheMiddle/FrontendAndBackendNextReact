import { Request, Response } from 'express';
import Company from '@modules/companies/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import User from '@modules/users/index.js';

const validationSchema = {
  params: Joi.object().required().keys({
    companyId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });

  const company = await Company.dal.findOne({
    filter: { _id: params.companyId },
    lean: true
  });

  if (!company) {
    return res.status(404).json({ message: 'company Not Found.' });
  }

  const updateResult = await Company.dal.updateOne({
    filter: { _id: params.companyId },
    update: { isActive: false, $unset: { activatedAt: 1 } }
  });

  if (!updateResult.modifiedCount) {
    return res.status(404).json({ message: 'company Not Found.' });
  }

  await User.dal.updateMany({
    filter: { companyId: params.companyId },
    update: { isActive: false }
  });


  return res.status(204).json();
};