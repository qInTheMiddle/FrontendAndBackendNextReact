export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/companies/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/team/companies/add/', permissions: 'post' },
      { resources: '/api/team/companies/:companyId/view/', permissions: 'get' },
      { resources: '/api/team/companies/:companyId/update/', permissions: 'put' },
      { resources: '/api/team/companies/:companyId/activate/', permissions: 'put' },
      { resources: '/api/team/companies/:companyId/deactivate/', permissions: 'put' }
    ]
  }]);
}