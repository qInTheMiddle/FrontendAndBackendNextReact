import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.get('/api/team/companies/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.post('/api/team/companies/add/', isAllowed, jsonParser, makeCallback(controllers.add));
  app.get('/api/team/companies/:companyId/view/', isAllowed, makeCallback(controllers.view));
  app.put('/api/team/companies/:companyId/update/', isAllowed, jsonParser, makeCallback(controllers.update));
  app.put('/api/team/companies/:companyId/activate/', isAllowed, makeCallback(controllers.activate));
  app.put('/api/team/companies/:companyId/deactivate/', isAllowed, makeCallback(controllers.deactivate));
}