import { PaymentMethod } from '@helpers/generic.types.js';
import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';
import { IApplication } from '@modules/applications/index.js';
import { CounterPrefix } from '@modules/counters/index.js';
import { IInvoice } from '@modules/invoices/index.js';
import { IPayment } from '@modules/payments/index.js';
import { IUser } from '@modules/users/index.js';

export interface ICreditNote<Populate = true> extends IMongo {
  customId: `${CounterPrefix.INVOICES}${number}`;

  userId: PopulatedDoc<IUser, Populate>;
  applicationId: PopulatedDoc<IApplication, Populate>;
  paymentId: PopulatedDoc<IPayment, Populate>;
  invoiceId: PopulatedDoc<IInvoice, Populate>;

  status: CreditNoteStatus;
  totalAmount: number;
  totalAmountWithoutVAT: number;
  VAT: number;
  vatPercentage: number,
  customer: {
    name: string;
    address: string;
    VATNumber?: string ;
    email?: string ;
    phone: string ;
  };

  items?: Array<{
    name: string;
    description: string;
    quantity: number;
    unitPrice: number;
    unitPriceWithoutVAT: number;
    VAT: number;
    totalAmount: number;
  }>;

  paidAmount?: number;
  paymentMethod: PaymentMethod;
  paidAt?: Date;

  refundedAt?: Date;
  issuedAt?: Date;

  QRCode?: string;

  creditNoteUrl?: string;
}

export enum CreditNoteStatus {
  OPEN = 'open',
  REFUNDED = 'refunded'
}