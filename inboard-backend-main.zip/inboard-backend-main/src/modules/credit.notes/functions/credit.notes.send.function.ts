import CreditNote from '@modules/credit.notes/index.js';
import { CustomError } from '@helpers/errors.js';
import sendEmail from '@helpers/send.email.js';
import { makeHttpRequest } from '@helpers/make.http.request.js';
import CONSTANTS from '@helpers/constants.js';

async function sendCreditNote ({ creditNoteId, email }) {
  const creditNote = await CreditNote.dal.findOne({
    filter: { _id: creditNoteId },
    lean: true
  });


  if (!email && !creditNote.customer.email) {
    throw new CustomError('Email is not provided.');
  }

  const emailData = {
    from: 'Hello Inboard<hello@inboard.sa>',
    to: email || creditNote.customer.email,
    subject: `اشعار دائن ${creditNote.customId}`,
    templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.creditNote,
    dynamicTemplateData: {
      creditNoteUrl: '',
      creditNoteId: creditNote.customId
    },
    attachments: [
      {
        content: '',
        filename: `credit-note-${creditNote.customId}.pdf`,
        type: 'application/pdf',
        disposition: 'attachment'
      }
    ]
  };

  if (!creditNote.creditNoteUrl) {
    throw new CustomError('Error generating creditNote');
  }
  const buffer = await makeHttpRequest({
    method: 'GET',
    url: creditNote.creditNoteUrl,
    responseType: 'buffer'
  });

  if (!buffer) {
    throw new CustomError('Error generating creditNote');
  }

  emailData.attachments[0].content = buffer.toString('base64');
  emailData.dynamicTemplateData.creditNoteUrl = creditNote.creditNoteUrl;

  await sendEmail(emailData);

  return { case: 1, message: 'Sent creditNotes successfully.' };
}

export default sendCreditNote;