import { Invoice } from '@axenda/zatca';
async function generateQRCode (creditNoteData) {
  const invoice = new Invoice(creditNoteData);
  const imageDate = await invoice.render();

  return imageDate;
}

export default generateQRCode;