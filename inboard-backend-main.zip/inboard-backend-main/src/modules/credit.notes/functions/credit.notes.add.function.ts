import CreditNote, { ICreditNote, CreditNoteStatus } from '@modules/credit.notes/index.js';
import { CustomError } from '@helpers/errors.js';
import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import moment from 'moment';

async function addCreditNote ({ invoiceId }) {
  const invoice = await Invoice.dal.findOne({
    filter: { _id: invoiceId },
    lean: true
  });

  if (!invoice) {
    throw new CustomError(`Invoice ${invoice} Not Found.`);
  }

  if (invoice.status !== InvoiceStatus.PAID) {
    throw new CustomError('Invoice is not paid.');
  }

  if (invoice.creditNoteId) {
    throw new CustomError('Invoice is already refunded.');
  }
  const issuedAt = new Date();
  const creditNote: Partial<ICreditNote> = {
    applicationId: invoice.applicationId,
    paymentId: invoice.paymentId,
    invoiceId: invoice._id,
    userId: invoice.userId,
    status: CreditNoteStatus.OPEN,
    totalAmount: invoice.totalAmount,
    totalAmountWithoutVAT: invoice.totalAmountWithoutVAT,
    VAT: invoice.VAT,
    vatPercentage: 15,
    customer: invoice.customer,
    items: invoice.items,
    paidAt: invoice.paidAt,
    paidAmount: invoice.paidAmount,
    issuedAt
  };



  const createCreditNote = await CreditNote.dal.create(creditNote);

  const QRCode = await CreditNote.generateQRCode({
    sellerName: 'شركة الخبرة المهنية لتقنية المعلومات',
    vatRegistrationNumber: '311364064300003',
    invoiceTimestamp: moment(issuedAt).format('YYYY-MM-DDTHH:mm:ss'),
    invoiceTotal: creditNote.totalAmount.toString(),
    invoiceVatTotal: creditNote.VAT.toString()
  });


  await CreditNote.dal.updateOne({
    filter: { _id: createCreditNote._id },
    update: { QRCode }
  });

  await Invoice.dal.updateOne({
    filter: { _id: invoiceId },
    update: { creditNoteId: createCreditNote._id, creditNotedAt: issuedAt, status: InvoiceStatus.REFUNDED }
  });

  return { case: 1, message: 'Created credit note successfully.', creditNote: createCreditNote };
}


export default addCreditNote;