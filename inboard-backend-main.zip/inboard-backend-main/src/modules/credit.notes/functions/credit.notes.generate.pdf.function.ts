import CreditNote from '@modules/credit.notes/index.js';
import { CreateOptions } from 'html-pdf';
import CONSTANTS from '@helpers/constants.js';
import htmlToPDFBuffer from '@helpers/html.to.pdf.buffer.js';
import uploadToS3 from '@helpers/upload.to.s3.js';
import moment from 'moment';

async function generatePDF ({ creditNoteId, app }) {
  const creditNote = await CreditNote.dal.findOne({
    filter: { _id: creditNoteId },
    lean: true
  });

  const creditNoteData: any = { ...creditNote };

  creditNoteData.totalAmount = creditNote.totalAmount.toFixed(2);

  creditNoteData.QRCode = creditNote.QRCode;
  creditNoteData.creditNotedAt = moment(creditNote.issuedAt).format('DD/MM/YYYY');



  const html = await app.renderAsync('creditnote', { creditNoteData, assets: CONSTANTS.ASSETS_DIRECTORY_PATH });
  const pdfOptions: CreateOptions = { format: 'A4', footer: { height: '32mm' }, header: { height: '10mm' } };

  const buffer = await htmlToPDFBuffer({ html, pdfOptions });

  const creditNoteUrl = await uploadToS3({
    destinationInBucket: `credit-notes/${creditNote.userId}/credit-note-${creditNote.status}-${creditNote.customId}.pdf`,
    body: buffer,
    acl: 'public-read',
    bucketName: CONSTANTS.S3_BUCKETS.INBOARD
  });



  await CreditNote.dal.updateOne({
    filter: { _id: creditNoteId },
    update: { creditNoteUrl }
  });


  return { case: 1, message: 'Created creditNotes successfully.', creditNoteUrl, buffer };
}


export default generatePDF;