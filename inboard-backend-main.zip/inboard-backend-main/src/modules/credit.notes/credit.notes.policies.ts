import teamPolicies from './team/credit.notes.team.policy.js';

export default function invokeRolesPolicies (acl) {
  teamPolicies(acl);
}