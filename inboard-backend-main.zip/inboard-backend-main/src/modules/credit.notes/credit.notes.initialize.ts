import { Application } from 'express';
import { Acl } from 'acl';
import routes from './credit.notes.routes.js';
import policies from './credit.notes.policies.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}