export * from './credit.notes.model.interface.js';

import DAL from '@helpers/dal.js';
import Model from './credit.notes.model.js';

const dal = new DAL(Model);

import { default as add } from './functions/credit.notes.add.function.js';
import { default as generateQRCode } from './functions/credit.notes.generate.qr.code.function.js';
import { default as generatePDF } from './functions/credit.notes.generate.pdf.function.js';
import { default as sendCreditNote } from './functions/credit.notes.send.function.js';

export default {
  Model,
  dal,
  add,
  generateQRCode,
  generatePDF,
  sendCreditNote
};