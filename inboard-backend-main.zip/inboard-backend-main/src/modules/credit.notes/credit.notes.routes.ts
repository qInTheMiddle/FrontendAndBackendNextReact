import { Application } from 'express';
import teamRoutes from './team/credit.notes.team.routes.js';

export default function (app: Application) {
  teamRoutes(app);
}