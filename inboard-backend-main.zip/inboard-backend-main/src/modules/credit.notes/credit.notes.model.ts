import { PaymentMethod } from '@helpers/generic.types.js';
import mongoose from 'mongoose';
import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';
import { ICreditNote, CreditNoteStatus } from '@modules/credit.notes/index.js';
import { CounterFor, CounterPrefix } from '@modules/counters/index.js';

const creditNotesSchema = new Schema<ICreditNote>({
  applicationId: { type: Schema.Types.ObjectId, ref: Model.APPLICATION, required: true },
  userId: { type: Schema.Types.ObjectId, ref: Model.USER, required: true },
  paymentId: { type: Schema.Types.ObjectId, ref: Model.PAYMENT },
  invoiceId: { type: Schema.Types.ObjectId, ref: Model.INVOICE },

  status: { type: String, required: true, default: CreditNoteStatus.OPEN, enum: Object.values(CreditNoteStatus) },

  totalAmount: { type: Number, min: 0, required: true },
  totalAmountWithoutVAT: { type: Number, min: 0, required: true },
  VAT: { type: Number, min: 0, required: true },
  vatPercentage: { type: Number, min: 0, required: true, default: 15 },
  customer: {
    name: { type: String, required: true },
    address: { type: String, required: true },
    VATNumber: { type: String },
    email: { type: String },
    phone: { type: String }
  },

  items: [{
    name: { type: String, required: true },
    description: { type: String, required: true },
    quantity: { type: Number, min: 0, required: true },
    unitPrice: { type: Number, min: 0, required: true },
    unitPriceWithoutVAT: { type: Number, min: 0, required: true },
    VAT: { type: Number, min: 0, required: true },
    totalAmount: { type: Number, min: 0, required: true }
  }],

  paidAt: Date,
  paidAmount: { type: Number, min: 0 },
  paymentMethod: { type: String, required: false, enum: Object.values(PaymentMethod) },

  refundedAt: Date,
  issuedAt: Date,

  QRCode: { type: String },

  creditNoteUrl: { type: String }
});

creditNotesSchema.index({ refundedAt: -1 });

injectCustomIdCreator({ schema: creditNotesSchema, documentName: CounterFor.CREDIT_NOTE, prefix: CounterPrefix.CREDIT_NOTE });

export default mongoose.model<ICreditNote>(Model.CREDIT_NOTE, creditNotesSchema);