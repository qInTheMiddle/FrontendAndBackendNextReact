import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import isAllowed from '@helpers/is.allowed.js';
import express, { Application } from 'express';
const jsonParser = express.json();

export default function (app: Application) {
  app.get('/api/team/credit-notes/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/team/credit-notes/:creditNoteId/view/', isAllowed, makeCallback(controllers.view));
  app.post('/api/team/credit-notes/:creditNoteId/send/', isAllowed, jsonParser, makeCallback(controllers.send));
}