import Joi from '@helpers/joi.js';
import { CustomError } from '@helpers/errors.js';
import Invoice from '@modules/invoices/index.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  params: Joi.object().required().keys({
    invoiceId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    email: Joi.string().email().allow(null, '').optional()
  })
};


export default async (req: Request, res: Response) => {
  const { params, body } = validateRequest(req, validationSchema, { warn: true });
  const { invoiceId } = params;
  const { email } = body;

  const invoice = await Invoice.sendInvoice({ invoiceId, email });

  if (!invoice.case) {
    throw new CustomError('Could not send invoice');
  }

  return res.json({ case: 1, message: 'Found invoice successfully.', invoice });
};