import Joi from '@helpers/joi.js';
import { CustomError } from '@helpers/errors.js';
import Invoice from '@modules/invoices/index.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  params: Joi.object().required().keys({
    invoiceId: Joi.mongoId().required()
  })
};


export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });
  const { invoiceId } = params;

  const filter = { _id: invoiceId };

  const fieldsToPopulate = getPopulateFields();

  const invoice = await Invoice.dal.findOne({
    filter,
    populate: fieldsToPopulate,
    lean: true
  });
  if (!invoice) {
    throw new CustomError('Invoice not found.');
  }

  return res.json({ case: 1, message: 'Found invoice successfully.', invoice });
};

function getPopulateFields () {
  return [
    { path: 'userId' },
    { path: 'applicationId' },
    { path: 'paymentId' }
  ];
}