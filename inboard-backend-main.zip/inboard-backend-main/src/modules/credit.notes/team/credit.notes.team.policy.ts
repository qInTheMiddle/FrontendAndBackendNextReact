export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/credit-notes/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/team/credit-notes/:creditNoteId/view/', permissions: 'get' },
      { resources: '/api/team/credit-notes/:creditNoteId/send/', permissions: 'post' }
    ]
  }]);
}