export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['applicant', 'agent', 'company-employee'],
    allows: [
      { resources: '/api/upload/', permissions: 'get' }
    ]
  }]);
}