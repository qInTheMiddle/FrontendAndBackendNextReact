import makeCallback from '@helpers/make.callback.js';
import uploader from './s3.upload.controller.js';
import { Application } from 'express';
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.get('/api/upload/', isAllowed, makeCallback(uploader));
}