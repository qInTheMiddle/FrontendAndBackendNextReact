import crypto from 'node:crypto';
import moment from 'moment';
import * as Objects from '@helpers/objects.js';
// This is the entry function that produces data for the frontend
// config is hash of S3 configuration:
// * bucket
// * region
// * accessKey
// * secretKey
function s3Credentials ({ config, params }) {
  return {
    endpoint_url: `https://${config.bucket}.s3.amazonaws.com/`,
    params: s3Params({ config, params })
  };
}

// Returns the parameters that must be passed to the API call
function s3Params ({ config, params }) {
  const credential = amzCredential({ config });
  const policy = s3UploadPolicy({ config, params, credential });
  const policyBase64 = Buffer.from(Objects.safeJSONStringify(policy)).toString('base64');
  const directory = params.directory.endsWith('/') ? params.directory.slice(0, -1) : params.directory;

  return {
    key: `${directory}/${params.filename}`,
    acl: 'public-read',
    success_action_status: '201',
    policy: policyBase64,
    'content-type': params.contentType,
    'x-amz-algorithm': 'AWS4-HMAC-SHA256',
    'x-amz-credential': credential,
    'x-amz-date': `${dateString()}T000000Z`,
    'x-amz-signature': s3UploadSignature({ config, policyBase64 })
  };
}

function dateString () {
  const date = moment().toISOString();
  return date.substr(0, 4) + date.substr(5, 2) + date.substr(8, 2);
}

function amzCredential ({ config }) {
  return [config.accessKey, dateString(), config.region, 's3/aws4_request'].join('/');
}

// Constructs the policy
function s3UploadPolicy ({ config, params, credential }) {
  const directory = params.directory.endsWith('/') ? params.directory.slice(0, -1) : params.directory;
  return {
    // 5 minutes into the future
    expiration: new Date((new Date).getTime() + (15 * 60 * 1000)).toISOString(),
    conditions: [
      { bucket: config.bucket },
      { key: `${directory}/${params.filename}` },
      { acl: 'public-read' },
      { success_action_status: '201' },
      // Optionally control content type and file size
      ['starts-with', '$key', `${directory}/${params.filename}`],
      ['content-length-range', 0, 20_971_520],
      { 'x-amz-algorithm': 'AWS4-HMAC-SHA256' },
      { 'x-amz-credential': credential },
      { 'x-amz-date': `${dateString()}T000000Z` }
    ]
  };
}

function hmac ({ key, string }) {
  const hmac = crypto.createHmac('sha256', key);
  hmac.end(string);
  return hmac.read();
}

// Signs the policy with the credential
function s3UploadSignature ({ config, policyBase64 }) {
  const dateKey = hmac({ key: `AWS4${config.secretKey}`, string: dateString() });
  const dateRegionKey = hmac({ key: dateKey, string: config.region });
  const dateRegionServiceKey = hmac({ key: dateRegionKey, string: 's3' });
  const signingKey = hmac({ key: dateRegionServiceKey, string: 'aws4_request' });

  return hmac({ key: signingKey, string: policyBase64 }).toString('hex');
}

export { s3Credentials };