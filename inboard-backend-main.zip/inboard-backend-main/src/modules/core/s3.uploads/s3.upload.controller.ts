import path from 'node:path';
import crypto from 'node:crypto';
import * as s3 from './s3.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  query: Joi.object().required().keys({
    filename: Joi.string().required(),
    directory: Joi.string().allow('', null)
  })
};

import { AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_DEFAULT_REGION, S3_BUCKET } from '@helpers/env.js';

const config = {
  accessKey: AWS_ACCESS_KEY_ID,
  secretKey: AWS_SECRET_ACCESS_KEY,
  region: AWS_DEFAULT_REGION,
  bucket: S3_BUCKET
};

export default function (req, res) {
  validateRequest(req, validationSchema, { warn: true });

  const { directory = 'applicant/' } = req.query;
  const filename = crypto.randomBytes(16).toString('hex') + path.extname(req.query.filename);
  const params = { filename, contentType: req.query.content_type, directory };

  return res.json(s3.s3Credentials({ config, params }));
}