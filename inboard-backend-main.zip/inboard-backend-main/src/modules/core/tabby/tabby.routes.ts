import makeCallback from '@helpers/make.callback.js';
import tabbyAuthorizer from './tabby.order.authorize.tabby.webhook.controller.js';
import express, { Application } from 'express';
const jsonParser = express.json();

export default function (app: Application) {
  app.post('/api/core/tabby', jsonParser, makeCallback(tabbyAuthorizer));
}