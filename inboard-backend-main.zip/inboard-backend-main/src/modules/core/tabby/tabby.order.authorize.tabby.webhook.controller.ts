import { Request, Response } from 'express';
import { TABBY_WEBHOOK_SECRET_KEY } from '@helpers/env.js';


export default (req: Request, res: Response) => {

  const tabbySecret = req.headers['x-tabby-secret-key'];

  if (tabbySecret !== TABBY_WEBHOOK_SECRET_KEY) {
    return res.sendStatus(200);
  }

  const { id, status, order } = req.body;
  console.log('id', id);
  console.log('status', status);
  console.log('order', order);
  if (status !== 'authorized' || !order?.reference_id) {
    return res.sendStatus(200);
  }



  return res.sendStatus(200);
};