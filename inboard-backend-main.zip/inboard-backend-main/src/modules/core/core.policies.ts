import coreS3UploadsPolicies from './s3.uploads/s3.uploads.policy.js';

export default function invokeRolesPolicies (acl) {
  coreS3UploadsPolicies(acl);
}