import { Application } from 'express';
import coreS3UploadsRoutes from './s3.uploads/s3.uploads.routes.js';
import tabbyRoutes from './tabby/tabby.routes.js';

export default function (app: Application) {
  coreS3UploadsRoutes(app);
  tabbyRoutes(app);
}