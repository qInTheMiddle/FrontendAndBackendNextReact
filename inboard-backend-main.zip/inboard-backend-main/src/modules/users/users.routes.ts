import { Application } from 'express';
import commonRoutes from './common/users.common.routes.js';
import applicantRoutes from './applicant/users.applicant.routes.js';
import teamRoutes from './team/users.team.routes.js';
import companyRoutes from './company/users.company.routes.js';

export default function (app: Application) {
  commonRoutes(app);
  applicantRoutes(app);
  teamRoutes(app);
  companyRoutes(app);
}