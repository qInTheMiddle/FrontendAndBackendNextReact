import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';

export interface IUser<Populate = true> extends IMongo {
  firstName: string;
  lastName: string;
  gender?: string;
  nationality?: string;
  dateOfBirth: Date;

  email: string;
  password: string;

  roles: UserRole;

  mobile?: string;
  mobileCC?: string;

  isEmailVerified?: boolean;

  isDeleted?: boolean;

  emailVerification?: {
    token?: string;
    expiresAt?: Date;
    sendCount?: number;
    blockExpiresAt?: Date;
  };

  resetPassword?: {
    token?: string;
    expiresAt?: Date;
    sendCount?: number;
    blockExpiresAt?: Date;
  };

  refreshTokens?: Array<{
    token: string;
    expiresAt: Date;
  }>;

  companyId?: PopulatedDoc<IUser, Populate>;
  userHMAC?: string;
}

export enum UserRole {
  APPLICANT = 'applicant',
  AGENT = 'agent',
  COMPANY_EMPLOYEE = 'company-employee',
}