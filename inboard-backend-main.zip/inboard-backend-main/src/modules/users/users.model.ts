import mongoose from 'mongoose';
import { IUser, UserRole } from '@modules/users/index.js';
import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;

const userSchema = new Schema<IUser>({
  companyId: { type: Schema.Types.ObjectId, ref: Model.COMPANY },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  gender: { type: String },
  nationality: { type: String },
  dateOfBirth: { type: Date },

  email: { type: String, required: true, lowercase: true },
  password: { type: String, required: true, trim: false },

  roles: [{ type: String, enum: UserRole }],

  mobile: { type: String },
  mobileCC: { type: String, default: '966' },

  isEmailVerified: Boolean,

  isDeleted: Boolean,

  emailVerification: {
    token: String,
    expiresAt: { type: Date, default: () => new Date() },
    sendCount: { type: Number, default: 0 },
    blockExpiresAt: { type: Date, default: () => new Date() }
  },

  resetPassword: {
    token: String,
    expiresAt: { type: Date, default: () => new Date() },
    sendCount: { type: Number, default: 0 },
    blockExpiresAt: { type: Date, default: () => new Date() }
  },

  refreshTokens: [{
    token: String,
    expiresAt: Date
  }]
});

userSchema.pre(/find/i, hideSensetiveData);

userSchema.index({ email: 1 }, { unique: true });

function hideSensetiveData () {
  const options = this.getOptions();
  const projection = this.projection();

  if (!projection && !options.exposeSensitiveData) {
    this.projection({
      password: 0,
      refreshTokens: 0,
      emailVerification: 0,
      resetPassword: 0
    });
  }
}



export default mongoose.model<IUser>(Model.USER, userSchema);