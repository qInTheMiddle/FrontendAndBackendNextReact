export * from './users.model.interface.js';
export * from './functions/users.get.access.token.payload.interface.js';

import bcrypt from 'bcrypt';


import Model from './users.model.js';
import DAL from '@helpers/dal.js';

const dal = new DAL(Model);

import getAccessTokenPayload from './functions/users.get.access.token.payload.function.js';
import generateTokens from './functions/users.generate.tokens.function.js';
import Random from '@helpers/random.js';

async function generateHash (password) {
  const salt = await bcrypt.genSalt(8);
  return await bcrypt.hash(password, salt, null);
}
async function isValidPassword ({ plainTextPassword, hashedPassword }) {
  ({ plainTextPassword, hashedPassword } = generateRandomPasswordsIfMissing({ plainTextPassword, hashedPassword }));

  return await bcrypt.compare(plainTextPassword, hashedPassword);
}

function generateRandomPasswordsIfMissing ({ plainTextPassword, hashedPassword }) {
  if (!plainTextPassword || !hashedPassword) {
    plainTextPassword = Random.uuid();
    hashedPassword = `${Random.uuid()}${plainTextPassword}`;
  }

  return { plainTextPassword, hashedPassword };
}

export default {
  Model,
  dal,

  getAccessTokenPayload,
  generateTokens,
  generateHash,
  isValidPassword
};