import commonPolicies from './common/users.common.policy.js';
import applicantPolicies from './applicant/users.applicant.policies.js';
import teamPolicies from './team/users.team.policies.js';
import companyPolicies from './company/users.company.policies.js';
export default function invokeRolesPolicies (acl) {
  commonPolicies(acl);
  applicantPolicies(acl);
  teamPolicies(acl);
  companyPolicies(acl);
}