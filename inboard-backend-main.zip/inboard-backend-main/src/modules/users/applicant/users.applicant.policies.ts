export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['applicant'],
    allows: [
      { resources: '/api/applicant/user/register/', permissions: 'post' },
      { resources: '/api/applicant/user/verify-email/', permissions: 'post' },
      { resources: '/api/applicant/user/resend-email-verification/', permissions: 'post' },
      { resources: '/api/applicant/user/login/', permissions: 'post' },
      { resources: '/api/applicant/user/view/', permissions: 'get' },
      { resources: '/api/applicant/user/update/', permissions: 'put' }
    ]
  }]);
}