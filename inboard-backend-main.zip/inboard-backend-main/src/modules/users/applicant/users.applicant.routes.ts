import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.post('/api/applicant/user/register/', jsonParser, makeCallback(controllers.register));
  app.post('/api/applicant/user/verify-email/', jsonParser, makeCallback(controllers.verifyEmail));
  app.post('/api/applicant/user/resend-email-verification/', jsonParser, makeCallback(controllers.resendEmailVerification));
  app.post('/api/applicant/user/login/', jsonParser, makeCallback(controllers.login));
  app.get('/api/applicant/user/view/', isAllowed, makeCallback(controllers.view));
  app.put('/api/applicant/user/update/', isAllowed, jsonParser, makeCallback(controllers.update));
  app.post('/api/applicant/user/forgot-password/', jsonParser, makeCallback(controllers.forgotPassword));
  app.post('/api/applicant/user/change-forgot-password/', jsonParser, makeCallback(controllers.changeForgotPassword));
}