import { Request, Response } from 'express';
import User from '@modules/users/index.js';
import crypto from 'node:crypto';
import { INTERCOM_HASH_SECRET } from '@helpers/env.js';

export default async (req: Request, res: Response) => {

  const user = await User.dal.findOne({
    filter: { _id: req.user._id },
    select: 'firstName lastName gender nationality dateOfBirth email mobile mobileCC',
    lean: true
  });
  const hmac = crypto.createHmac('sha256', INTERCOM_HASH_SECRET);

  user.userHMAC = hmac.update(user._id.toString()).digest('hex');

  return res.status(200).json({ user });
};