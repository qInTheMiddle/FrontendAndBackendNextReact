import { Request, Response } from 'express';
import User from '@modules/users/index.js';
import { CustomError } from '@helpers/errors.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    resetPasswordToken: Joi.string().required(),
    password: Joi.password().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });

  const user = await User.dal.findOne({
    filter: {
      'resetPassword.token': body.resetPasswordToken,
      'resetPassword.expiresAt': { $gt: new Date() }
    },
    lean: true
  });
  if (!user) {
    throw new CustomError('Password reset token has already expired.');
  }

  const newHashedPassword = await User.generateHash(body.password);
  await User.dal.updateOne({
    filter: { _id: user._id },
    update: {
      password: newHashedPassword,
      $unset: { resetPassword: true }
    }
  });

  return res.status(204).json();
};