import moment from 'moment';
import { Request, Response } from 'express';
import User, { UserRole } from '@modules/users/index.js';
import Random from '@helpers/random.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import CONSTANTS from '@helpers/constants.js';
import sendEmail from '@helpers/send.email.js';
const validationSchema = {
  body: Joi.object().required().keys({
    email: Joi.string().required().email().lowercase(),
    password: Joi.password().required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body: userToCreate } = validateRequest(req, validationSchema, { warn: true });

  const userExists = await User.dal.exists({ filter: { email: userToCreate.email } });
  if (userExists) {
    return res.status(409).json({ message: 'Email is already taken.' });
  }

  userToCreate.roles = [UserRole.APPLICANT];
  userToCreate.password = await User.generateHash(userToCreate.password);
  userToCreate['emailVerification.sendCount'] = 1,
  userToCreate['emailVerification.token'] = Random.uuid(),
  userToCreate['emailVerification.expiresAt'] = moment().add(2, 'hours').toDate(),
  userToCreate['emailVerification.blockExpiresAt'] = moment().add(10, 'minutes').toDate();

  const user = await User.dal.create(userToCreate);
  const userFullName = `${user.firstName} ${user.lastName}`;

  await sendEmail({
    from: 'Hello Inboard<hello@inboard.sa>',
    to: user.email,
    subject: 'Inboard Email Verification',
    templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.signupAndVerify,
    dynamicTemplateData: { emailVerificationToken: user.emailVerification.token, userFullName }
  });

  return res.status(201).json();
};