import { Request, Response } from 'express';
import User from '@modules/users/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    firstName: Joi.string(),
    lastName: Joi.string(),
    gender: Joi.string(),
    nationality: Joi.string(),
    dateOfBirth: Joi.date(),
    mobile: Joi.mobile(),
    mobileCC: Joi.string()
  })
};


export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });
  const userExists = await User.dal.exists({ filter: { _id: actingUser._id } });

  if (!userExists) {
    return res.status(404).json({ message: 'User not found.' });
  }

  await User.dal.updateOne({
    filter: { _id: actingUser._id },
    update: { ...body }
  });

  return res.status(204).json();
};