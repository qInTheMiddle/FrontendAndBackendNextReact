import { Request, Response } from 'express';
import User, { UserRole } from '@modules/users/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    email: Joi.string().required().email().lowercase(),
    password: Joi.notTrimmedString().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });

  const user = await User.dal.findOne({
    filter: { email: body.email, roles: { $in: UserRole.APPLICANT } },
    select: 'password isDeleted isEmailVerified',
    lean: true
  });

  const isValidPassword = await User.isValidPassword({ plainTextPassword: body.password, hashedPassword: user?.password });
  if (!isValidPassword) {
    return res.status(400).json({ message: 'Invalid email or password.' });
  }

  if (user.isDeleted) {
    return res.status(404).json({ message: 'Contact Support.' });
  }

  if (!user.isEmailVerified) {
    return res.status(400).json({ message: 'Please verify your email.' });
  }

  const { accessToken, refreshToken } = await User.generateTokens({ userId: user._id });

  return res.status(200).json({ accessToken, refreshToken });
};