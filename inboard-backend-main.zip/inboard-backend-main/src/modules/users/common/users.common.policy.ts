export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['applicant'],
    allows: [
      { resources: '/api/user/logout/', permissions: 'put' },
      { resources: '/api/user/change-password/', permissions: 'put' }
    ]
  }]);
}