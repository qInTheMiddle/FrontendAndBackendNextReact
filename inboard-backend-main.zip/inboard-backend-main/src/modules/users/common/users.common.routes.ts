import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.put('/api/user/logout/', isAllowed, jsonParser, makeCallback(controllers.logOut));
  app.put('/api/user/change-password/', isAllowed, jsonParser, makeCallback(controllers.changePasswordWithOldPassword));
}