import User from '@modules/users/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  body: Joi.object().required().keys({
    currentPassword: Joi.password().required(),
    newPassword: Joi.password().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { currentPassword, newPassword } = body;

  const user = await User.dal.findOne({
    filter: { _id: actingUser._id },
    select: 'password',
    lean: true
  });

  const isValidPassword = await User.isValidPassword({ plainTextPassword: currentPassword, hashedPassword: user?.password });

  if (!isValidPassword) {
    return res.status(400).json({ message: 'Incorrect email or password.' });
  }

  const hashedPassword = await User.generateHash(newPassword);

  await User.dal.updateOne({ filter: { _id: actingUser._id }, update: { password: hashedPassword } });

  return res.status(200).json({ message: 'Password changed successfully' });
};