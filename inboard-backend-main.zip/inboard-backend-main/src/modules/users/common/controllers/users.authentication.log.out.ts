import User from '@modules/users/index.js';
import { Request, Response } from 'express';

export default async (req: Request, res: Response) => {
  const refreshToken = req.header('refresh-token');

  await User.dal.updateOne({
    filter: { _id: req.user._id },
    update: {
      $pull: {
        refreshTokens: { token: refreshToken }
      }
    }
  });

  return res.status(204).json();
};