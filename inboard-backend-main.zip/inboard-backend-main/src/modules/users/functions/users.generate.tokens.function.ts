import jwt from 'jsonwebtoken';
import Random from '@helpers/random.js';
import User, { IUser } from '@modules/users/index.js';
import { JWT_SECRET_KEY } from '@helpers/env.js';
import moment from 'moment';

export const _deps = {
  generateAccessToken: _generateAccessToken,
  generateRefreshToken: _generateRefreshToken,
  updateUserSession: _updateUserSession
};

async function generateUserTokens ({ userId, oldRefreshToken }: IGenerateUserTokensParams) {
  const { generateAccessToken, generateRefreshToken, updateUserSession } = _deps;

  const payload = await User.getAccessTokenPayload({ filter: { _id: userId } });
  if (!payload) {
    throw new Error(`User \`${userId}\` is not found.`);
  }

  const accessToken = generateAccessToken({ payload });
  const refreshToken = generateRefreshToken();

  await updateUserSession({ userId, refreshToken, oldRefreshToken });

  return { accessToken, refreshToken };
}

export default generateUserTokens;

function _generateAccessToken ({ payload, options = { expiresIn: '1y' } }) {
  return jwt.sign(payload, JWT_SECRET_KEY, options);
}

function _generateRefreshToken () {
  return Random.uuid();
}

async function _updateUserSession ({ userId, refreshToken, oldRefreshToken }) {
  await Promise.all([
    User.dal.updateOne({
      filter: { _id: userId },
      update: {
        $pull: { refreshTokens: { token: oldRefreshToken } }
      }
    }),
    User.dal.updateOne({
      filter: { _id: userId },
      update: {
        $push: {
          refreshTokens: { token: refreshToken, expiresAt: moment().add(14, 'days').toDate() }
        }
      }
    })
  ]);

  const user = await User.dal.findOne({
    filter: { _id: userId },
    select: 'refreshTokens',
    lean: true
  });

  const userHasMoreThanTenRefreshTokens = user.refreshTokens.length > 10;
  if (userHasMoreThanTenRefreshTokens) {
    await User.dal.updateOne({
      filter: { _id: userId },
      update: {
        $pull: { refreshTokens: { token: user.refreshTokens[0].token } }
      }
    });
  }
}

interface IGenerateUserTokensParams {
  userId: IUser['_id'];
  oldRefreshToken?: IUser['refreshTokens'][number]['token'];
}