import User, { IActingUser, IUser } from '@modules/users/index.js';
import * as Objects from '@helpers/objects.js';
import { FilterQuery } from 'mongoose';

export const _deps = {
  getUser: _getUser
};

async function getUserAccessTokenPayload ({ filter }: IGetUserAccessTokenPayloadParams): Promise<IActingUser> {
  const { getUser } = _deps;

  const user = await getUser({ filter });

  if (!user || user.isDeleted) {
    return null;
  }

  const payload = {
    _id: user._id,
    roles: user.roles,
    email: user.email,
    companyId: user.companyId
  };

  return Objects.safeJSONify(payload);
}

export default getUserAccessTokenPayload;

async function _getUser ({ filter }: { filter: FilterQuery<IUser> }) {
  return await User.dal.findOne({
    filter,
    select: 'roles email companyId',
    populate: {
      path: 'companyId'
    },
    lean: true
  });
}

interface IGetUserAccessTokenPayloadParams {
  filter: FilterQuery<IUser>
}