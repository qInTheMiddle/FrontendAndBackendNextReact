import { IUser } from '@modules/users/index.js';

export interface IActingUser {
  _id: IUser['_id'];
  roles: IUser['roles'];
  email: IUser['email'];
  companyId?: IUser['companyId'];
}