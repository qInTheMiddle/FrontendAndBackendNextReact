import moment from 'moment';
import { Request, Response } from 'express';
import User, { UserRole } from '@modules/users/index.js';
import Random from '@helpers/random.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import CONSTANTS from '@helpers/constants.js';
import sendEmail from '@helpers/send.email.js';
const validationSchema = {
  body: Joi.object().required().keys({
    email: Joi.string().required().email().lowercase()
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });

  const user = await User.dal.findOne({
    filter: { email: body.email, isEmailVerified: false, roles: UserRole.COMPANY_EMPLOYEE },
    select: 'emailVerification',
    lean: true
  });
  if (!user || moment().isBefore(user.emailVerification?.blockExpiresAt)) {
    return res.status(204).json();
  }

  if (user.emailVerification?.sendCount >= 5) {
    await User.dal.updateOne({
      filter: { email: body.email, isEmailVerified: false },
      update: {
        'emailVerification.sendCount': 0,
        'emailVerification.blockExpiresAt': moment().add(24, 'hours').toDate()
      }
    });

    return res.status(204).json();
  }

  const emailVerificationToken = Random.uuid();

  const updateResult = await User.dal.updateOne({
    filter: { email: body.email, isEmailVerified: false },
    update: {
      'emailVerification.sendCount': (user.emailVerification.sendCount || 0) + 1,
      'emailVerification.token': emailVerificationToken,
      'emailVerification.expiresAt': moment().add(2, 'hours').toDate(),
      'emailVerification.blockExpiresAt': moment().add(10, 'minutes').toDate()
    }
  });

  if (updateResult.modifiedCount) {
    await sendEmail({
      from: 'Hello Inboard<hello@inboard.sa>',
      to: body.email,
      subject: 'Inboard Email Verification',
      templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.companyEmailVerification,
      dynamicTemplateData: { emailVerificationToken }
    });
  }

  return res.status(204).json();
};