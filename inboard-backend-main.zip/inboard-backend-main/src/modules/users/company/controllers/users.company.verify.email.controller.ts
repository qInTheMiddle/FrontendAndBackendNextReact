import { Request, Response } from 'express';
import User from '@modules/users/index.js';
import { CustomError } from '@helpers/errors.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    emailVerificationToken: Joi.string().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });

  const user = await User.dal.findOne({
    filter: {
      'emailVerification.token': body.emailVerificationToken,
      'emailVerification.expiresAt': { $gt: new Date() }
    },
    lean: true
  });
  if (!user) {
    throw new CustomError('Email verification token has already expired.');
  }

  await User.dal.updateOne({
    filter: { _id: user._id },
    update: {
      isEmailVerified: true,
      $unset: { emailVerification: true }
    }
  });

  const { accessToken, refreshToken } = await User.generateTokens({ userId: user._id });

  return res.json({ accessToken, refreshToken });
};