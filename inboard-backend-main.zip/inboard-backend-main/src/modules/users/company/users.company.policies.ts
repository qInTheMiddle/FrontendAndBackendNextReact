export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['company-employee'],
    allows: [
      { resources: '/api/company/user/register/', permissions: 'post' },
      { resources: '/api/company/user/verify-email/', permissions: 'post' },
      { resources: '/api/company/user/resend-email-verification/', permissions: 'post' },
      { resources: '/api/company/user/login/', permissions: 'post' },
      { resources: '/api/company/user/view/', permissions: 'get' },
      { resources: '/api/company/user/update/', permissions: 'put' }
    ]
  }]);
}