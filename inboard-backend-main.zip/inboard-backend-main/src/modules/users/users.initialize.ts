import { Application } from 'express';
import { Acl } from 'acl';
import routes from './users.routes.js';
import policies from './users.policies.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}