export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/user/login/', permissions: 'post' }
    ]
  }]);
}