import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();

export default function (app: Application) {
  app.post('/api/team/user/login/', jsonParser, makeCallback(controllers.login));
}