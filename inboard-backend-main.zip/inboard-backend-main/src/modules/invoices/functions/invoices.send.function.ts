import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import { CustomError } from '@helpers/errors.js';
import sendEmail from '@helpers/send.email.js';
import { makeHttpRequest } from '@helpers/make.http.request.js';
import CONSTANTS from '@helpers/constants.js';

async function sendInvoice ({ invoiceId, email }) {
  const invoice = await Invoice.dal.findOne({
    filter: { _id: invoiceId },
    lean: true
  });


  if (!email && !invoice.customer.email) {
    throw new CustomError('Email is not provided.');
  }

  const emailData = {
    from: 'Hello Inboard<hello@inboard.sa>',
    to: email || invoice.customer.email,
    subject: `فاتورة ${invoice.customId}`,
    templateId: '',
    dynamicTemplateData: {
      invoiceUrl: '',
      invoiceId: invoice.customId
    },
    attachments: [
      {
        content: '',
        filename: `invoice-${invoice.customId}.pdf`,
        type: 'application/pdf',
        disposition: 'attachment'
      }
    ]
  };

  let downloadUrl = '';
  let templateId = '';
  switch (invoice.status) {
    case InvoiceStatus.PENDING:
      downloadUrl = invoice.performaInvoiceUrl;
      templateId = CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.proformaInvoice;
      break;
    case InvoiceStatus.PAID:
      downloadUrl = invoice.invoiceUrl;
      templateId = CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.invoice;
      break;
    default:
      throw new CustomError('Error generating invoice');
  }
  if (!downloadUrl) {
    throw new CustomError('Error generating invoice');
  }

  const buffer = await makeHttpRequest({
    method: 'GET',
    url: downloadUrl,
    responseType: 'buffer'
  });

  if (!buffer) {
    throw new CustomError('Error generating invoice');
  }

  emailData.attachments[0].content = buffer.toString('base64');
  emailData.dynamicTemplateData.invoiceUrl = downloadUrl;
  emailData.templateId = templateId;

  await sendEmail(emailData);

  return { case: 1, message: 'Sent invoices successfully.' };
}

export default sendInvoice;