import { Invoice } from '@axenda/zatca';
async function generateQRCode (invoiceData) {
  const invoice = new Invoice(invoiceData);
  const imageDate = await invoice.render();

  return imageDate;
}

export default generateQRCode;