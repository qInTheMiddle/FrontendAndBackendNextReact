import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import { CreateOptions } from 'html-pdf';
import CONSTANTS from '@helpers/constants.js';
import htmlToPDFBuffer from '@helpers/html.to.pdf.buffer.js';
import uploadToS3 from '@helpers/upload.to.s3.js';
import moment from 'moment';

async function generatePDF ({ invoiceId, app }) {
  const invoice = await Invoice.dal.findOne({
    filter: { _id: invoiceId },
    lean: true
  });

  const invoiceData: any = { ...invoice };

  invoiceData.totalAmount = invoice.totalAmount.toFixed(2);

  switch (invoice.status) {
    case InvoiceStatus.PAID:
      invoiceData.QRCode = invoice.QRCode;
      invoiceData.invoicedAt = moment(invoice.invoicedAt || invoice.createdAt).format('DD/MM/YYYY');
      break;
    default:
      invoiceData.invoicedAt = moment(invoice.createdAt).format('DD/MM/YYYY');
      invoiceData.QRCode = '';
      break;
  }

  const title = getInvoiceTitle(invoice);

  const html = await app.renderAsync('invoice', { invoiceData, title, assets: CONSTANTS.ASSETS_DIRECTORY_PATH });
  const pdfOptions: CreateOptions = { format: 'A4', footer: { height: '32mm' }, header: { height: '10mm' } };

  const buffer = await htmlToPDFBuffer({ html, pdfOptions });

  const pdfUrl = await uploadToS3({
    destinationInBucket: `invoices/${invoice.userId}/invoice-${invoice.status}-${invoice.customId}.pdf`,
    body: buffer,
    acl: 'public-read',
    bucketName: CONSTANTS.S3_BUCKETS.INBOARD
  });

  const invoiceUpdate = {
    invoiceUrl: invoice.status === InvoiceStatus.PAID ? pdfUrl : undefined,
    performaInvoiceUrl: invoice.status === InvoiceStatus.PENDING ? pdfUrl : undefined
  };

  // remove empty keys
  Object.keys(invoiceUpdate)
    .forEach(key => invoiceUpdate[key] === undefined && delete invoiceUpdate[key]);


  await Invoice.dal.updateOne({
    filter: { _id: invoiceId },
    update: invoiceUpdate
  });


  return { case: 1, message: 'Created invoices successfully.', invoiceUrl: pdfUrl, buffer };
}

function getInvoiceTitle (invoice) {
  const { status } = invoice;
  switch (status) {
    case InvoiceStatus.PENDING:
    default:
      return 'فاتورة مبدئية';
    case InvoiceStatus.PAID:
      return 'فاتورة ضريبية مبسطة';
  }
}


export default generatePDF;