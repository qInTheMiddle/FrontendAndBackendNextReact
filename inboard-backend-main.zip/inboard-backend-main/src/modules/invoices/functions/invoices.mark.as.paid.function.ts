import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import Payment from '@modules/payments/index.js';
import { PaymentMethod } from '@helpers/generic.types.js';
import moment from 'moment';
import { CustomError } from '@helpers/errors.js';

async function payInvoice ({ invoiceId, paymentId }) {
  const invoice = await Invoice.dal.findOne({ filter: { _id: invoiceId }, lean: true });
  const payment = await Payment.dal.findOne({ filter: { _id: paymentId }, lean: true });
  const paymentExistsInInvoice = await Invoice.dal.exists({ filter: { paymentId } });

  if (invoice.paymentId) {
    throw new CustomError('Invoice already paid.');
  }

  if (paymentExistsInInvoice) {
    throw new CustomError('Payment already exists in invoice.');
  }

  if (invoice.status === InvoiceStatus.PAID || invoice.status === InvoiceStatus.REFUNDED) {
    throw new CustomError('Invoice is not pending.');
  }

  const { totalAmount, VAT } = invoice;
  const invoicedAt = new Date();

  const QRCode = await Invoice.generateQRCode({
    sellerName: 'شركة الخبرة المهنية لتقنية المعلومات',
    vatRegistrationNumber: '311364064300003',
    invoiceTimestamp: moment(invoicedAt).format('YYYY-MM-DDTHH:mm:ss'),
    invoiceTotal: totalAmount.toString(),
    invoiceVatTotal: VAT.toString()
  });

  const paymentMethod = payment.method as PaymentMethod;

  const invoiceChanges = {
    QRCode,
    status: InvoiceStatus.PAID,
    paymentMethod,
    paidAt: payment.paidAt,
    paidAmount: payment.amount,
    paymentId,
    invoicedAt
  };



  await Invoice.dal.updateOne({
    filter: { _id: invoiceId },
    update: invoiceChanges
  });

  await Payment.dal.updateOne({
    filter: { _id: paymentId },
    update: { invoiceId }
  });

  return { case: 1, message: 'Paid invoices successfully.' };
}


export default payInvoice;