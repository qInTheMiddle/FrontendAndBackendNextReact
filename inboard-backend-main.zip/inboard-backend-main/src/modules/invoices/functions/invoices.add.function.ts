import Payment from '@modules/payments/index.js';
import Invoice, { IInvoice, InvoiceStatus } from '@modules/invoices/index.js';
import Application from '@modules/applications/index.js';
import * as VATHelper from '@helpers/calculate.vat.js';
import * as Numbers from '@helpers/numbers.js';
import { CustomError } from '@helpers/errors.js';

async function addInvoice ({ applicationId, customer = { name: '', email: '', phone: '', address: '' } }) {
  const application = await Application.dal.findOne({
    filter: { _id: applicationId },
    populate: [
      { path: 'opportunityId', select: 'title' },
      { path: 'userId', select: 'firstName lastName email mobile mobileCC' }
    ],
    lean: true
  });

  if (!application) {
    throw new CustomError(`Application ${applicationId} Not Found.`);
  }

  const existingInvoice = await Invoice.dal.exists({ filter: { applicationId } });
  if (existingInvoice) {
    throw new CustomError(`Invoice already exists for application ${applicationId}.`);
  }

  const totalAmount = Numbers.toFixedNumber(application.applicationFees);
  const totalAmountWithoutVAT = VATHelper.getOriginalAmount(totalAmount);
  const VAT = VATHelper.getVATFromAmountWithVAT(totalAmount);

  const items: IInvoice['items'] = [{
    name: `رسوم خبرة ${application.opportunityId.title.arabic}`,
    description: 'خبرة عملية للتدريب على العمل',
    quantity: 1,
    unitPrice: totalAmount,
    unitPriceWithoutVAT: totalAmountWithoutVAT,
    VAT,
    totalAmount
  }];

  const name = customer.name || `${application.userId.firstName || ''} ${application.userId.lastName || ''}`;
  const address = customer.address || 'N/A';
  const phone = customer.phone || `00${application.userId.mobileCC}${application.userId.mobile}`;
  const email = customer.email || application.userId.email;

  const invoice: Partial<IInvoice> = {
    applicationId,
    userId: application.userId._id,
    status: InvoiceStatus.PENDING,
    totalAmount,
    totalAmountWithoutVAT,
    VAT,
    vatPercentage: 15,
    customer: {
      name,
      address,
      phone,
      email
    },
    items
  };



  const createdInvoice = await Invoice.dal.create(invoice);

  await Payment.dal.updateOne({
    filter: { applicationId },
    update: { invoiceId: createdInvoice._id }
  });

  return { case: 1, message: 'Created invoices successfully.', invoice: createdInvoice };
}


export default addInvoice;