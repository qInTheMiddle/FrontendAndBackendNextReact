import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import moment from 'moment';
import { CustomError } from '@helpers/errors.js';

async function refundInvoice ({ invoiceId }) {
  const invoice = await Invoice.dal.findOne({ filter: { _id: invoiceId }, lean: true });

  if (invoice.status !== InvoiceStatus.PAID) {
    throw new CustomError('Invoice is not paid.');
  }

  const { totalAmount, VAT } = invoice;
  const refundedAt = new Date();

  const QRCode = await Invoice.generateQRCode({
    sellerName: 'شركة الخبرة المهنية لتقنية المعلومات',
    vatRegistrationNumber: '311364064300003',
    invoiceTimestamp: moment(refundedAt).format('YYYY-MM-DDTHH:mm:ss'),
    invoiceTotal: totalAmount.toString(),
    invoiceVatTotal: VAT.toString()
  });

  const invoiceChanges = {
    creditNoteQRCode: QRCode,
    status: InvoiceStatus.REFUNDED,
    refundedAt
  };



  await Invoice.dal.updateOne({
    filter: { _id: invoiceId },
    update: invoiceChanges
  });

  return { case: 1, message: 'Refunded invoices successfully.' };
}


export default refundInvoice;