export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/invoices/create/', permissions: 'post' },
      { resources: '/api/team/invoices/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/team/invoices/:invoiceId/view/', permissions: 'get' },
      { resources: '/api/team/invoices/:invoiceId/print/', permissions: 'get' },
      { resources: '/api/team/invoices/:invoiceId/send/', permissions: 'post' },
      { resources: '/api/team/invoices/:invoiceId/mark-as-paid/', permissions: 'post' },
      { resources: '/api/team/invoices/:invoiceId/refund/', permissions: 'post' }
    ]
  }]);
}