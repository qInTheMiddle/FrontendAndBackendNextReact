import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import isAllowed from '@helpers/is.allowed.js';
import express, { Application } from 'express';
const jsonParser = express.json();

export default function (app: Application) {
  app.post('/api/team/invoices/create/', isAllowed, jsonParser, makeCallback(controllers.create));
  app.get('/api/team/invoices/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/team/invoices/:invoiceId/view/', isAllowed, makeCallback(controllers.view));
  app.get('/api/team/invoices/:invoiceId/print/', isAllowed, makeCallback(controllers.print));
  app.post('/api/team/invoices/:invoiceId/send/', isAllowed, jsonParser, makeCallback(controllers.send));
  app.post('/api/team/invoices/:invoiceId/mark-as-paid/', isAllowed, jsonParser, makeCallback(controllers.markAsPaid));
  app.post('/api/team/invoices/:invoiceId/refund/', isAllowed, jsonParser, makeCallback(controllers.refund));
}