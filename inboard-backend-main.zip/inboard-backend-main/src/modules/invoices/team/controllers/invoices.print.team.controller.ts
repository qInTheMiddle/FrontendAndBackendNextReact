import Joi from '@helpers/joi.js';
// import { CustomError } from '@helpers/errors.js';
import Invoice from '@modules/invoices/index.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
import fs from 'fs-extra';
const validationSchema = {
  params: Joi.object().required().keys({
    invoiceId: Joi.mongoId().required()
  })
};


export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });
  const { invoiceId } = params;

  const buffer = await Invoice.generatePDF({ invoiceId, app: req.app });

  await fs.writeFile(`./invoices/${invoiceId}.pdf`, buffer);

  return res.json({ case: 1, message: 'Found invoice successfully.' });
};