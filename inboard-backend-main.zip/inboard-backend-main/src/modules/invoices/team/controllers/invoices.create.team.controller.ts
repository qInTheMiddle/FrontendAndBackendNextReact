import Joi from '@helpers/joi.js';
import { CustomError } from '@helpers/errors.js';
import Invoice from '@modules/invoices/index.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  body: Joi.object().keys({
    applicationId: Joi.mongoId().required(),
    customer: Joi.object().keys({
      name: Joi.string(),
      email: Joi.string().email(),
      phone: Joi.string(),
      address: Joi.string()
    })
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });
  const { customer, applicationId } = body;

  const { invoice } = await Invoice.add({ applicationId, customer });
  if (!invoice) {
    throw new CustomError('Invoice can not be created.');
  }

  return res.json({ case: 1, message: 'Found invoice successfully.', invoice });
};