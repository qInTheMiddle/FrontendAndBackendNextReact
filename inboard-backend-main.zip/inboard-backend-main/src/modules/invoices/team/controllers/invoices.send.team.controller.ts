import Joi from '@helpers/joi.js';
import { CustomError } from '@helpers/errors.js';
import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  params: Joi.object().required().keys({
    invoiceId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    email: Joi.string().email().allow(null, '').optional()
  })
};


export default async (req: Request, res: Response) => {
  const { params, body } = validateRequest(req, validationSchema, { warn: true });
  const { invoiceId } = params;
  const { email } = body;

  const invoice = await Invoice.dal.findOne({ filter: { _id: invoiceId }, lean: true });
  if (!invoice.performaInvoiceUrl && invoice.status === InvoiceStatus.PENDING) {
    await Invoice.generatePDF({ invoiceId, app: req.app });
  }

  if (!invoice.invoiceUrl && invoice.status === InvoiceStatus.PAID) {
    await Invoice.generateQRCode({ invoiceId });
    await Invoice.generatePDF({ invoiceId, app: req.app });
  }

  const sendInvoice = await Invoice.sendInvoice({ invoiceId, email });

  if (!sendInvoice.case) {
    throw new CustomError('Could not send invoice');
  }

  return res.json({ case: 1, message: 'Found invoice successfully.', invoice: sendInvoice });
};