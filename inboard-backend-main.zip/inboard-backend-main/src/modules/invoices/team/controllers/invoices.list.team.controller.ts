import { Request as Req, Response } from 'express';
import calculatePagesCount from '@helpers/calculate.pages.count.js';
import Invoice from '@modules/invoices/index.js';


export default async (req: Req, res: Response) => {
  const sortBy = req.params.sortBy || '-createdAt';
  const limit = Math.min(Number(req.params.limit) || 30, 100);
  const currentPage = parseInt(req.params.page) || 1;


  const [invoices, invoicesCount] = await Promise.all([
    Invoice.dal.find({
      filter: {},
      select: 'customId totalAmount VAT totalAmountWithoutVAT invoiceUrl invoicedAt paidAt applicationId userId paymentId status customer performaInvoiceUrl creditNoteId',
      populate: [
        {
          path: 'applicationId',
          select: 'customId',
          populate: {
            path: 'opportunityId',
            select: 'title companyId',
            populate: {
              path: 'companyId',
              select: 'name'
            }
          }

        },
        { path: 'paymentId', select: 'method amount' },
        { path: 'creditNoteId', select: 'creditNoteUrl' }
      ],
      paginate: { documentsPerPage: limit, page: currentPage },
      sort: sortBy,
      lean: true
    }),
    Invoice.Model.countDocuments({})
  ]);

  if (!invoicesCount) {
    return res.json({ case: 2, message: 'No invoices found.' });
  }

  const pagesCount = calculatePagesCount({ documentsCount: invoicesCount, documentsPerPage: limit });

  return res.json({ case: 1, message: 'Found invoices successfully.', invoicesCount, pagesCount, invoices });
};