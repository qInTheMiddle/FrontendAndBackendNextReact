import Joi from '@helpers/joi.js';
import { CustomError } from '@helpers/errors.js';
import Invoice from '@modules/invoices/index.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  params: Joi.object().required().keys({
    invoiceId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    paymentId: Joi.mongoId().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body, params } = validateRequest(req, validationSchema, { warn: true });

  const { invoiceId } = params;
  const { paymentId } = body;

  const invoice = await Invoice.markAsPaid({ invoiceId, paymentId });

  if (!invoice?.case) {
    throw new CustomError('Invoice can not be set as paid.');
  }

  return res.json({ case: 1, message: 'Found invoice successfully.', invoice });
};