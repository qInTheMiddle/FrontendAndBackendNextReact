import teamPolicies from './team/invoices.team.policy.js';

export default function invokeRolesPolicies (acl) {
  teamPolicies(acl);
}