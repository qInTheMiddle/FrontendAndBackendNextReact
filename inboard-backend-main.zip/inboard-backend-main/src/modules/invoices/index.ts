export * from './invoices.model.interface.js';

import DAL from '@helpers/dal.js';
import Model from './invoices.model.js';

const dal = new DAL(Model);

import { default as add } from './functions/invoices.add.function.js';
import { default as generateQRCode } from './functions/invoices.generate.qr.code.function.js';
import { default as generatePDF } from './functions/invoices.generate.pdf.function.js';
import { default as sendInvoice } from './functions/invoices.send.function.js';
import { default as markAsPaid } from './functions/invoices.mark.as.paid.function.js';
import { default as refund } from './functions/invoices.mark.as.refunded.function.js';

export default {
  Model,
  dal,
  add,
  generateQRCode,
  generatePDF,
  sendInvoice,
  markAsPaid,
  refund
};