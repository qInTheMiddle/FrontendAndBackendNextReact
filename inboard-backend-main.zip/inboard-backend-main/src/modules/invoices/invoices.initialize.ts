import { Application } from 'express';
import { Acl } from 'acl';
import routes from './invoices.routes.js';
import policies from './invoices.policies.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}