import { Request, Response } from 'express';
import Payment from '@modules/payments/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    paymentId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });

  const payment = await Payment.dal.findOne({
    filter: { _id: params.paymentId, isRefunded: { $ne: true } },
    lean: true
  });
  if (!payment) {
    return res.status(404).json({ message: 'Payment Not Found.' });
  }

  await Payment.dal.updateOne({
    filter: { _id: params.paymentId },
    update: { isRefunded: true, refundedAt: new Date(), refundedAmount: payment.amount, refundedBy: req.user._id }
  });

  return res.status(200).json({ payment });
};