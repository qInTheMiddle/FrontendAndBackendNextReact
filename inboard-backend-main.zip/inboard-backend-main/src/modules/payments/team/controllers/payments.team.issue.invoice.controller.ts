import { Request, Response } from 'express';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import Invoice, { InvoiceStatus } from '@modules/invoices/index.js';
import Payment from '@modules/payments/index.js';
const validationSchema = {
  params: Joi.object().required().keys({
    paymentId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });
  const { paymentId } = params;

  const payment = await Payment.dal.findOne({
    filter: { _id: paymentId },
    select: 'applicationId invoiceId',
    populate: {
      path: 'invoiceId',
      select: 'status'
    },
    lean: true
  });

  if (!payment) {
    return res.status(404).json({ message: 'Payment Not Found.' });
  }

  if (!payment.applicationId) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }

  let { invoiceId }: { invoiceId?: any } = payment;
  let existingInvoiceId = invoiceId?._id;
  if (!invoiceId) {
    const { invoice } = await Invoice.add({ applicationId: payment.applicationId });
    invoiceId = invoice;
    existingInvoiceId = invoice._id;
  }


  if (invoiceId.status === InvoiceStatus.PENDING) {
    await Invoice.markAsPaid({ invoiceId: existingInvoiceId, paymentId: payment._id });
  }

  await Invoice.generatePDF({ invoiceId: existingInvoiceId, app: req.app });
  await Invoice.sendInvoice({ invoiceId: existingInvoiceId, email: '' });


  return res.status(200).json({ case: 1, message: 'Invoice sent successfully' });
};