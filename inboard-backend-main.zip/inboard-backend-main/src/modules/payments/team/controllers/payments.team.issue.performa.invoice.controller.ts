import { Request, Response } from 'express';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import Invoice from '@modules/invoices/index.js';
import Payment from '@modules/payments/index.js';
const validationSchema = {
  params: Joi.object().required().keys({
    paymentId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    email: Joi.string().email().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });
  const { paymentId } = params;
  const { email } = req.body;

  const payment = await Payment.dal.findOne({
    filter: { _id: paymentId },
    select: 'applicationId invoiceId',
    lean: true
  });

  if (!payment) {
    return res.status(404).json({ message: 'Payment Not Found.' });
  }

  if (!payment.applicationId) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }

  if (payment.invoiceId) {
    await Invoice.generatePDF({ invoiceId: payment.invoiceId, app: req.app });
    await Invoice.sendInvoice({ invoiceId: payment.invoiceId, email });

    return res.status(200).json({ case: 1, message: 'Invoice sent successfully' });
  }

  const { invoice } = await Invoice.add({ applicationId: payment.applicationId });

  await Invoice.generatePDF({ invoiceId: invoice._id, app: req.app });

  await Invoice.sendInvoice({ invoiceId: invoice._id, email });


  return res.status(200).json({ case: 1, message: 'Invoice sent successfully' });
};