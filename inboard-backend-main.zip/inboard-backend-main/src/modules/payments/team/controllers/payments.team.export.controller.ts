import { Request, Response } from 'express';
import Payment, { PaymentFor } from '@modules/payments/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import moment from 'moment';
import XLSX from 'xlsx';
const validationSchema = {
  query: Joi.object().required().keys({
    from: Joi.date().required(),
    to: Joi.date().required()
  })
};
export default async (req: Request, res: Response) => {
  const { query } = validateRequest(req, validationSchema, { warn: true });
  const paymentsQuery = {
    createdAt: {
      $gte: query.from,
      $lte: query.to
    }
  };
  const payments = await Payment.dal.find({
    filter: paymentsQuery,
    populate: [
      {
        path: 'applicationId',
        populate: {
          path: 'opportunityId',
          populate: { path: 'companyId', select: 'name' }
        }
      },
      { path: 'userId', select: 'firstName lastName mobileCC mobile' }
    ],
    sort: 'createdAt',
    lean: true
  });

  const paymentsMap = payments.map((payment) => {
    const { applicationId, userId, amount, createdAt, paymentFor } = payment;
    const username = `${userId.firstName} ${userId.lastName}`;
    const opportunityName = applicationId.opportunityId.title.arabic;
    const companyName = applicationId.opportunityId.companyId?.name;
    const paymentForInArabic = paymentFor === PaymentFor.APPLICATION_FEES ? 'رسوم التقديم' : 'رسوم الفرصة';
    const mobileNumber = `${userId.mobileCC}${userId.mobile}`;
    const applicationCustomId = applicationId.customId;
    const opportunityCustomId = applicationId.opportunityId.customId;
    const paymentDate = moment(createdAt).format('DD/MM/YYYY');
    const amountInArabic = amount.toFixed(2);
    return {
      التاريخ: paymentDate,
      'معرف النموذج': applicationCustomId,
      'معرف الفرصة': opportunityCustomId,
      'اسم المستخدم': username,
      'رقم الجوال': mobileNumber,
      'اسم الشركة': companyName,
      'اسم الفرصة': opportunityName,
      المبلغ: amountInArabic,
      'المدفوع ل': paymentForInArabic,
      'حالة الدفع': payment.isRefunded ? 'تم الارجاع' : 'تم الدفع'
    };

  });
  const readableFrom = moment(query.from as string).format('DD-MM-YYYY');
  const readableTo = moment(query.to as string).format('DD-MM-YYYY');
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(paymentsMap);
  XLSX.utils.book_append_sheet(workbook, worksheet, 'المدفوعات');
  const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename=payments_from_${readableFrom}_to_${readableTo}.xlsx`);
  return res.send(buffer);


};