import { Request, Response } from 'express';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import Payment from '@modules/payments/index.js';
import CreditNotes from '@modules/credit.notes/index.js';

const validationSchema = {
  params: Joi.object().required().keys({
    paymentId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });
  const { paymentId } = params;

  const payment = await Payment.dal.findOne({
    filter: { _id: paymentId },
    select: 'invoiceId',
    lean: true
  });

  if (!payment) {
    return res.status(404).json({ message: 'Payment Not Found.' });
  }

  if (!payment.invoiceId) {
    return res.status(404).json({ message: 'Invoice Not Found.' });
  }

  const { creditNote } = await CreditNotes.add({ invoiceId: payment.invoiceId });
  if (!creditNote) {
    return res.status(400).json({ message: 'Credit Note is not created.' });
  }

  await CreditNotes.generatePDF({ creditNoteId: creditNote._id, app: req.app });
  await CreditNotes.sendCreditNote({ creditNoteId: creditNote._id, email: '' });

  await Payment.dal.updateOne({
    filter: { _id: params.paymentId },
    update: {
      isRefunded: true,
      refundedAt: new Date(),
      refundedAmount: payment.amount,
      refundedBy: req.user._id,
      creditNoteId: creditNote._id
    }
  });

  return res.status(200).json({ creditNote });
};