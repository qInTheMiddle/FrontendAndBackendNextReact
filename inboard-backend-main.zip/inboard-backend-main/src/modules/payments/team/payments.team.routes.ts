import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.get('/api/team/payments/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/team/payments/export/', isAllowed, makeCallback(controllers.exportPayments));
  app.get('/api/team/payments/:paymentId/view/', isAllowed, makeCallback(controllers.view));
  app.put('/api/team/payments/:paymentId/mark-as-refunded/', isAllowed, makeCallback(controllers.markAsRefunded));
  app.post('/api/team/payments/:paymentId/issue-invoice/', isAllowed, jsonParser, makeCallback(controllers.issueInvoice));
  app.post('/api/team/payments/:paymentId/refund-invoice/', isAllowed, jsonParser, makeCallback(controllers.refundInvoice));
  app.post('/api/team/payments/:paymentId/issue-performa-invoice/', isAllowed, jsonParser, makeCallback(controllers.issuePerformaInvoice));
}