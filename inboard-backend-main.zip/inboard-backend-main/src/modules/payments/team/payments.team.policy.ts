export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/payments/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/team/payments/:paymentId/view/', permissions: 'get' },
      { resources: '/api/team/payments/export/', permissions: 'get' },
      { resources: '/api/team/payments/:paymentId/mark-as-refunded/', permissions: 'put' },
      { resources: '/api/team/payments/:paymentId/issue-invoice/', permissions: 'post' },
      { resources: '/api/team/payments/:paymentId/refund-invoice/', permissions: 'post' },
      { resources: '/api/team/payments/:paymentId/issue-performa-invoice/', permissions: 'post' }
    ]
  }]);
}