import applicantPolicies from './applicant/payments.applicant.policy.js';
import teamPolicies from './team/payments.team.policy.js';

export default function invokeRolesPolicies (acl) {
  applicantPolicies(acl);
  teamPolicies(acl);
}