import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';
import { IUser } from '@modules/users/index.js';
import { IApplication } from '@modules/applications/index.js';
import { CounterPrefix } from '@modules/counters/index.js';
import { IInvoice } from '@modules/invoices/index.js';
import { ICreditNote } from '@modules/credit.notes/index.js';

export interface IPayment<Populate = true> extends IMongo {
  userId: PopulatedDoc<IUser, Populate>;
  applicationId: PopulatedDoc<IApplication, Populate>;
  invoiceId?: PopulatedDoc<IInvoice, Populate>;
  creditNoteId?: PopulatedDoc<ICreditNote, Populate>;

  paymentFor: PaymentFor;

  amount: number;
  capturedAmount?: number;
  amountToCapture?: number;
  isTabbyPaymentClosed?: boolean;
  paidAt?: Date;

  method?: 'tap' | 'tabby' | 'tamara';

  tap: ITap;

  tabby: ITabby;
  tabbyPaymentPlan?: TabbyPaymentPlan;

  refundedByUserId?: PopulatedDoc<IUser, Populate>;
  refundedAmount?: number;
  refundedAt?: Date;
  isRefunded?: boolean;

  customId: `${CounterPrefix.PAYMENT}${number}`;
}

export enum PaymentFor {
  APPLICATION_FEES = 'application-fees',
  OPPORTUNITY_FEES = 'opportunity-fees'
}

export interface ITap {
  id: string
  object: string
  live_mode: boolean
  api_version: string
  method: string
  status: string
  amount: number
  currency: string
  threeDSecure: boolean
  card_threeDSecure: boolean
  save_card: boolean
  merchant_id: string
  product: string
  description: string
  metadata: {
    applicationId: string
    paymentFor: string
    userId: string
  };
  transaction: {
    authorization_id: string
    timezone: string
    created: string
    expiry: {
      period: number
      type: string
    };
    asynchronous: boolean
    amount: number
    currency: string
  };
  reference: {
    track: string
    payment: string
    gateway: string
    acquirer: string
  }
  response: {
    code: string
    message: string
  }
  security: {
    threeDSecure: {
      id: string
      status: string
    };
  };
  acquirer: {
    response: {
      code: string
      message: string
    };
  };
  gateway: {
    response: {
      code: string
      message: string
    };
  }
  card: {
    object: string
    first_six: string
    scheme: string
    brand: string
    last_four: string
  };
  receipt: {
    id: string
    email: boolean
    sms: boolean
  };
  customer: {
    id: string
    first_name: string
    last_name: string
    email: string
    phone: {
      country_code: string
      number: string
    };
  };
  merchant: {
    country: string
    currency: string
    id: string
  };
  source: {
    object: string
    type: string
    payment_type: string
    payment_method: string
    channel: string
    id: string
  };
  redirect: {
    status: string
    url: string
  };
  activities: Array<{
    id: string
    object: string
    created: number
    status: string
    currency: string
    amount: number
    remarks: string
  }>;
  auto_reversed: boolean
}

interface ITabby {
  id?: string;
  created_at?: string;
  expires_at?: string;
  amount?: string;
  currency?: string;
  description?: string;
  status?: string;
  test?: boolean;
  buyer?: {
    phone?: string;
    email?: string;
    name?: string;
    dob?: string;
  };
  buyer_history?: {
    registered_since?: string;
    loyalty_level?: number;
    wishlist_count?: number;
  };
  order?: {
    tax_amount?: string;
    shipping_amount?: string;
    discount_amount?: string;
    updated_at?: string;
    reference_id?: string;
    items?: any[]
  };
  order_history?: any[];
  shipping_address?: {
    city?: string;
    address?: string;
    zip?: string;
  };
  captures?: any[];
  refunds?: any[];
}

export enum TabbyPaymentPlan {
  PAY_LATER = 'pay-later',
  INSTALLMENTS = 'installments'
}