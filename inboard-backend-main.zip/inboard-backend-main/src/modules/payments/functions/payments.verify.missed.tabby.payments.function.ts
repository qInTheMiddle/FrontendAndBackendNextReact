import moment from 'moment';
import Tabby from '@helpers/tabby/index.js';
import Payment from '@modules/payments/index.js';
import reportError from '@helpers/report.error.js';
import { CounterPrefix } from '@modules/counters/index.js';

export const _deps = {
  getUnprocessedUserIdsAndTabbyPaymentIds: _getUnprocessedUserIdsAndTabbyPaymentIds
};

async function verifyMissedTabbyPayments () {
  const { getUnprocessedUserIdsAndTabbyPaymentIds } = _deps;

  const tabbyPayments = await Tabby.listPayments({
    startDate: moment().subtract(1, 'day').toDate(),
    endDate: new Date()
  });

  const unprocessedTabbyPayments = getUnprocessedUserIdsAndTabbyPaymentIds(tabbyPayments);

  for (const { userId, tabbyPaymentId } of unprocessedTabbyPayments) {
    console.log(`Processing missed tabby payment ${tabbyPaymentId}`);
    await Payment.verifyTabby({ userId, tabbyPaymentId }).catch(reportError);
  }
}

export default verifyMissedTabbyPayments;

function _getUnprocessedUserIdsAndTabbyPaymentIds (tabbyPayments) {
  const paymentsWithoutCustomIds = tabbyPayments.filter((payment) => {
    const isApplication = payment.order.reference_id.startsWith(CounterPrefix.APPLICATION);
    return !isApplication && !payment.is_expired;
  });

  const userIdsAndTabbyPaymentIds = paymentsWithoutCustomIds.map(payment => {
    const [userId] = payment.order.reference_id.split('_');
    return {
      userId,
      tabbyPaymentId: payment.id
    };
  });

  return userIdsAndTabbyPaymentIds;
}