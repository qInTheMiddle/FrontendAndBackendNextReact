import { UpdateQuery } from 'mongoose';
import Payment from '@modules/payments/index.js';
import Application, { IApplication, ApplicationStatus } from '@modules/applications/index.js';
import Opportunity from '@modules/opportunities/index.js';
import User, { IUser } from '@modules/users/index.js';
import Tap from '@helpers/tap/index.js';
import sendEmail from '@helpers/send.email.js';
import CONSTANTS from '@helpers/constants.js';
import moment from 'moment';
import Invoice from '@modules/invoices/index.js';

async function verifyTapPayment ({ tapPaymentId, userId, app }: IVerifyTapPaymentParameters) {
  const tapVerificationResult = await Tap.verifyPayment({ tapPaymentId });
  if (tapVerificationResult.statusCode !== 200) {
    return { statusCode: tapVerificationResult.statusCode, message: tapVerificationResult.message };
  }

  const { tapPayment } = tapVerificationResult;
  if (userId.toString() !== tapPayment.metadata.userId) {
    return { statusCode: 401, message: 'Unauthroized' };
  }

  const paymentExists = await Payment.dal.exists({ filter: { 'tap.id': tapPayment.id } });
  if (paymentExists) {
    return { statusCode: 409, message: 'Payment Already Exists.' };
  }

  const application = await Application.dal.findOne({
    filter: {
      _id: tapPayment.metadata.applicationId,
      userId
    },
    select: 'opportunityId',
    populate: {
      path: 'opportunityId',
      select: 'title experienceGuideURL locationLink workHours',
      populate: {
        path: 'companyId',
        select: 'name slug'
      }
    },
    lean: true
  });
  if (!application) {
    throw new Error('Application Not Found.');
  }

  const payment = await Payment.Model.create({
    userId,
    applicationId: application._id,
    opportunityId: application.opportunityId,
    paymentFor: tapPayment.metadata.paymentFor,
    amount: tapPayment.amount,
    paidAt: new Date(),
    tap: tapPayment
  });

  const applicationUpdate: UpdateQuery<IApplication> = {};

  applicationUpdate.paidApplicationFees = tapPayment.amount;
  applicationUpdate.applicationFeesPaidAt = new Date();
  applicationUpdate.status = ApplicationStatus.PAID_APPLICATION_FEES;

  const templateId = CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.applicationPaid;

  await Application.dal.updateOne({
    filter: { _id: application._id },
    update: applicationUpdate
  });

  await Opportunity.dal.updateOne({
    filter: { _id: application.opportunityId },
    update: { $inc: { applicationsCount: 1, availableSeats: -1 } }
  });

  const user = await User.dal.findOne({ filter: { _id: userId }, select: 'email firstName lastName' });
  const { workHours, mentor } = application.opportunityId;

  const mentorName = `${mentor?.name?.firstName} ${mentor?.name?.lastName}`;

  sendEmail({
    from: 'Hello Inboard<hello@inboard.sa>',
    to: user.email,
    subject: 'Inboard Payment Confirmation',
    templateId,
    dynamicTemplateData: {
      firstName: user.firstName,
      lastName: user.lastName,
      companyName: application.opportunityId?.companyId.name,
      opportunityName: application.opportunityId?.title?.arabic,
      experienceGuide: application.opportunityId?.experienceGuideURL,
      startWorkDate: moment(application.opportunityId?.startingDate).format('YYYY-MM-DD'),
      locationLink: application.opportunityId?.locationLink,
      mentorNumber: application.opportunityId?.mentor?.phoneNumber,
      mentorName,
      workHours: hoursToAmPm(workHours)
    }
  });


  const { invoice } = await Invoice.add({ applicationId: application._id });
  if (invoice && app) {
    await Invoice.generatePDF({ invoiceId: invoice._id, app });
    await Invoice.sendInvoice({ invoiceId: invoice._id, email: '' });
  }


  return { statusCode: 200, paymentId: payment._id };
}

function hoursToAmPm ({ from, to }) {

  if (!from || !to) {
    return '';
  }

  const fromHoursInSeconds = moment.utc(from * 3600 * 1000);
  const toHoursInSeconds = moment.utc(to * 3600 * 1000);
  return `${fromHoursInSeconds.format('hh:mm A')} - ${toHoursInSeconds.format('hh:mm A')}`;
}
export default verifyTapPayment;

interface IVerifyTapPaymentParameters {
  tapPaymentId?: string;
  userId: IUser['_id'];
  app?: any;
}