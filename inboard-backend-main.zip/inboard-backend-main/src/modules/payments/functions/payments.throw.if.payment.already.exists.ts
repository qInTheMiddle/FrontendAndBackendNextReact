import Payment from '@modules/payments/index.js';

import { CustomError } from '@helpers/errors.js';

async function throwIfPaymentAlreadyExists ({
  foreignPaymentId,
  method
}) {
  const filter = getFilter({ foreignPaymentId, method });
  const paymentExists = await Payment.dal.exists({ filter });
  if (paymentExists) {
    throw new CustomError(`Payment ${method} ${foreignPaymentId} already exists, can not reuse it.`);
  }
}

function getFilter ({ foreignPaymentId, method }) {
  switch (method) {
    case 'tap':
      return { 'tap.id': foreignPaymentId };
    case 'tabby':
      return { 'tabby.id': foreignPaymentId };
    default:
      throw new Error(`Unexpected payment method: ${method}`);
  }
}

export {
  throwIfPaymentAlreadyExists,
  getFilter as _getFilter
};