import moment from 'moment';
import Tap from '@helpers/tap/index.js';
import Payment from '@modules/payments/index.js';
import reportError from '@helpers/report.error.js';

async function verifyMissedTapPayments () {
  const { tapPaymets } = await Tap.listPayments({
    startDate: moment().subtract(30, 'days').valueOf(),
    endDate: moment().valueOf(),
    status: 'CAPTURED'
  });

  const tapPaymentsIdToUserIdMap = {};

  const tapPaymentsIds = [];
  for (const tapPayment of tapPaymets) {
    tapPaymentsIdToUserIdMap[tapPayment.id] = tapPayment.metadata.userId;
    tapPaymentsIds.push(tapPayment.id);
  }

  const existingPayments = await Payment.dal.find({
    filter: { 'tap.id': { $in: tapPaymentsIds } },
    select: 'tap.id',
    lean: true
  });

  const existingTapPaymentsIds = new Set(existingPayments.map(payment => payment.tap.id));

  const missedTapPaymentsIds = tapPaymentsIds.filter(paymentId => !existingTapPaymentsIds.has(paymentId));

  for (const tapPaymentId of missedTapPaymentsIds) {
    await Payment.verifyTapPayment({ tapPaymentId, userId: tapPaymentsIdToUserIdMap[tapPaymentId] }).catch(reportError);
  }
}

export default verifyMissedTapPayments;