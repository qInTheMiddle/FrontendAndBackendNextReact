import Bluebird from 'bluebird';
import Payment, { IPayment } from '@modules/payments/index.js';
import Tabby from '@helpers/tabby/index.js';
import { UpdateQuery } from 'mongoose';

async function closeTabbyPayment ({ paymentId }: { paymentId: IPayment['_id'] }) {
  const payment = await Payment.dal.findOne({
    filter: { _id: paymentId, method: 'tabby' },
    select: 'tabby isTabbyPaymentClosed',
    lean: true
  });
  if (!payment) {
    throw new Error(`Payment ${paymentId} is not found.`);
  }

  if (payment.isTabbyPaymentClosed) {
    return { case: 2, message: 'Payment is already closed.' };
  }

  const closeResult = await Tabby.closePayment({ paymentId: payment.tabby.id });
  if (closeResult.case !== 1) {
    return { case: 3, message: 'Could not close tabby payment.' };
  }

  const paymentChanges: UpdateQuery<IPayment> = { isTabbyPaymentClosed: true };
  if (closeResult.payment?.id === payment.tabby.id) {
    paymentChanges.tabby = closeResult.payment;
  }

  if (!closeResult.payment) {
    await Bluebird.delay(3000);

    const tabbyPaymentResult = await Tabby.getPayment({ paymentId: payment.tabby.id });
    if (tabbyPaymentResult.case === 1) {
      paymentChanges.tabby = tabbyPaymentResult.tabbyPayment;
    }
  }

  await Payment.dal.updateOne({ filter: { _id: paymentId }, update: paymentChanges });
}


export default closeTabbyPayment;