import Bluebird from 'bluebird';
import Payment, { IPayment } from '@modules/payments/index.js';
import reportError from '@helpers/report.error.js';
import * as Numbers from '@helpers/numbers.js';
import Tabby from '@helpers/tabby/index.js';

async function captureTabbyPayment ({ paymentId, amountToCapture }: { paymentId: IPayment['_id'], amountToCapture: number }) {
  const payment = await Payment.dal.findOne({
    filter: { _id: paymentId, method: 'tabby' },
    select: 'amountToCapture capturedAmount tabby',
    lean: true
  });

  if (!payment) {
    return { case: 4, message: 'Payment not found.' };
  }

  amountToCapture = Math.min(amountToCapture, payment.amountToCapture);

  if (amountToCapture <= 0) {
    return { case: 3, message: 'Already captured all amounts.' };
  }

  const captureResult = await Tabby.capturePayment({ tabbyPaymentId: payment.tabby.id, amount: amountToCapture });
  if (captureResult.case !== 1) {
    const err = new Error(`Could not capture tabby payment ${payment._id}`);
    err.metadata = { paymentId, amountToCapture };
    reportError(err);
    return { case: 2, message: 'Could not capture tabby payment', captureResult };
  }

  const newAmountToCapture = Numbers.toFixedNumber(payment.amountToCapture - amountToCapture);
  const newCapturedAmount = Numbers.toFixedNumber(payment.capturedAmount + amountToCapture);

  await Bluebird.delay(5000);

  await Promise.all([
    newAmountToCapture <= 0 && Payment.closeTabbyPayment({ paymentId }),
    Payment.dal.updateOne({
      filter: { _id: paymentId },
      update: { capturedAmount: newCapturedAmount, amountToCapture: newAmountToCapture, 'tabby.captures': captureResult.payment.captures }
    })
  ]);


  return { case: 1, message: 'Captured tabby amount successfully.', captureResult };
}


export default captureTabbyPayment;