import Payment, { IPayment, PaymentFor } from '@modules/payments/index.js';
import Tabby from '@helpers/tabby/index.js';
import { IUser } from '@modules/users/index.js';
import Application, { ApplicationStatus, IApplication } from '@modules/applications/index.js';
import { UpdateQuery } from 'mongoose';
import Invoice from '@modules/invoices/index.js';

async function verifyTabbyPayment ({ tabbyPaymentId, userId, tabbyPaymentPlan, app }: IVerifyTabbyPaymentParameters) {
  const verificationResult = await Tabby.getPayment({ paymentId: tabbyPaymentId });
  const { tabbyPayment } = verificationResult;


  if (verificationResult.case !== 1) {
    const err = new Error(tabbyPayment.error);
    err.metadata = { verificationResult };
    err.message = tabbyRejectionReason(tabbyPayment);
    throw err;
  }

  await Payment.throwIfPaymentAlreadyExists({
    foreignPaymentId: tabbyPayment.id,
    method: 'tabby'
  });

  const application = await Application.dal.findOne({
    filter: {
      customId: tabbyPayment.order.reference_id,
      userId
    },
    select: 'opportunityId',
    populate: {
      path: 'opportunityId',
      select: 'title experienceGuideURL locationLink workHours',
      populate: {
        path: 'companyId',
        select: 'name slug'
      }
    },
    lean: true
  });
  if (!application) {
    throw new Error('Application Not Found.');
  }


  const payment = await Payment.dal.create({
    paymentFor: PaymentFor.APPLICATION_FEES,
    method: 'tabby',
    applicationId: application._id,
    tabbyPaymentPlan,
    tabby: tabbyPayment,
    userId,
    amount: tabbyPayment.amount,
    paidAt: new Date()
  });

  const applicationUpdate: UpdateQuery<IApplication> = {};

  applicationUpdate.paidApplicationFees = tabbyPayment.amount;
  applicationUpdate.applicationFeesPaidAt = new Date();
  applicationUpdate.status = ApplicationStatus.PAID_APPLICATION_FEES;

  await Application.dal.updateOne({
    filter: { _id: application._id },
    update: applicationUpdate
  });

  const { invoice } = await Invoice.add({ applicationId: application._id });
  if (invoice && app) {
    await Invoice.generatePDF({ invoiceId: invoice._id, app });
    await Invoice.sendInvoice({ invoiceId: invoice._id, email: '' });
  }


  return { case: 1, message: 'Application paid successfully.', applicationId: application._id, paymentId: payment._id };
}


export default verifyTabbyPayment;

function tabbyRejectionReason (tabbyPayment) {
  if (!tabbyPayment) {
    return 'unknown_error';
  }

  if (tabbyPayment.is_expired || tabbyPayment.status === 'EXPIRED') {
    return 'expired';
  }

  if (tabbyPayment.status === 'REJECTED') {
    return 'rejected';
  }

  if (tabbyPayment.status === 'canceled') {
    return 'canceled';
  }
  return 'unknown_error';

}
interface IVerifyTabbyPaymentParameters {
  tabbyPaymentId: IPayment['tabby']['id'];
  userId: IUser['_id'];
  tabbyPaymentPlan?: IPayment['tabbyPaymentPlan'];
  app?: any;
}