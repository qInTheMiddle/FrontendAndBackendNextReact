export default function invokeRolesPolicies (acl) {
  acl.allow([
    {
      roles: ['applicant'],
      allows: [
        { resources: '/api/applicant/payments/tap/create/', permissions: 'post' },
        { resources: '/api/applicant/payments/tap/verify/', permissions: 'post' },
        { resources: '/api/applicant/payments/tabby/create/', permissions: 'post' },
        { resources: '/api/applicant/payments/tabby/verify/', permissions: 'post' },
        { resources: 'api/applicant/payments/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
        { resources: '/api/applicant/payments/:paymentId/view/', permissions: 'get' }
      ]
    }
  ]);
}