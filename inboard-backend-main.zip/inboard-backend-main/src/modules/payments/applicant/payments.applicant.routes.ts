import express, { Application } from 'express';
import getRateLimiter from '@helpers/get.rate.limiter.js';
import isAllowed from '@helpers/is.allowed.js';
import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
const jsonParser = express.json();
const rateLimiter = getRateLimiter({ windowMs: 2000, max: 1 });

export default function (app: Application) {
  app.post('/api/applicant/payments/tap/create/', isAllowed, jsonParser, rateLimiter, makeCallback(controllers.createTap));
  app.post('/api/applicant/payments/tap/verify/', isAllowed, jsonParser, rateLimiter, makeCallback(controllers.verifyTap));
  app.post('/api/applicant/payments/tabby/create/', isAllowed, jsonParser, rateLimiter, makeCallback(controllers.createTabby));
  app.post('/api/applicant/payments/tabby/verify/', isAllowed, jsonParser, rateLimiter, makeCallback(controllers.verifyTabby));
  app.get('/api/applicant/payments/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/applicant/payments/:paymentId/view/', isAllowed, makeCallback(controllers.view));
}