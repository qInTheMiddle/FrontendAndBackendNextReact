import { Request, Response } from 'express';
import Payment from '@modules/payments/index.js';
import calculatePagesCount from '@helpers/calculate.pages.count.js';

export default async (req: Request, res: Response) => {
  const sortBy = req.params.sortBy || '-createdAt';
  const limit = Math.min(Number(req.params.limit) || 30, 100);
  const currentPage = parseInt(req.params.page) || 1;

  const [payments, paymentsCount] = await Promise.all([
    Payment.dal.find({
      filter: { ...req.query, userId: req.user._id },
      populate: [
        { path: 'opportunityId' },
        { path: 'userId' }
      ],
      sort: sortBy,
      paginate: { documentsPerPage: limit, page: currentPage },
      lean: true
    }),
    Payment.Model.countDocuments(req.query)
  ]);
  const pagesCount = calculatePagesCount({ documentsCount: paymentsCount, documentsPerPage: limit });

  return res.status(200).json({
    payments,
    paymentsCount,
    pagesCount
  });
};