export { default as createTap } from './payments.applicant.create.tap.controller.js';
export { default as verifyTap } from './payments.applicant.verify.tap.controller.js';
export { default as view } from './payments.applicant.view.controller.js';
export { default as list } from './payments.applicant.list.controller.js';
export { default as createTabby } from './payments.applicant.create.tabby.controller.js';
export { default as verifyTabby } from './payments.applicant.verify.tabby.controller.js';