import Tap from '@helpers/tap/index.js';
import { Request, Response } from 'express';
import { PaymentFor } from '@modules/payments/index.js';
import Application, { ApplicationStatus } from '@modules/applications/index.js';
import Opportunity from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    applicationId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { applicationId } = body;

  const application = await Application.dal.findOne({
    filter: { _id: applicationId, userId: actingUser._id },
    populate: { path: 'userId', select: 'firstName lastName email mobileCC mobile' },
    lean: true
  });
  if (!application) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }

  const opportunity = await Opportunity.dal.findOne({
    filter: { _id: application.opportunityId, isActive: true },
    select: 'availableSeats acceptedCount',
    lean: true
  });
  if (!opportunity) {
    return res.status(404).json({ message: 'Opportunity Not Found.' });
  }


  throwIfInvalidStatus({ applicationStatus: application.status, applicationId: application._id });
  throwIfInvalidFeesPayment({
    applicationId,
    paidApplicationFees: application.paidApplicationFees
  });

  const amount = application.applicationFees;

  const user = application.userId;

  const tapCreatePaymentResult = await Tap.createPayment({
    amount,
    paymentFor: PaymentFor.APPLICATION_FEES,
    applicationId,
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    mobileCC: user.mobileCC,
    mobile: user.mobile,
    userId: user._id
  });

  return res.status(tapCreatePaymentResult.statusCode).json({
    message: tapCreatePaymentResult.message,
    paymentUrl: tapCreatePaymentResult.paymentUrl
  });
};

function throwIfInvalidStatus ({ applicationStatus, applicationId }) {
  if (
    applicationStatus !== ApplicationStatus.DRAFT
  ) {
    const err = new Error('Invalid application status');
    err.metadata = { applicationId, applicationStatus };
    throw err;
  }
}

function throwIfInvalidFeesPayment ({ applicationId, paidApplicationFees }) {
  const hasPaidApplicationFees = Boolean(paidApplicationFees);
  if (hasPaidApplicationFees) {
    const err = new Error('Invalid fees payment');
    err.metadata = { applicationId, paidApplicationFees };
    throw err;
  }
}