import { Request, Response } from 'express';
import Payment from '@modules/payments/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    paymentId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const application = await Payment.dal.findOne({
    filter: { _id: params.paymentId, userId: actingUser._id },
    populate: [
      { path: 'opportunityId' },
      { path: 'userId' }
    ],
    lean: true
  });
  if (!application) {
    return res.status(404).json({ message: 'Payment Not Found.' });
  }

  return res.status(200).json({ application });
};