import User from '@modules/users/index.js';
import Payment from '@modules/payments/index.js';
import Application, { ApplicationStatus } from '@modules/applications/index.js';
import Tabby from '@helpers/tabby/index.js';
import { Request, Response } from 'express';
import Opportunity from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import moment from 'moment';

const validationSchema = {
  body: Joi.object().required().keys({
    applicationId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { applicationId } = body;

  const application = await Application.dal.findOne({
    filter: { _id: applicationId, userId: actingUser._id },
    populate: { path: 'userId', select: 'firstName lastName email mobileCC mobile' },
    lean: true
  });
  if (!application) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }

  const opportunity = await Opportunity.dal.findOne({
    filter: { _id: application.opportunityId, isActive: true },
    select: 'availableSeats acceptedCount title applicationFees',
    lean: true
  });
  if (!opportunity) {
    return res.status(404).json({ message: 'Opportunity Not Found.' });
  }


  throwIfInvalidStatus({ applicationStatus: application.status, applicationId: application._id });
  throwIfInvalidFeesPayment({
    applicationId,
    paidApplicationFees: application.paidApplicationFees
  });

  const amount = application.applicationFees;

  const user = application.userId;
  const name = `${user.firstName} ${user.lastName}`;

  const previousPayments = await Payment.dal.find({
    filter: { userId: user._id },
    select: 'amount applicationId paidAt createdAt method',
    populate: { path: 'applicationId', select: 'customId' },
    lean: true
  });
  const orderHistory = previousPayments.map(({ amount, applicationId, paidAt, createdAt, _id }) => ({
    amount: amount.toFixed(2),
    reference_id: applicationId?.customId || _id,
    purchased_at: moment(createdAt || paidAt).format(),
    status: paidAt ? 'complete' : 'pending'
  }));

  const userDcoument = await User.dal.findOne({ filter: { _id: actingUser._id }, select: 'createdAt', lean: true });

  const tabbySession = await Tabby.createSession({
    amount,
    buyer: {
      phone: `00${user.mobileCC}${user.mobile}`,
      email: user.email,
      name
    },
    tax_amount: 0,
    shipping_amount: 0,
    reference_id: application.customId,
    registeredSince: moment(userDcoument.createdAt).toISOString(),
    items: [{
      reference_id: applicationId.toString(),
      title: opportunity.title.arabic,
      quantity: 1,
      unit_price: opportunity.applicationFees,
      category: 'training-service-fees'
    }],
    metadata: {
      order_id: applicationId.toString()
    },
    orderHistory
  });


  if (!tabbySession?.id) {
    throw new Error('Can not create tabby session');
  }


  const [{ web_url: installmentsWebUrl }] = tabbySession.configuration.available_products?.installments || [{ web_url: '' }];
  return res.json({
    case: 1,
    sessionId: tabbySession.id,
    availableProducts: Object.keys(tabbySession.configuration.available_products),
    installmentsWebUrl,
    rejectionReason: tabbySession.rejection_reason_code
  });
};
function throwIfInvalidStatus ({ applicationStatus, applicationId }) {
  if (applicationStatus !== ApplicationStatus.DRAFT) {
    const err = new Error('Invalid application status');
    err.metadata = { applicationId, applicationStatus };
    throw err;
  }
}

function throwIfInvalidFeesPayment ({ applicationId, paidApplicationFees }) {
  const hasPaidApplicationFees = Boolean(paidApplicationFees);
  if (hasPaidApplicationFees) {
    const err = new Error('Invalid fees payment');
    err.metadata = { applicationId, paidApplicationFees };
    throw err;
  }
}