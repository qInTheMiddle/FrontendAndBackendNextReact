import { Request, Response } from 'express';
import Payment from '@modules/payments/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    tapPaymentId: Joi.string().required()
  })
};

export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { statusCode, message, paymentId } = await Payment.verifyTapPayment({
    tapPaymentId: body.tapPaymentId,
    userId: actingUser._id,
    app: req.app
  });

  return res.status(statusCode).json({ message, paymentId });
};