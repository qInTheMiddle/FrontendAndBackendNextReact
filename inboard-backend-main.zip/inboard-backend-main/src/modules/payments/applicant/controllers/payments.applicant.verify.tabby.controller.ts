import Payment from '@modules/payments/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  body: Joi.object().required().keys({
    tabbyPaymentId: Joi.string().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { tabbyPaymentId } = body;
  const userId = actingUser._id;


  const verificationResult = await Payment.verifyTabby({ userId, tabbyPaymentId, app: req.app });
  return res.json(verificationResult);
};