import mongoose from 'mongoose';
import { IPayment, PaymentFor, TabbyPaymentPlan } from '@modules/payments/index.js';
import { CounterFor, CounterPrefix } from '@modules/counters/index.js';
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';

import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;

const paymentSchema = new Schema<IPayment>({
  userId: { type: Schema.Types.ObjectId, ref: Model.USER, required: true },
  applicationId: { type: Schema.Types.ObjectId, ref: Model.APPLICATION, required: true },
  invoiceId: { type: Schema.Types.ObjectId, ref: Model.INVOICE },
  creditNoteId: { type: Schema.Types.ObjectId, ref: Model.CREDIT_NOTE },

  paymentFor: { type: String, required: true, enum: PaymentFor },

  amount: { type: Number, required: true, min: 0 },
  paidAt: Date,

  method: { type: String, enum: ['tabby', 'tamara', 'tap'], default: 'tap' },

  tap: getTapSchema(),

  tabbyPaymentPlan: { type: String, enum: TabbyPaymentPlan },
  tabby: getTabbySchema(),

  capturedAmount: {
    type: Number,
    default () {
      const { method } = this;
      return ['tabby', 'tamara'].includes(method) ? 0 : undefined;
    }
  },
  amountToCapture: {
    type: Number,
    default () {
      const { method } = this;
      return ['tabby', 'tamara'].includes(method) ? this.amount : undefined;
    }
  },
  isTabbyPaymentClosed: {
    type: Boolean,
    default () {
      return this.method === 'tabby' ? false : undefined;
    }
  },
  isRefunded: Boolean,
  refundedByUserId: { type: Schema.Types.ObjectId, ref: Model.USER },
  refundedAmount: { type: Number, default: 0 },
  refundedAt: Date
});

injectCustomIdCreator({ schema: paymentSchema, documentName: CounterFor.PAYMENT, prefix: CounterPrefix.PAYMENT });

export default mongoose.model<IPayment>(Model.PAYMENT, paymentSchema);

function getTapSchema () {
  return {
    id: { type: String },
    object: { type: String },
    live_mode: { type: Boolean },
    api_version: { type: String },
    method: { type: String },
    status: { type: String },
    amount: { type: Number },
    currency: { type: String },
    threeDSecure: { type: Boolean },
    card_threeDSecure: { type: Boolean },
    save_card: { type: Boolean },
    merchant_id: { type: String },
    product: { type: String },
    description: { type: String },
    metadata: {
      applicationId: { type: String },
      paymentFor: { type: String },
      userId: { type: String }
    },
    transaction: {
      authorization_id: { type: String },
      timezone: { type: String },
      created: { type: String },
      expiry: {
        period: { type: Number },
        type: { type: String }
      },
      asynchronous: { type: Boolean },
      amount: { type: Number },
      currency: { type: String }
    },
    reference: {
      track: { type: String },
      payment: { type: String },
      gateway: { type: String },
      acquirer: { type: String }
    },
    response: {
      code: { type: String },
      message: { type: String }
    },
    security: {
      threeDSecure: {
        id: { type: String },
        status: { type: String }
      }
    },
    acquirer: {
      response: {
        code: { type: String },
        message: { type: String }
      }
    },
    gateway: {
      response: {
        code: { type: String },
        message: { type: String }
      }
    },
    card: {
      object: { type: String },
      first_six: { type: String },
      scheme: { type: String },
      brand: { type: String },
      last_four: { type: String }
    },
    receipt: {
      id: { type: String },
      email: { type: Boolean },
      sms: { type: Boolean }
    },
    customer: {
      id: { type: String },
      first_name: { type: String },
      last_name: { type: String },
      email: { type: String },
      phone: {
        country_code: { type: String },
        number: { type: String }
      }
    },
    merchant: {
      country: { type: String },
      currency: { type: String },
      id: { type: String }
    },
    source: {
      object: { type: String },
      type: { type: String },
      payment_type: { type: String },
      payment_method: { type: String },
      channel: { type: String },
      id: { type: String }
    },
    redirect: {
      status: { type: String },
      url: { type: String }
    },
    activities: [{
      id: { type: String },
      object: { type: String },
      created: { type: Number },
      status: { type: String },
      currency: { type: String },
      amount: { type: Number },
      remarks: { type: String }
    }],
    auto_reversed: { type: Boolean }
  };
}

function getTabbySchema () {
  return {
    id: String,
    created_at: String,
    expires_at: String,
    amount: String,
    currency: String,
    description: String,
    status: String,
    test: Boolean,
    buyer: {
      phone: String,
      email: String,
      name: String,
      dob: String
    },
    buyer_history: {
      registered_since: String,
      loyalty_level: Number,
      wishlist_count: Number
    },
    order: {
      tax_amount: String,
      shipping_amount: String,
      discount_amount: String,
      updated_at: String,
      reference_id: String,
      items: Array
    },
    order_history: Array,
    shipping_address: {
      city: String,
      address: String,
      zip: String
    },
    captures: Array,
    refunds: Array
  };
}