import startCronJob from '@helpers/start.cron.job.js';
import Payment from '@modules/payments/index.js';

startCronJob({ pattern: '*/15 * * * *', functionToRun: Payment.verifyMissedTabbyPayments, logDescription: true });