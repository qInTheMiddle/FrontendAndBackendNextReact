import { Application } from 'express';
import { Acl } from 'acl';
import routes from './payments.routes.js';
import policies from './payments.policies.js';
import './payments.cron.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}