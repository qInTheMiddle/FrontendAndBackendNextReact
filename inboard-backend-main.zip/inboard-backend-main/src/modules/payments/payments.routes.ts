import { Application } from 'express';
import applicantRoutes from './applicant/payments.applicant.routes.js';
import teamRoutes from './team/payments.team.routes.js';

export default function (app: Application) {
  applicantRoutes(app);
  teamRoutes(app);
}