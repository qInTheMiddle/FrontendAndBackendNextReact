import { Request, Response } from 'express';
import { FilterQuery } from 'mongoose';
import Opportunity, { IOpportunity } from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    opportunityId: Joi.mongoId().required(),
    slug: Joi.slug().required()
  })
};


export default async (req: Request, res: Response) => {
  const { body } = validateRequest(req, validationSchema, { warn: true });

  const filter: FilterQuery<IOpportunity> = { slug: body.slug };
  if (body.opportunityId) {
    filter._id = { $ne: body.opportunityId };
  }

  const opportunityExists = await Opportunity.dal.exists({ filter });
  if (opportunityExists) {
    return res.status(409).json({ message: 'Slug Already Exists.' });
  }

  return res.status(200).json();
};