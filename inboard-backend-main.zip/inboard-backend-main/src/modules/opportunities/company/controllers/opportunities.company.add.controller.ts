import User from '@modules/users/index.js';
import Opportunity, { OpportunityCategory } from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
import slugify from 'slugify';

const validationSchema = {
  body: Joi.object().required().keys({
    opportunity: Joi.object().required().keys({
      locationCity: Joi.string(),
      locationLink: Joi.string(),
      careerLevel: Joi.string().required(),
      educationLevel: Joi.string().required(),
      startingDate: Joi.date().required(),
      opportunityDurationInDays: Joi.number().required(),
      title: Joi.object().required().keys({
        arabic: Joi.string().required(),
        english: Joi.string()
      }),
      workHours: Joi.object().keys({
        from: Joi.number(),
        to: Joi.number()
      }),
      workDays: Joi.object().keys({
        from: Joi.number(),
        to: Joi.number()
      }),
      description: Joi.object().required().keys({
        arabic: Joi.string().required(),
        english: Joi.string()
      }),
      dailyWork: Joi.object().keys({
        arabic: Joi.string(),
        english: Joi.string()
      }),

      experienceGuideURL: Joi.string(),
      mentor: Joi.object().keys({
        name: Joi.object().keys({
          firstName: Joi.string(),
          lastName: Joi.string()
        }),
        email: Joi.string(),
        phoneNumber: Joi.string()
      }),

      skills: Joi.object().keys({
        arabic: Joi.string(),
        english: Joi.string()
      }),
      category: Joi.string().valid(...Object.values(OpportunityCategory)).required(),
      opportunityFees: Joi.number().required(),
      availableSeats: Joi.number().required(),
      isActive: Joi.boolean()
    })
  })
};


export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const user = await User.dal.findOne({ filter: { _id: actingUser._id }, select: 'companyId', lean: true });
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  if (!user.companyId) {
    return res.status(404).json({ message: 'User is not associated with a company.' });
  }

  const slug = await generateSlug(body.opportunity.title.arabic);

  body.opportunity.slug = slug;
  body.opportunity.companyId = user.companyId;
  body.opportunity.applicationFees = body.opportunity.opportunityFees;
  const opportunity = await Opportunity.dal.create(body.opportunity);

  return res.status(201).json({ opportunityId: opportunity._id });
};

async function generateSlug (title: string) {

  const slug = slugify(title);

  const matchingSlugs = await Opportunity.Model.countDocuments({ slug: new RegExp(`^${slug}`) });
  if (matchingSlugs) {
    return `${slug}-${matchingSlugs + 1}`;
  }

  return `${slug}-1`;
}