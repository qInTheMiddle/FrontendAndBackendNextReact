export { default as view } from './opportunities.company.view.controller.js';
export { default as list } from './opportunities.company.list.controller.js';
export { default as add } from './opportunities.company.add.controller.js';
export { default as validateSlug } from './opportunities.company.validate.slug.controller.js';
export { default as update } from './opportunities.company.update.controller.js';