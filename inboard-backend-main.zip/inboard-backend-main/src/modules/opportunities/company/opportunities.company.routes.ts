import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.get('/api/company/opportunities/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/company/opportunities/:opportunityId/view/', isAllowed, makeCallback(controllers.view));
  app.post('/api/company/opportunities/add/', isAllowed, jsonParser, makeCallback(controllers.add));
  app.post('/api/company/opportunities/validate-slug/', isAllowed, jsonParser, makeCallback(controllers.validateSlug));
  app.put('/api/company/opportunities/:opportunityId/update/', isAllowed, jsonParser, makeCallback(controllers.update));
}