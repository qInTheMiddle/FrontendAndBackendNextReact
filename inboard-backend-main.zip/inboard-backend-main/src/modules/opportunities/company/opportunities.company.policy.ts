export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['company-employee'],
    allows: [
      { resources: '/api/company/opportunities/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/company/opportunities/:opportunityId/view/', permissions: 'get' },
      { resources: '/api/company/opportunities/add/', permissions: 'post' },
      { resources: '/api/company/opportunities/validate-slug/', permissions: 'post' },
      { resources: '/api/company/opportunities/:opportunityId/update/', permissions: 'put' }
    ]
  }]);
}