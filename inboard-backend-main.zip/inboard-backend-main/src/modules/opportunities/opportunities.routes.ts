import { Application } from 'express';
import applicantRoutes from './applicant/opportunities.applicant.routes.js';
import teamRoutes from './team/opportunities.team.routes.js';
import companyRoutes from './company/opportunities.company.routes.js';

export default function (app: Application) {
  applicantRoutes(app);
  teamRoutes(app);
  companyRoutes(app);
}