import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';
import { CounterPrefix } from '@modules/counters/index.js';
import { ICompany } from '@modules/companies/index.js';

export interface IOpportunity<Populate = true> extends IMongo {

  companyName: string;
  companyLogo?: string;
  companyLocation?: string;
  companyWebsite?: string;
  companyEmail?: string;
  companyPhone?: string;
  companySize?: string;
  companyInformation?: {
    arabic: string;
    english?: string
  };
  companyId?: PopulatedDoc<ICompany, Populate>;
  locationCity: string;
  locationLink?: string;

  careerLevel: CareerLevel;
  educationLevel: string;
  opportunityDurationInDays: number;
  title: {
    arabic: string;
    english?: string
  };
  workHours: { from: number, to: number };
  workDays: { from: number, to: number };
  description: {
    arabic: string;
    english?: string
  };
  dailyWork?: {
    arabic: string;
    english?: string
  };

  skills?: {
    arabic: string;
    english?: string
  };

  department?: {
    arabic: string;
    english?: string
  };

  category: OpportunityCategory;

  slug: string;

  applicationFees: number;
  opportunityFees: number;

  availableSeats: number;
  applicationsCount?: number;
  acceptedCount?: number;
  rejectedCount?: number;

  isActive?: boolean;

  startingDate?: Date;

  experienceGuideURL?: string;
  mentor?: {
    name: {
      firstName: string;
      lastName: string;
    };
    phoneNumber: string;
    email: string;
  };

  customId: `${CounterPrefix.OPPORTUNITY}${number}`;
}

export enum OpportunityCategory {
  CREATIVE = 'creative',
  DIGITAL_MARKETING = 'digital-marketing',
  PRODUCTION = 'production',
  MARKETING = 'marketing',
  SALES = 'sales',
  ADVERTISING = 'advertising',
  PROJECT_MANAGEMENT = 'project-management',
  ACCOUNTING = 'accounting',
  EVENT_MANAGEMENT = 'event-management',
  PUBLIC_RELATIONS = 'public-relations',
  HUMAN_RESOURCES = 'human-resources',
  BUSINESS_ADMINISTRATION = 'business-administration',
}
export enum CareerLevel {
  ENTRY_LEVEL = 'entry-level',
  MIDDLE_LEVEL = 'mid-level',
  SENIOR_LEVEL = 'senior-level',
}
export enum EducationLevel {
  HIGH_SCHOOL = 'high-school',
  SOME_COLLEGE_NO_DEGREE = 'some-college-no-degree',
  BACHELORS_DEGREE = 'bachelors-degree',
  MASTERS_DEGREE = 'masters-degree',
  PHD = 'phd',
}