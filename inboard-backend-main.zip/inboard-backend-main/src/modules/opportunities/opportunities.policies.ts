import applicantPolicies from './applicant/opportunities.applicant.policy.js';
import teamPolicies from './team/opportunities.team.policy.js';
import companyPolicies from './company/opportunities.company.policy.js';

export default function invokeRolesPolicies (acl) {
  applicantPolicies(acl);
  teamPolicies(acl);
  companyPolicies(acl);
}