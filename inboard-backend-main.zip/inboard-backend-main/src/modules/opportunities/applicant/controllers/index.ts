export { default as view } from './opportunities.applicant.view.controller.js';
export { default as list } from './opportunities.applicant.list.controller.js';