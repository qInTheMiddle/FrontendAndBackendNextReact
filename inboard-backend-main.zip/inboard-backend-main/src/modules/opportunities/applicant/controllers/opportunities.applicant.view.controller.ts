import Opportunity, { IOpportunity } from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
import isMongoId from '@helpers/is.mongo.id.js';
import { FilterQuery } from 'mongoose';
const validationSchema = {
  params: Joi.object().required().keys({
    opportunityIdOrSlug: Joi.alternatives().required().try(
      Joi.mongoId(),
      Joi.slug()
    )
  })
};


export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });

  const filter: FilterQuery<IOpportunity> = {
    isActive: true,
    availableSeats: { $gt: 0 }
  };

  if (isMongoId(params.opportunityIdOrSlug)) {
    filter._id = params.opportunityIdOrSlug;
  } else {
    filter.slug = params.opportunityIdOrSlug;
  }

  const opportunity = await Opportunity.dal.findOne({
    filter,
    populate: [
      { path: 'companyId' }
    ],
    lean: true
  });

  if (!opportunity) {
    return res.status(404).json({ message: 'Opportunity Not Found.' });
  }

  return res.status(200).json({ opportunity });
};