import { Request, Response } from 'express';
import Opportunity from '@modules/opportunities/index.js';
import calculatePagesCount from '@helpers/calculate.pages.count.js';

export default async (req: Request, res: Response) => {
  const sortBy = req.params.sortBy || '-createdAt';
  const limit = Math.min(Number(req.params.limit) || 30, 100);
  const currentPage = parseInt(req.params.page) || 1;
  const { query } = req;
  const [opportunities, opportunitiesCount] = await Promise.all([
    Opportunity.dal.find({
      filter: { ...query, isActive: true, availableSeats: { $gte: 0 } },
      sort: sortBy,
      paginate: { documentsPerPage: limit, page: currentPage },
      populate: [
        { path: 'companyId' }
      ],
      lean: true
    }),
    Opportunity.Model.countDocuments({ ...query, isActive: true, availableSeats: { $gte: 0 } })
  ]);

  const pagesCount = calculatePagesCount({ documentsCount: opportunitiesCount, documentsPerPage: limit });

  return res.status(200).json({
    opportunities,
    opportunitiesCount,
    pagesCount
  });
};