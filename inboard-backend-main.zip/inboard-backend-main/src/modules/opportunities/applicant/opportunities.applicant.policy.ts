export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['applicant'],
    allows: [
      { resources: '/api/applicant/opportunities/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/applicant/opportunities/:opportunityIdOrSlug/view/', permissions: 'get' }
    ]
  }]);
}