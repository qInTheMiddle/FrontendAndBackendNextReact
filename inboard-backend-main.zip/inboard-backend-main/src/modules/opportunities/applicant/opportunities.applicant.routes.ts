import { Application } from 'express';
import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';

export default function (app: Application) {
  app.get('/api/applicant/opportunities/list/sortBy-:sortBy/:limit/:page/', makeCallback(controllers.list));
  app.get('/api/applicant/opportunities/:opportunityIdOrSlug/view/', makeCallback(controllers.view));
}