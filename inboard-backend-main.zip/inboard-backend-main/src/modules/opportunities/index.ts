export * from './opportunities.model.interface.js';

import Model from './opportunities.model.js';
import DAL from '@helpers/dal.js';

const dal = new DAL(Model);

export default {
  Model,
  dal
};