import mongoose from 'mongoose';
import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;
import { IOpportunity, OpportunityCategory, CareerLevel, EducationLevel } from '@modules/opportunities/index.js';
import { CounterPrefix, CounterFor } from '@modules/counters/index.js';
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';

const opportunitySchema = new Schema<IOpportunity>({
  companyId: { type: Schema.Types.ObjectId, ref: Model.COMPANY, required: true },

  locationCity: { type: String, required: true },
  locationLink: { type: String },
  careerLevel: { type: String, required: true, enum: CareerLevel, default: CareerLevel.ENTRY_LEVEL },
  educationLevel: { type: String, required: true, enum: EducationLevel, default: EducationLevel.BACHELORS_DEGREE },
  opportunityDurationInDays: { type: Number, required: true },
  title: getArabicAndEnglish({ requireArabic: true, requireEnglish: false }),

  workHours: { from: { type: Number, min: 0, max: 23, default: 8 }, to: { type: Number, min: 0, max: 23, default: 16 } },
  workDays: { from: { type: Number, min: 0, max: 6, default: 0 }, to: { type: Number, min: 0, max: 6, default: 4 } },
  description: getArabicAndEnglish({ requireArabic: true, requireEnglish: false }),
  dailyWork: getArabicAndEnglish({ requireArabic: false, requireEnglish: false }),

  skills: getArabicAndEnglish({ requireArabic: false, requireEnglish: false }),

  category: { type: String, enum: OpportunityCategory, default: OpportunityCategory.CREATIVE },

  slug: { type: String, required: true },

  applicationFees: { type: Number },
  opportunityFees: { type: Number, required: true },

  availableSeats: { type: Number, required: true },
  applicationsCount: { type: Number, default: 0 },
  acceptedCount: { type: Number, default: 0 },
  rejectedCount: { type: Number, default: 0 },

  startingDate: { type: Date },

  experienceGuideURL: { type: String },
  mentor: {
    name: {
      firstName: { type: String },
      lastName: { type: String }
    },
    phoneNumber: { type: String },
    email: { type: String }
  },

  isActive: { type: Boolean }
});

opportunitySchema.index({ userId: -1 });
opportunitySchema.index({ slug: -1 }, { unique: true });

injectCustomIdCreator({ schema: opportunitySchema, documentName: CounterFor.OPPORTUNITY, prefix: CounterPrefix.OPPORTUNITY });

export default mongoose.model<IOpportunity>(Model.OPPORTUNITY, opportunitySchema);

function getArabicAndEnglish ({ requireArabic = false, requireEnglish = false }) {
  return {
    arabic: { type: String, required: requireArabic },
    english: { type: String, required: requireEnglish }
  };
}