import { Application } from 'express';
import { Acl } from 'acl';
import routes from './opportunities.routes.js';
import policies from './opportunities.policies.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}