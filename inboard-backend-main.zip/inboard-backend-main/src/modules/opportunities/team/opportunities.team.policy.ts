export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/opportunities/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/team/opportunities/:opportunityId/view/', permissions: 'get' },
      { resources: '/api/team/opportunities/add/', permissions: 'post' },
      { resources: '/api/team/opportunities/validate-slug/', permissions: 'post' },
      { resources: '/api/team/opportunities/:opportunityId/update/', permissions: 'put' }
    ]
  }]);
}