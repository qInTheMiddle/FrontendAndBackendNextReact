import Opportunity from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';
const validationSchema = {
  params: Joi.object().required().keys({
    opportunityId: Joi.mongoId().required()
  })
};


export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });

  const opportunity = await Opportunity.dal.findOne({
    filter: { _id: params.opportunityId },
    populate: [
      { path: 'companyId' }
    ],
    lean: true
  });

  if (!opportunity) {
    return res.status(404).json({ message: 'Opportunity Not Found.' });
  }

  return res.status(200).json({ opportunity });
};