import Opportunity, { OpportunityCategory } from '@modules/opportunities/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
import { Request, Response } from 'express';

const validationSchema = {
  params: Joi.object().required().keys({
    opportunityId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    opportunity: Joi.object().required().keys({
      companyId: Joi.mongoId().required(),
      locationCity: Joi.string(),
      locationLink: Joi.string(),
      careerLevel: Joi.string().required(),
      educationLevel: Joi.string().required(),
      startingDate: Joi.date().required(),
      opportunityDurationInDays: Joi.number().required(),
      title: Joi.object().required().keys({
        arabic: Joi.string().required(),
        english: Joi.string()
      }),
      workHours: Joi.object().keys({
        from: Joi.number(),
        to: Joi.number()
      }),
      workDays: Joi.object().keys({
        from: Joi.number(),
        to: Joi.number()
      }),
      description: Joi.object().required().keys({
        arabic: Joi.string().required(),
        english: Joi.string()
      }),
      dailyWork: Joi.object().keys({
        arabic: Joi.string(),
        english: Joi.string()
      }),
      mentor: Joi.object().keys({
        name: Joi.object().keys({
          firstName: Joi.string(),
          lastName: Joi.string()
        }),
        email: Joi.string(),
        phoneNumber: Joi.string()
      }),
      skills: Joi.object().keys({
        arabic: Joi.string(),
        english: Joi.string()
      }),
      experienceGuideURL: Joi.string(),
      category: Joi.string().valid(...Object.values(OpportunityCategory)).required(),
      applicationFees: Joi.number().required(),
      opportunityFees: Joi.number().required(),
      availableSeats: Joi.number().required(),
      isActive: Joi.boolean()
    })
  })
};


export default async (req: Request, res: Response) => {
  const { body, params } = validateRequest(req, validationSchema, { warn: true });

  const updateResult = await Opportunity.dal.updateOne({
    filter: { _id: params.opportunityId },
    update: body.opportunity
  });
  if (!updateResult.modifiedCount) {
    return res.status(404).json({ message: 'Opportunity Not Found.' });
  }

  return res.status(204).json();
};