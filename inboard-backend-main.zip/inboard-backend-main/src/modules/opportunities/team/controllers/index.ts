export { default as view } from './opportunities.team.view.controller.js';
export { default as list } from './opportunities.team.list.controller.js';
export { default as add } from './opportunities.team.add.controller.js';
export { default as validateSlug } from './opportunities.team.validate.slug.controller.js';
export { default as update } from './opportunities.team.update.controller.js';