import mongoose from 'mongoose';
import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;
import { ICounter, CounterFor } from '@modules/counters/index.js';

const counterSchema = new Schema<ICounter>({
  counterFor: { type: String, required: true, enum: CounterFor },
  count: { type: Number, required: true, default: 0 }
});

counterSchema.index({ counterFor: 1 });

export default mongoose.model<ICounter>(Model.COUNTER, counterSchema);