import { IMongo } from '@helpers/mongo.interface.js';

export interface ICounter extends IMongo {
  counterFor: CounterFor;
  count: number;
}

export enum CounterFor {
  OPPORTUNITY = 'opportunity',
  APPLICATION = 'application',
  COMPANY = 'company',
  PAYMENT = 'payment',
  PAYMENT_CAPTURES = 'payment-captures',
  INVOICES = 'invoices',
  CREDIT_NOTE = 'credit-note',
}

export enum CounterPrefix {
  OPPORTUNITY = 'OP',
  APPLICATION = 'APP',
  COMPANY = 'CO',
  PAYMENT = 'P',
  PAYMENT_CAPTURES = 'PC',
  INVOICES = 'INV',
  CREDIT_NOTE = 'CN',
}