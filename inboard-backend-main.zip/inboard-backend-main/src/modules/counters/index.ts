export * from './counter.model.interface.js';

import Model from './counter.model.js';
import DAL from '@helpers/dal.js';

const dal = new DAL(Model);

export default {
  Model,
  dal
};