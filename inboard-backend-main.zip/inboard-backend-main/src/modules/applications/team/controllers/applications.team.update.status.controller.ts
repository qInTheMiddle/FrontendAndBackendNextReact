import { Request, Response } from 'express';
import Application, { ApplicationStatus } from '@modules/applications/index.js';
import reportError from '@helpers/report.error.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    applicationId: Joi.mongoId().required()
  }),
  body: Joi.object().required().keys({
    application: Joi.object().required().keys({
      status: Joi.string().required().valid(...Object.values(ApplicationStatus)),
      rejectionReason: Joi.when('status', { is: ApplicationStatus.REJECTED, then: Joi.string().required(), otherwise: Joi.forbidden() })
    })
  })
};

export default async (req: Request, res: Response) => {
  const { params, body } = validateRequest(req, validationSchema, { warn: true });

  const { statusCode, message } = await Application.updateStatus({
    applicationId: params.applicationId,
    status: body.application.status,
    rejectionReason: body.application.rejectionReason
  });
  if (statusCode !== 204) {
    return res.status(statusCode).json({ message });
  }

  Application.sendApplicantEmail({ applicationId: params.applicationId }).catch(reportError);

  return res.status(statusCode).json();
};