import { Request, Response } from 'express';
import Application from '@modules/applications/index.js';
import calculatePagesCount from '@helpers/calculate.pages.count.js';

export default async (req: Request, res: Response) => {
  const sortBy = req.params.sortBy || '-createdAt';
  const limit = Math.min(Number(req.params.limit) || 30, 100);
  const currentPage = parseInt(req.params.page) || 1;

  const [applications, applicationsCount] = await Promise.all([
    Application.dal.find({
      filter: {
        ...req.query
      },
      populate: [
        { path: 'opportunityId',
          populate: {
            path: 'companyId',
            select: 'name'
          }
        },
        { path: 'userId' }
      ],
      sort: sortBy,
      paginate: { documentsPerPage: limit, page: currentPage },
      lean: true
    }),
    Application.Model.countDocuments(req.query)
  ]);

  const pagesCount = calculatePagesCount({ documentsCount: applicationsCount, documentsPerPage: limit });

  return res.status(200).json({
    applications,
    applicationsCount,
    pagesCount
  });
};