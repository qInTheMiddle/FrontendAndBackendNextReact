export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/applications/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/team/applications/:applicationId/view/', permissions: 'get' },
      { resources: '/api/team/applications/:applicationId/update-status/', permissions: 'put' }
    ]
  }]);
}