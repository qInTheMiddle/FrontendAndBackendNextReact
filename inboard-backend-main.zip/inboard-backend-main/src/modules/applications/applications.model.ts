import mongoose from 'mongoose';
import { Model } from '@helpers/models.enum.js';
const { Schema } = mongoose;
import { IApplication, YearsOfExperience, ApplicationStatus } from '@modules/applications/index.js';
import { CounterFor, CounterPrefix } from '@modules/counters/index.js';
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';

const applicationschema = new Schema<IApplication>({
  userId: { type: Schema.Types.ObjectId, ref: Model.USER, required: true },
  opportunityId: { type: Schema.Types.ObjectId, ref: Model.OPPORTUNITY, required: true },
  companyId: { type: Schema.Types.ObjectId, ref: Model.COMPANY },

  yearsOfExperience: { type: String, enum: YearsOfExperience, required: true },
  cvUrl: { type: String, required: true },
  duration: { type: Number, required: false },
  expectedGoals: { type: String, max: 600 },

  status: { type: String, enum: ApplicationStatus, default: ApplicationStatus.DRAFT },

  applicationFees: { type: Number, required: true },
  opportunityFees: { type: Number, required: true },

  paidApplicationFees: { type: Number, default: 0 },
  applicationFeesPaidAt: { type: Date },
  paidOpportunityFees: { type: Number, default: 0 },
  opportunityFeesPaidAt: { type: Date },

  isTabbyCaptured: { type: Boolean, default: false },

  acceptedAt: { type: Date },

  rejectedAt: { type: Date },
  rejectionReason: { type: String }
});

applicationschema.index({ userId: -1 });
applicationschema.index({ userId: -1, opportunityId: -1 }, { unique: true });

injectCustomIdCreator({ schema: applicationschema, documentName: CounterFor.APPLICATION, prefix: CounterPrefix.APPLICATION });

export default mongoose.model<IApplication>(Model.APPLICATION, applicationschema);