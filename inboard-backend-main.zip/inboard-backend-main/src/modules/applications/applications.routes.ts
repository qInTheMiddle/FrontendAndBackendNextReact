import { Application } from 'express';
import applicantRoutes from './applicant/applications.applicant.routes.js';
import teamRoutes from './team/applications.team.routes.js';
import companyRoutes from './company/applications.company.routes.js';
export default function (app: Application) {
  applicantRoutes(app);
  teamRoutes(app);
  companyRoutes(app);
}