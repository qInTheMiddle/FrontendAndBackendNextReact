import applicantPolicies from './applicant/applications.applicant.policy.js';
import teamPolicies from './team/applications.team.policy.js';
import companyPolicies from './company/applications.company.policy.js';
export default function invokeRolesPolicies (acl) {
  applicantPolicies(acl);
  teamPolicies(acl);
  companyPolicies(acl);
}