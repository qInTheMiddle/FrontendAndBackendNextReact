import { Application } from 'express';
import { Acl } from 'acl';
import routes from './applications.routes.js';
import policies from './applications.policies.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}