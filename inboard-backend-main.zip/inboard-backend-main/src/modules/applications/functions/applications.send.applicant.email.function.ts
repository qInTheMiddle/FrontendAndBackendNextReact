import Application, { ApplicationStatus } from '@modules/applications/index.js';
import CONSTANTS from '@helpers/constants.js';
import sendEmail from '@helpers/send.email.js';
import moment from 'moment';

async function sendApplicantEmail ({ applicationId }) {
  const application = await Application.dal.findOne({
    filter: { _id: applicationId },
    select: 'status opportunityId userId rejectionReason',
    populate: [
      { path: 'userId', select: 'firstName lastName email' },
      {
        path: 'opportunityId',
        select: 'companyId title startingDate locationLink mentor workHours experienceGuideURL',
        populate: { path: 'companyId', select: 'name slug' }
      }
    ],
    lean: true
  });
  if (!application) {
    throw new Error(`Application ${applicationId} Not Found.`);
  }

  const user = application.userId;
  const opportunity = application.opportunityId;

  const { subject, templateId } = getEmailSubjectAndTemplateId({ status: application.status });

  if (subject && templateId) {
    await sendEmail({
      from: 'Hello Inboard<hello@inboard.sa>',
      to: user.email,
      subject,
      templateId,
      dynamicTemplateData: {
        applicationId: application._id,
        companyName: opportunity.companyId.name,
        opportunityTitle: opportunity.title.arabic,
        userFullName: `${user.firstName} ${user.lastName}`,
        rejectionReason: application.rejectionReason || '',
        startWorkDate: moment(opportunity.startingDate).format('DD-MM-YYYY'),
        locationLink: opportunity.locationLink,
        workHours: getWorkHours(opportunity.workHours),
        mentorName: opportunity.mentor?.name?.firstName || '',
        mentorNumber: opportunity.mentor?.phoneNumber || '',
        experienceGuide: opportunity.experienceGuideURL || ''
      }
    });
  }
}

export default sendApplicantEmail;

function getEmailSubjectAndTemplateId ({ status }) {
  switch (status) {
    case ApplicationStatus.AWAITING_INBOARD_INVERVIEW:
      return { subject: 'Inboard Team Interview', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.teamInterview };
    case ApplicationStatus.AWAITING_OPPORTUNITY_INVERVIEW:
      return { subject: 'Inboard Opportunity Interview', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.opportunityInterview };
    case ApplicationStatus.ACCEPTED:
      return { subject: 'Inboard Opportunity Accepted', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.opportunityPaid };
    case ApplicationStatus.REJECTED:
      return { subject: 'Inboard Opportunity Rejected', templateId: CONSTANTS.TEMPLATE_NAME_TO_ID_MAP.applicationRejected };
    default:
      return { subject: null, templateId: null };
  }
}

function getWorkHours (workHours) {
  const { from, to } = workHours;
  const fromString = convertHoursTo12HourFormat(from);
  const toString = convertHoursTo12HourFormat(to);
  if (!fromString && toString) {
    return `${toString}`;
  }
  if (fromString && !toString) {
    return `${fromString}`;
  }
  if (!fromString && !toString) {
    return '';
  }
  return `${fromString} - ${toString}`;

}

function convertHoursTo12HourFormat (hour) {
  if (!hour) {
    return '';
  }
  const totalHoursInSeconds = moment.utc(hour * 3600 * 1000);
  return moment(totalHoursInSeconds).format('hh:mmA').toString();
}