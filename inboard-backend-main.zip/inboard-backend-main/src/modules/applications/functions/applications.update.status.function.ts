import Opportunity, { IOpportunity } from '@modules/opportunities/index.js';
import { UpdateQuery } from 'mongoose';
import Application, { IApplication, ApplicationStatus } from '@modules/applications/index.js';
import PaymentCaptures from '@modules/payment.captures/index.js';
import Payment from '@modules/payments/index.js';
import { PaymentMethod } from '@helpers/generic.types.js';

async function updateApplicationStatus ({ applicationId, status, rejectionReason }: IUpdateApplicationStatusParams) {
  const application = await Application.dal.findOne({
    filter: { _id: applicationId },
    select: 'status opportunityId userId paidApplicationFees',
    lean: true
  });

  if (!application) {
    return { statusCode: 404, message: 'Application Not Found.' };
  }

  const applicationUpdate = getApplicationUpdate({ status, rejectionReason });
  await Application.dal.updateOne({
    filter: { _id: application._id },
    update: applicationUpdate
  });

  await updateOpportynityCounts({ opportunityId: application.opportunityId, status });

  if (status === ApplicationStatus.ACCEPTED) {
    const payment = await Payment.dal.findOne({
      filter: { applicationId: application._id, userId: application.userId, isTabbyPaymentClosed: false }
    });
    if (payment) {
      await PaymentCaptures.add({
        applicationId: application._id,
        userId: application.userId,
        amountToCapture: payment.amount,
        paymentId: payment._id,
        paymentMethod: PaymentMethod.TABBY
      });
    }
  }

  return { statusCode: 204 };
}

export default updateApplicationStatus;

function getApplicationUpdate ({ status, rejectionReason }) {
  const applicationUpdate: UpdateQuery<IApplication> = { status };
  if (status === ApplicationStatus.ACCEPTED) {
    applicationUpdate.acceptedAt = new Date();
  }

  if (status === ApplicationStatus.REJECTED) {
    applicationUpdate.rejectedAt = new Date();
    applicationUpdate.rejectionReason = rejectionReason;
  }

  return applicationUpdate;
}

async function updateOpportynityCounts ({ opportunityId, status }) {
  const update: UpdateQuery<IOpportunity> = {};
  if (status !== ApplicationStatus.REJECTED && status !== ApplicationStatus.ACCEPTED) {
    return;
  }

  if (status === ApplicationStatus.ACCEPTED) {
    update.$inc = { acceptedCount: 1 };
  }
  if (status === ApplicationStatus.REJECTED) {
    update.$inc = { rejectedCount: 1 };
  }

  return await Opportunity.dal.updateOne({
    filter: { _id: opportunityId },
    update
  });
}

interface IUpdateApplicationStatusParams {
  applicationId: IApplication['_id'];
  status: IApplication['status'];
  rejectionReason?: IApplication['rejectionReason']
}