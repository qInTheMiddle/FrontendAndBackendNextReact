import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';
import { IOpportunity } from '@modules/opportunities/index.js';
import { IUser } from '@modules/users/index.js';
import { CounterPrefix } from '@modules/counters/index.js';
import { ICompany } from '@modules/companies/index.js';

export interface IApplication<Populate = true> extends IMongo {
  opportunityId: PopulatedDoc<IOpportunity, Populate>;
  userId: PopulatedDoc<IUser, Populate>;
  companyId?: PopulatedDoc<ICompany, Populate>;
  yearsOfExperience: YearsOfExperience;
  cvUrl: string;
  duration?: number;
  expectedGoals?: string;

  status: ApplicationStatus,

  applicationFees: number;
  opportunityFees: number;

  paidApplicationFees?: number;
  applicationFeesPaidAt?: Date;

  paidOpportunityFees?: number;
  opportunityFeesPaidAt?: Date;

  acceptedAt?: Date;

  rejectedAt?: Date;
  rejectionReason?: string;
  isTabbyCaptured?: boolean;
  customId: `${CounterPrefix.APPLICATION}${number}`;
}

export enum YearsOfExperience {
  ZERO = '0',
  ZERO_TO_ONE = '0-1 years',
  ONE_TO_THREE = '1-3 years',
  THREE_PLUS = '3+ years',
}

export enum ApplicationStatus {
  DRAFT = 'draft',
  PAID_APPLICATION_FEES = 'paid-application-fees',
  AWAITING_INBOARD_INVERVIEW = 'awaiting-inboard-interview',
  AWAITING_OPPORTUNITY_INVERVIEW = 'awaiting-opportunity-interview',
  ACCEPTED = 'accepted',
  REJECTED = 'rejected'
}

export const APPLICATION_STATUS_ORDER = Object.freeze({
  [ApplicationStatus.DRAFT]: 1,
  [ApplicationStatus.PAID_APPLICATION_FEES]: 2,
  [ApplicationStatus.AWAITING_INBOARD_INVERVIEW]: 3,
  [ApplicationStatus.AWAITING_OPPORTUNITY_INVERVIEW]: 4,
  [ApplicationStatus.ACCEPTED]: 5
});