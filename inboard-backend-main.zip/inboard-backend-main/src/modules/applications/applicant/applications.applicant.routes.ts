import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.get('/api/applicant/applications/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/applicant/applications/:applicationIdOrOpportunityId/view/', isAllowed, makeCallback(controllers.view));
  app.post('/api/applicant/applications/add/', isAllowed, jsonParser, makeCallback(controllers.add));
  app.post('/api/applicant/applications/update/', isAllowed, jsonParser, makeCallback(controllers.update));
}