export { default as list } from './applications.applicant.list.controller.js';
export { default as view } from './applications.applicant.view.controller.js';
export { default as add } from './applications.applicant.add.controller.js';
export { default as update } from './applications.applicant.update.controller.js';