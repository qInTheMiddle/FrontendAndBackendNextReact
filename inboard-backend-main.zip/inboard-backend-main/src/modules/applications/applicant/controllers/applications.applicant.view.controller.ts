import { Request, Response } from 'express';
import Application from '@modules/applications/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    applicationIdOrOpportunityId: Joi.mongoId().required()
  })
};
export default async (req: Request, res: Response) => {
  const { params, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const application = await Application.dal.findOne({
    filter: {
      userId: actingUser._id,
      $or: [
        { _id: params.applicationIdOrOpportunityId },
        { opportunityId: params.applicationIdOrOpportunityId }
      ]
    },
    populate: {
      path: 'opportunityId',
      select: 'companyId title slug',
      populate: { path: 'companyId', select: 'name slug' }
    },
    lean: true
  });
  if (!application) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }

  return res.status(200).json({ application });
};