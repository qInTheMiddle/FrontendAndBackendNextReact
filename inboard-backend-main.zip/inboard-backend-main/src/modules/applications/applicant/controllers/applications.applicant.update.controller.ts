import { Request, Response } from 'express';
import Application, { ApplicationStatus, YearsOfExperience } from '@modules/applications/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    application: Joi.object().required().keys({
      opportunityId: Joi.mongoId().required(),
      yearsOfExperience: Joi.string().required().valid(...Object.values(YearsOfExperience)),
      cvUrl: Joi.string().required(),
      expectedGoals: Joi.string().required()
    })
  })
};


export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { opportunityId } = body.application;

  const application = await Application.dal.findOne({
    filter: { userId: actingUser._id, opportunityId },
    select: 'status',
    lean: true
  });
  if (!application) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }
  if (application.status !== ApplicationStatus.DRAFT) {
    return res.status(400).json({ message: 'Cannot update application.' });
  }

  await Application.dal.updateOne({
    filter: {
      userId: actingUser._id,
      opportunityId
    },
    update: {
      yearsOfExperience: body.application.yearsOfExperience,
      cvUrl: body.application.cvUrl,
      expectedGoals: body.application.expectedGoals
    }
  });

  return res.status(201).json({ applicationId: application._id });
};