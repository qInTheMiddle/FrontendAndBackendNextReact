import { Request, Response } from 'express';
import Opportunity from '@modules/opportunities/index.js';
import Application, { ApplicationStatus, YearsOfExperience } from '@modules/applications/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  body: Joi.object().required().keys({
    application: Joi.object().required().keys({
      opportunityId: Joi.mongoId().required(),
      yearsOfExperience: Joi.string().required().valid(...Object.values(YearsOfExperience)),
      cvUrl: Joi.string().required(),
      expectedGoals: Joi.string().required()
    })
  })
};


export default async (req: Request, res: Response) => {
  const { body, actingUser } = validateRequest(req, validationSchema, { warn: true });

  const { opportunityId } = body.application;

  const [opportunity, currentApplication] = await Promise.all([
    Opportunity.dal.findOne({
      filter: { _id: opportunityId, isActive: true, availableSeats: { $gt: 0 } },
      lean: true
    }),
    Application.dal.findOne({
      filter: { userId: actingUser._id, opportunityId }
    })
  ]);

  if (!opportunity) {
    return res.status(404).json({ message: 'Opportunity Not Found.' });
  }
  const applicationData = {
    yearsOfExperience: body.application.yearsOfExperience,
    cvUrl: body.application.cvUrl,
    expectedGoals: body.application.expectedGoals,
    userId: actingUser._id,
    status: ApplicationStatus.DRAFT,
    applicationFees: opportunity.applicationFees,
    opportunityFees: opportunity.opportunityFees,
    opportunityId,
    companyId: opportunity.companyId

  };


  let applicationId;

  if (!currentApplication) {
    const newCreatedApplication = await Application.dal.create(applicationData);

    await Opportunity.dal.updateOne({
      filter: { _id: opportunity._id },
      update: { $inc: { applicationsCount: 1 } }
    });
    applicationId = newCreatedApplication._id;

  } else {

    if (currentApplication.status !== ApplicationStatus.DRAFT) {
      return res.status(409).json({ message: 'Application Already Exists.' });
    }

    await Application.dal.updateOne({
      filter: {
        _id: currentApplication._id
      },
      update: applicationData
    });

    applicationId = currentApplication._id;
  }

  return res.status(201).json({ applicationId });

};