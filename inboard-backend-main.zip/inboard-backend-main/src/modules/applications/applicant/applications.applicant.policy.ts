export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['applicant'],
    allows: [
      { resources: '/api/applicant/applications/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/applicant/applications/:applicationIdOrOpportunityId/view/', permissions: 'get' },
      { resources: '/api/applicant/applications/add/', permissions: 'post' },
      { resources: '/api/applicant/applications/update/', permissions: 'post' }
    ]
  }]);
}