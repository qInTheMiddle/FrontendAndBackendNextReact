export * from './applications.model.interface.js';

import Model from './applications.model.js';
import DAL from '@helpers/dal.js';

const dal = new DAL(Model);

import updateStatus from './functions/applications.update.status.function.js';
import sendApplicantEmail from './functions/applications.send.applicant.email.function.js';

export default {
  Model,
  dal,

  updateStatus,
  sendApplicantEmail
};