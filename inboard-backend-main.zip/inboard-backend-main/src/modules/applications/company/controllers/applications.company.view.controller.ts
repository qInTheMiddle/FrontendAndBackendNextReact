import { Request, Response } from 'express';
import Application from '@modules/applications/index.js';
import Joi from '@helpers/joi.js';
import validateRequest from '@helpers/validate.request.js';
const validationSchema = {
  params: Joi.object().required().keys({
    applicationId: Joi.mongoId().required()
  })
};

export default async (req: Request, res: Response) => {
  const { params } = validateRequest(req, validationSchema, { warn: true });

  const application = await Application.dal.findOne({
    filter: { _id: params.applicationId, companyId: req.user?.companyId },
    populate: [
      { path: 'opportunityId' },
      { path: 'userId' }
    ],
    lean: true
  });
  if (!application) {
    return res.status(404).json({ message: 'Application Not Found.' });
  }

  return res.status(200).json({ application });
};