export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['company-employee'],
    allows: [
      { resources: '/api/company/applications/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' },
      { resources: '/api/company/applications/:applicationId/view/', permissions: 'get' },
      { resources: '/api/company/applications/:applicationId/update-status/', permissions: 'put' }
    ]
  }]);
}