import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import express, { Application } from 'express';
const jsonParser = express.json();
import isAllowed from '@helpers/is.allowed.js';

export default function (app: Application) {
  app.get('/api/company/applications/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
  app.get('/api/company/applications/:applicationId/view/', isAllowed, makeCallback(controllers.view));
  app.put('/api/company/applications/:applicationId/update-status/', isAllowed, jsonParser, makeCallback(controllers.updateStatus));
}