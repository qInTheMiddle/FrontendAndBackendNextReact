import { Application } from 'express';
import teamRoutes from './team/payment.captures.routes.js';

export default function (app: Application) {
  teamRoutes(app);
}