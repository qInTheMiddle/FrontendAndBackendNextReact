import mongoose from 'mongoose';
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';
import { IPaymentCapture, PaymentCaptureStatus } from '@modules/payment.captures/index.js';
import { CounterFor, CounterPrefix } from '@modules/counters/index.js';

import { Model } from '@helpers/models.enum.js';
import { PaymentMethod } from '@helpers/generic.types.js';
const { Schema } = mongoose;

const paymentCapturesSchema = new Schema<IPaymentCapture>({
  applicationId: {
    type: Schema.Types.ObjectId,
    ref: Model.APPLICATION,
    required: true
  },
  userId: { type: Schema.Types.ObjectId, ref: Model.USER, required: true },
  paymentId: { type: Schema.Types.ObjectId, ref: Model.PAYMENT, required: true },

  status: { type: String, default: PaymentCaptureStatus.PENDING, enum: PaymentCaptureStatus },

  paymentMethod: { type: String, enum: [PaymentMethod.TABBY, PaymentMethod.TAMARA], required: true },

  amountToCapture: { type: Number, required: true },

  paymentCaptureResult: Object,

  capturedAt: Date,
  failedAt: Date
});

paymentCapturesSchema.index({ userId: 1 });
paymentCapturesSchema.index({ applicationId: 1 }, { unique: true, sparse: true });

injectCustomIdCreator({ schema: paymentCapturesSchema, documentName: CounterFor.PAYMENT_CAPTURES, prefix: CounterPrefix.PAYMENT_CAPTURES });

export default mongoose.model<IPaymentCapture>(Model.PAYMENT_CAPTURE, paymentCapturesSchema);