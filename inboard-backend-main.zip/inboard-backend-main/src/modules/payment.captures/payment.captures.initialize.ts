import { Application } from 'express';
import { Acl } from 'acl';
import routes from './payment.captures.routes.js';
import policies from './payment.captures.policies.js';
import './payment.captures.cron.js';

export default function (app: Application, acl: Acl) {
  routes(app);
  policies(acl);
}