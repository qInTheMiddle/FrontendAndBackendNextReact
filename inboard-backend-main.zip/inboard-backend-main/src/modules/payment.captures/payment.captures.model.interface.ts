import { IMongo, PopulatedDoc } from '@helpers/mongo.interface.js';
import { IUser } from '@modules/users/index.js';
import { IPayment } from '@modules/payments/index.js';
import { PaymentMethod } from '@helpers/generic.types.js';
import { IApplication } from '@modules/applications/index.js';

export interface IPaymentCapture<Populate = true> extends IMongo {
  applicationId?: PopulatedDoc<IApplication, Populate>;
  userId: PopulatedDoc<IUser, Populate>;
  paymentId: PopulatedDoc<IPayment, Populate>;

  status?: PaymentCaptureStatus;

  paymentMethod: PaymentMethod.TABBY | PaymentMethod.TAMARA;

  amountToCapture: number;

  paymentCaptureResult?: any;

  capturedAt?: Date;
  failedAt?: Date;
}


export enum PaymentCaptureStatus {
  PENDING = 'pending',
  FAILED = 'failed',
  SUCCEEDED = 'succeeded',
}