import { Request as Req, Response } from 'express';
import calculatePagesCount from '@helpers/calculate.pages.count.js';
import * as mongoUtils from '@helpers/mongo.utils.js';
import Strings from '@helpers/strings.js';
import Application from '@modules/applications/index.js';
import PaymentCapture from '@modules/payment.captures/index.js';
import User from '@modules/users/index.js';

export default async (req: Req, res: Response) => {
  const sortBy = req.params.sortBy || '-createdAt';
  const limit = Math.min(Number(req.params.limit) || 30, 100);
  const currentPage = parseInt(req.params.page) || 1;
  let { query } = req;

  mongoUtils.makeDateWorkByDay({ filter: query, dateField: 'createdAt' });

  const stats = getStatsFilters();

  const { searchKey }: { searchKey?: string } = query;
  delete query.searchKey;

  if (searchKey?.trim()) {
    const { additionalFilter } = await getSearchKeyAdditionalFilter(searchKey);
    query = mongoUtils.and(query, additionalFilter);

    for (const fieldName of Object.keys(stats)) {
      stats[fieldName] = mongoUtils.and(stats[fieldName], query);
    }
  }

  const [
    paymentCaptures,
    paymentCapturesCount,
    all,
    pending,
    failed,
    succeeded
  ] = await Promise.all([
    PaymentCapture.dal.find({
      filter: query,
      populate: [
        { path: 'applicationId', select: 'customId' }
      ],
      sort: sortBy,
      paginate: { documentsPerPage: limit, page: currentPage },
      lean: true
    }),
    PaymentCapture.Model.countDocuments(query),
    PaymentCapture.Model.countDocuments(stats.all),
    PaymentCapture.Model.countDocuments({ status: 'pending' }),
    PaymentCapture.Model.countDocuments({ status: 'failed' }),
    PaymentCapture.Model.countDocuments({ status: 'succeeded' })
  ]);


  const searchStats = {
    all,
    pending,
    failed,
    succeeded
  };

  if (!paymentCapturesCount) {
    return res.json({ case: 2, message: 'No payment captures found.', searchStats });
  }

  const pagesCount = calculatePagesCount({ documentsCount: paymentCapturesCount, documentsPerPage: limit });

  return res.json({ case: 1, paymentCaptures, paymentCapturesCount, pagesCount, searchStats });
};

function getStatsFilters () {
  return {
    all: {},
    pending: { status: 'pending' },
    failed: { status: 'failed' },
    succeeded: { status: 'succeeded' }
  };
}

async function getSearchKeyAdditionalFilter (searchKey) {
  searchKey = searchKey.trim();
  let additionalFilter = {};

  const { customIdType, customId } = Strings.isCustomId(searchKey);
  if (customIdType) {
    ({ additionalFilter } = await getCustomIdFilter(customIdType, customId));
  } else {
    ({ additionalFilter } = await getTextFilter(searchKey));
  }

  additionalFilter = mongoUtils.blockIfEmpty(additionalFilter);

  return { additionalFilter };
}

async function getCustomIdFilter (customIdType, customId) {
  let additionalFilter = {};

  switch (customIdType) {
    case 'payment-capture':
      additionalFilter = { customId };
      break;
    case 'application':
      const directOrder = await Application.dal.findOne({
        filter: { customId },
        select: '_id',
        lean: true
      });
      if (directOrder) {
        additionalFilter = { directOrderId: directOrder._id };
      }
      break;
  }

  return { additionalFilter };
}

async function getTextFilter (searchKey) {
  let additionalFilter = {};

  const {
    isEmail, email,
    isMobileNumber, mobile
  } = Strings.analyzeSearchKey(searchKey);

  let userFilter;
  if (isEmail) {
    userFilter = { email };
  } else if (isMobileNumber) {
    userFilter = { mobile };
  }

  const user = userFilter && await User.dal.findOne({ filter: userFilter, select: '_id', lean: true });
  if (user) {
    additionalFilter = { userId: user._id };
  }

  return { additionalFilter };
}