export default function invokeRolesPolicies (acl) {
  acl.allow([{
    roles: ['agent'],
    allows: [
      { resources: '/api/team/payment-captures/list/sortBy-:sortBy/:limit/:page/', permissions: 'get' }
    ]
  }]);
}