import makeCallback from '@helpers/make.callback.js';
import * as controllers from './controllers/index.js';
import isAllowed from '@helpers/is.allowed.js';
import { Application } from 'express';

export default function (app: Application) {
  app.get('/api/team/payment-captures/list/sortBy-:sortBy/:limit/:page/', isAllowed, makeCallback(controllers.list));
}