import teamPolicies from './team/payment.captures.policy.js';

export default function invokeRolesPolicies (acl) {
  teamPolicies(acl);
}