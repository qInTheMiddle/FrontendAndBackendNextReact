export * from './payment.captures.model.interface.js';

import Model from './payment.captures.model.js';
import DAL from '@helpers/dal.js';

const dal = new DAL(Model);

import add from './functions/payment.captures.add.function.js';
import process from './functions/payment.captures.process.function.js';

export default {
  Model,
  dal,
  add,
  process

};