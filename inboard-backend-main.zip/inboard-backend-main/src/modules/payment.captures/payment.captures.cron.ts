import PaymentCapture from '@modules/payment.captures/index.js';
import startCronJob from '@helpers/start.cron.job.js';

startCronJob({
  pattern: '*/10 * * * *',
  functionToRun: PaymentCapture.process,
  logDescription: true
});