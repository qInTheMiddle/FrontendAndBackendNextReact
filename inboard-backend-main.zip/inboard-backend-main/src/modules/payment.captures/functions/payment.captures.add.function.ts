import PaymentCapture, { IPaymentCapture } from '@modules/payment.captures/index.js';
import { CustomError } from '@helpers/errors.js';
import { IApplication } from '@modules/applications/index.js';
import { IUser } from '@modules/users/index.js';
import { IPayment } from '@modules/payments/index.js';

export const _deps = {
  paymentCaptureExists: _paymentCaptureExists
};

async function addPaymentCapture ({
  applicationId,
  userId,
  paymentId,
  amountToCapture,
  paymentMethod
}: IAddPaymentCaptureParams) {
  const { paymentCaptureExists } = _deps;

  if (!['tabby', 'tamara'].includes(paymentMethod)) {
    const err = new Error('Invalid payment capture method');
    err.metadata = {
      applicationId,
      userId,
      paymentId,
      amountToCapture,
      paymentMethod
    };
    throw err;
  }

  const paymentCaptureExistsResult = await paymentCaptureExists({ applicationId });
  if (paymentCaptureExistsResult) {
    const err = new CustomError('Payment capture already exists.');
    err.metadata = { applicationId };
    throw err;
  }

  const err = await PaymentCapture.dal.create({
    applicationId,
    userId,
    paymentId,
    amountToCapture,
    paymentMethod
  }).then(() => null, err => err);
  if (err) {
    err.metadata = {
      applicationId, paymentId, amountToCapture, paymentMethod
    };
    throw err;
  }

}

export default addPaymentCapture;

async function _paymentCaptureExists ({ applicationId }: IPaymentCaptureExistsParams) {

  const paymentCaptureExists = await PaymentCapture.dal.exists({
    filter: { applicationId }
  });

  return Boolean(paymentCaptureExists);
}

interface IAddPaymentCaptureParams {
  applicationId?: IApplication['_id'];
  userId: IUser['_id'];
  paymentId: IPayment['_id'];
  amountToCapture: number;
  paymentMethod: IPaymentCapture['paymentMethod'];
}

interface IPaymentCaptureExistsParams {
  applicationId?: IApplication['_id'];
}