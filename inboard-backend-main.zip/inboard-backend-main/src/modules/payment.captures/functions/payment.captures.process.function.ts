import Bluebird from 'bluebird';
import PaymentCapture from '@modules/payment.captures/index.js';
import Payment from '@modules/payments/index.js';
import Application from '@modules/applications/index.js';
import groupBy from '@helpers/group.by.js';
import reportError from '@helpers/report.error.js';
import { PaymentMethod } from '@helpers/generic.types.js';

export const _deps = {
  processPaymentCapture: _processPaymentCapture
};

async function processPaymentCaptures () {
  const { processPaymentCapture } = _deps;

  const paymentCaptures = await PaymentCapture.dal.find({
    filter: { status: 'pending' },
    sort: '-createdAt',
    lean: true
  });

  const paymentCapturesWriteOperations = [];
  const applicationsWriteOperations = [];

  const paymentCapturesGroups = groupBy(paymentCaptures, 'paymentId');
  for (const paymentCapturesGroup of paymentCapturesGroups) {
    const [{ applicationId, paymentId, paymentMethod }] = paymentCapturesGroup;
    const amountToCapture = paymentCapturesGroup.reduce((sum, paymentCapture) => sum + paymentCapture.amountToCapture, 0);
    const paymentCapturesIds = paymentCapturesGroup.map(paymentCapture => paymentCapture._id);

    try {
      await processPaymentCapture({
        paymentId,
        paymentMethod,
        amountToCapture,
        applicationId,
        paymentCapturesGroup,
        applicationsWriteOperations,
        paymentCapturesWriteOperations
      });

      await Bluebird.delay(1000);

    } catch (err) {
      err.metadata = { applicationId, paymentId, amountToCapture };
      reportError(err);
      paymentCapturesWriteOperations.push({
        updateMany: {
          filter: { _id: { $in: paymentCapturesIds } },
          update: { status: 'failed', paymentCaptureResult: err }
        }
      });
    }
  }

  await Promise.all([
    PaymentCapture.Model.bulkWrite(paymentCapturesWriteOperations),
    Application.Model.bulkWrite(applicationsWriteOperations)
  ]);
}

export default processPaymentCaptures;

async function _processPaymentCapture ({
  paymentId,
  paymentMethod,
  amountToCapture,
  applicationId,
  paymentCapturesGroup,
  applicationsWriteOperations,
  paymentCapturesWriteOperations
}) {
  let paymentCaptureResult;
  if (paymentMethod === PaymentMethod.TABBY) {
    paymentCaptureResult = await Payment.captureTabbyPayment({ paymentId, amountToCapture });
  }

  const paymentCapturesIds = paymentCapturesGroup.map(paymentCapture => paymentCapture._id);

  if ([1, 3].includes(paymentCaptureResult.case) === false) {
    paymentCapturesWriteOperations.push({
      updateMany: {
        filter: { _id: { $in: paymentCapturesIds } },
        update: { status: 'failed', paymentCaptureResult, failedAt: Date.now() }
      }
    });
  } else {

    paymentCapturesWriteOperations.push({
      updateMany: {
        filter: { _id: { $in: paymentCapturesIds } },
        update: { status: 'succeeded', paymentCaptureResult, capturedAt: Date.now() }
      }
    });
  }

  applicationsWriteOperations.push({
    updateOne: {
      filter: { _id: applicationId },
      update: { isTabbyCaptured: true }
    }
  });
}