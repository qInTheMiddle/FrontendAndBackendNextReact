import Big from 'big.js';

function toFixedNumber (number: number, digits: number = 2, floor: boolean = false) {
  if (digits < 0) {
    throw new Error(`Number of digits to keep after decimal point has to be greater than or equal zero got ${digits} instead.`);
  }
  if (number == null) {
    return null;
  }
  if (isNaN(number)) {
    return number;
  }

  if (floor) {
    return new Big(number).round(digits, Big.roundDown).toNumber();
  }

  return new Big(number).round(digits, Big.roundHalfUp).toNumber();
}


function getNthDigit <T extends number | string> (number: T, digit: number): number {
  const positiveNumber = Math.abs(Number(number));
  const stringifiedDigit = Math.floor(positiveNumber)?.toString()[digit - 1];

  const resultDigit = parseInt(stringifiedDigit);

  return Number.isNaN(resultDigit) === false ? resultDigit : null;
}

export { toFixedNumber, getNthDigit };