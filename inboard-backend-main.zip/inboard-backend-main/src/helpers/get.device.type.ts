export type DeviceType = 'iOS' | 'Android' | 'Mobile Web' | 'Web';

function getDeviceType (userAgent): DeviceType {
  userAgent = userAgent.toLowerCase();

  if (userAgent.includes('alamofire')) {
    return 'iOS';
  }
  if (userAgent.includes('okhttp')) {
    return 'Android';
  }
  if (isMobileWeb(userAgent)) {
    return 'Mobile Web';
  }
  return 'Web';
}

function isMobileWeb (userAgent) {
  const mobileWebAgents = [
    /Android/i,
    /webOS/i,
    /iPhone/i,
    /iPad/i,
    /iPod/i,
    /BlackBerry/i,
    /Windows Phone/i
  ];

  return mobileWebAgents.some((toMatchItem) => {
    return userAgent.match(toMatchItem);
  });
}

export default getDeviceType;