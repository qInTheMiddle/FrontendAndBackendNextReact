class CustomError extends Error {
  constructor (message) {
    super(message);
    this.name = 'CustomError';
  }
}
class ValidationError extends Error {
  public warn: any;

  constructor ({ message, warn }: { message?: any, warn?: boolean }) {
    super(message);
    this.name = 'ValidationError';
    this.message = message;
    this.warn = warn;
  }
}

export { CustomError, ValidationError };