import { Request, Response, NextFunction } from 'express';
import rateLimit, { Options, RateLimitRequestHandler } from 'express-rate-limit';
import RedisStore from 'rate-limit-redis';
import { redis } from '@helpers/redis/index.js';
import getIP from '@helpers/get.ip.js';
import { NODE_ENV } from '@helpers/env.js';

function getRateLimiter (options: Partial<Options>): RateLimitRequestHandler | ((req: Request, res: Response, next: NextFunction) => void) {
  if (!options.windowMs || options.windowMs < 1000) {
    throw new Error('`windowMs` is required and must be greater than or equal 1000.');
  }


  if (NODE_ENV === 'TEST') {
    return getFakeRateLimiter();
  }

  return rateLimit({
    store: getRedisStore(),
    keyGenerator: options.keyGenerator || defaultKeyGenerator,
    ...options
  });
}

export default getRateLimiter;

function getRedisStore () {
  return new RedisStore({
    // @ts-expect-error
    sendCommand: (...args: string[]) => redis.call(...args),
    prefix: 'RateLimiter:'
  });
}

function getFakeRateLimiter () {
  return (req: Request, res: Response, next: NextFunction) => next();
}

function defaultKeyGenerator (req: Request, res: Response) {
  const apiPath = req.route?.path || req.url;
  const userIdOrIP = req.user?._id || getIP(req);

  return `${apiPath}:${userIdOrIP}`;
}