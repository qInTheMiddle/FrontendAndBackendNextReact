import mongoose from 'mongoose';
import assert from 'node:assert';
import injectCustomIdCreator from '@helpers/inject.custom.id.creator.js';
const { Schema } = mongoose;

describe('injectCustomIdCreator(...)', () => {
  it('Should fail if the same document name is used twice', () => {
    // Arrange
    // @ts-ignore
    injectCustomIdCreator({ schema: new Schema(), documentName: 'test-test-requests', prefix: 'AB' });

    // Act and Assert
    assert.throws(
      // @ts-ignore
      () => injectCustomIdCreator({ schema: new Schema(), documentName: 'test-test-requests', prefix: 'AB' }),
      { message: 'Can not use the same document name twice. test-test-requests' }
    );
  });

  it('adds customId to schema', () => {
    // Arrange
    const commentSchema = new Schema();

    // Act
    // @ts-ignore
    injectCustomIdCreator({ schema: commentSchema, documentName: 'test-test-comment1', prefix: 'CCCCC' });

    // Assert
    const path = commentSchema.path('customId');
    assert.strictEqual((path as any).options.type, String);
    assert.strictEqual((path as any).options.required, true);

    const customIdUniqueIndex = commentSchema.indexes()
      .find(([indexNameObject, indexOptions]: any) => {
        return indexNameObject.customId && indexOptions.unique === true;
      });

    assert.ok(customIdUniqueIndex);
  });

  it('adds customId to schema', () => {
    // Arrange
    const commentSchema = new Schema();

    // Act
    // @ts-ignore
    injectCustomIdCreator({ schema: commentSchema, documentName: 'test-test-comment2', prefix: 'CCCCC' });

    // Assert
    assert.strictEqual((commentSchema as any).s.hooks._pres.get('validate')[0].fn.name, 'createCustomId');
  });
});