import { S3Client, PutObjectCommand, PutObjectCommandInput } from '@aws-sdk/client-s3';
import { AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_DEFAULT_REGION } from '@helpers/env.js';
import getContentType from '@helpers/get.content.type.js';

const s3Client = new S3Client({
  region: AWS_DEFAULT_REGION,
  credentials: {
    accessKeyId: AWS_ACCESS_KEY_ID,
    secretAccessKey: AWS_SECRET_ACCESS_KEY
  }
});

async function uploadToS3 ({ body, destinationInBucket, bucketName, acl }: IUploadToS3) {
  const fileExtension = destinationInBucket.split('.').pop();
  const ContentType = getContentType(fileExtension);

  const putObjectCommand = new PutObjectCommand({
    Bucket: bucketName,
    Key: destinationInBucket,
    Body: body,
    ContentType,
    CacheControl: 'max-age=31536000',
    ACL: acl
  });

  await s3Client.send(putObjectCommand);

  return `https://${bucketName}.s3.${AWS_DEFAULT_REGION}.amazonaws.com/${destinationInBucket}`;
}

export default uploadToS3;

interface IUploadToS3 {
  body: PutObjectCommandInput['Body'];
  destinationInBucket: PutObjectCommandInput['Key'];
  bucketName: PutObjectCommandInput['Bucket'];
  acl: PutObjectCommandInput['ACL'];
}