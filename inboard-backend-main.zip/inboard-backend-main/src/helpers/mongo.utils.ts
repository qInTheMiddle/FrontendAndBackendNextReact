import moment from 'moment';
import _ from 'lodash';
import isMongoId from '@helpers/is.mongo.id.js';
import { FilterQuery } from 'mongoose';
import Joi from '@helpers/joi.js';
const { cloneDeep, isObject, isEmpty, get, set } = _;

// TODO: should be refactored
function and (...filters) {
  const nonObjectValueIndex = filters.findIndex(obj => !isObject(obj));
  if (nonObjectValueIndex !== -1) {
    throw new Error(`Expecting filter objects, received \`${filters[nonObjectValueIndex]}\` instead.`);
  }

  filters = filters.map(cloneDeep);

  let flattenedFilters = [];

  for (const filter of filters) {
    flattenedFilters.push(filter);

    if (Array.isArray(filter.$and)) {
      flattenedFilters.push(...filter.$and);
      delete filter.$and;
    }
  }

  flattenedFilters = flattenedFilters.filter(filter => !isEmpty(filter));
  let mergedFilter = { $and: flattenedFilters };

  if (flattenedFilters.length === 1) {
    [mergedFilter] = flattenedFilters;
  }

  return mergedFilter;
}


function blockIfEmpty (filter) {
  if (isEmpty(filter)) {
    return { _id: '0'.repeat(24) };
  }

  return filter;
}

function injectIfChanged (originalDocument, changes, fieldPath, newValue) {
  const currentValue = get(originalDocument, fieldPath);
  const valueHasChanged = isEqual(currentValue, newValue) === false;
  if (valueHasChanged) {
    set(changes, fieldPath, newValue);
  }
}

function isEqual (currentValue, newValue) {
  if (newValue instanceof Date) {
    return newValue.valueOf() === currentValue?.valueOf?.();
  }

  if (isMongoId(newValue)) {
    return newValue?.toString() === currentValue?.toString?.();
  }

  return currentValue === newValue;
}

function injectIfNullish (originalDocument, changes, fieldPath, newValue) {
  if (get(originalDocument, fieldPath) == null) {
    set(changes, fieldPath, newValue);
  }
}

const dateSchema = Joi.date();

function makeDateWorkByDay<T> ({ filter, dateField }: { filter: FilterQuery<T>, dateField: string }) {
  if (filter[dateField] == null) {
    return;
  }

  for (const [key, value] of Object.entries(filter[dateField])) {
    const date = convertValueToDate(value);

    if (key.startsWith('$gt')) {
      filter[dateField][key] = moment(date).startOf('day');
    }

    if (key.startsWith('$lt')) {
      filter[dateField][key] = moment(date).endOf('day');
    }
  }
}

function convertValueToDate (value) {
  return dateSchema.validate(value).value;
}

function convertDocumentsToMap ({ documents, identifierKey = '_id' }) {
  const map = new Map();

  for (const document of documents) {
    if (document[identifierKey] == null) {
      continue;
    }
    map.set(document[identifierKey].toString?.(), document);
  }

  return map;
}


function generateDateRange ({ startDate, endDate }: { startDate?: Date, endDate?: Date } = {}) {
  const dateRangeFilter: { $gte?: Date, $lte?: Date } = {};
  if (startDate) {
    dateRangeFilter.$gte = startDate;
  }
  if (endDate) {
    dateRangeFilter.$lte = endDate;
  }

  if (_.isEmpty(dateRangeFilter)) {
    return null;
  }

  return dateRangeFilter;
}

export {
  and,
  blockIfEmpty,
  injectIfChanged,
  isEqual,
  injectIfNullish,
  makeDateWorkByDay,
  convertDocumentsToMap,
  generateDateRange
};