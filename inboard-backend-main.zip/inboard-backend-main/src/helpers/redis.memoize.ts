import { redis } from '@helpers/redis/index.js';
import * as Objects from '@helpers/objects.js';

function redisMemoize<T extends Function, U> ({
  functionToMemoize,
  cacheKey,
  expirationTimeInSeconds,
  thisContext = null
}: IRedisMemoizeParams<T, U>): T {
  async function memoizedAdapter (...args) {
    const formattedCacheKey = `${cacheKey}:${Objects.safeJSONStringify(args)}`;

    const cachedResult = await redis.get(formattedCacheKey);
    if (cachedResult) {
      return JSON.parse(cachedResult);
    }

    const result = await functionToMemoize.apply(thisContext, args);

    await redis.set(formattedCacheKey, Objects.safeJSONStringify(result));
    if (expirationTimeInSeconds > 0) {
      await redis.expire(formattedCacheKey, expirationTimeInSeconds);
    }

    return result;
  }

  return (memoizedAdapter as unknown as T);
}

export default redisMemoize;

interface IRedisMemoizeParams<T, U> {
  functionToMemoize: T;
  cacheKey: `${string}:${string}`;
  expirationTimeInSeconds?: number;
  thisContext?: U
}