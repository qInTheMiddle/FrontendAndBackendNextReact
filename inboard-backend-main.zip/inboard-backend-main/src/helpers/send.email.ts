import sendgridMail from '@sendgrid/mail';
import { AttachmentJSON } from '@sendgrid/helpers/classes/attachment';
import { SEND_GRID_MAIL_API_KEY } from '@helpers/env.js';
import reportError from '@helpers/report.error.js';

sendgridMail.setApiKey(SEND_GRID_MAIL_API_KEY);

async function sendEmail ({ from, to, subject, templateId, dynamicTemplateData, attachments }: ISendEmailParameters) {
  try {
    await sendgridMail.send({
      from,
      to,
      subject,
      templateId,
      dynamicTemplateData,
      attachments
    });
  } catch (err) {
    reportError(err);
  }
}


export default sendEmail;

interface ISendEmailParameters {
  from: string;
  to: string;
  subject?: string;
  templateId: string;
  dynamicTemplateData?: object;
  attachments?: AttachmentJSON[];
}