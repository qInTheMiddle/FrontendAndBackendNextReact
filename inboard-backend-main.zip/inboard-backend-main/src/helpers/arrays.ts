import _ from 'lodash';
const { uniqBy, chunk } = _;

function unique<T> (arr: T[]) {
  return [... new Set(arr)];
}

function getLastNElements<T> (array: T[], elementsCount: number) {
  return array.slice(
    Math.max(array.length - elementsCount, 0)
  );
}

function getFirstNElements<T> (array: T[], elementsCount: number) {
  return array.slice(0, elementsCount);
}

function insertOne<T> (array: T[], newElement: T, index: number) {
  array.splice(index, 0, newElement);
}

function removeFirstElement<T> (array: T[]) {
  array.shift();
}

function randomize<T> (arr: T[]): T[] {
  return _.shuffle(arr);
}

export {
  unique,
  getLastNElements,
  getFirstNElements,
  insertOne,
  uniqBy as uniqueBy,
  randomize,
  removeFirstElement,
  chunk as splitIntoChunks
};