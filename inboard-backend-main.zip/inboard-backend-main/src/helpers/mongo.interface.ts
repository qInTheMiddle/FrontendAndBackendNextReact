import { Types } from 'mongoose';

export interface IMongo {
  _id: Types.ObjectId | string;
  createdAt?: Date;
  updatedAt?: Date;
}

// eslint-disable-next-line @typescript-eslint/space-infix-ops
export type PopulatedDoc<IDoc extends { _id: IMongo['_id'] }, Populate = true> = Populate extends true ? Partial<IDoc> & IDoc['_id'] : IDoc['_id'];