function calculatePagesCount ({ documentsCount, documentsPerPage }: { documentsCount: number, documentsPerPage: number }) {
  let pagesCount = (1 + Math.floor(documentsCount / documentsPerPage)) || 1;

  if (documentsPerPage && !(documentsCount % documentsPerPage)) {
    pagesCount -= 1;
  }

  return pagesCount;
}

export default calculatePagesCount;