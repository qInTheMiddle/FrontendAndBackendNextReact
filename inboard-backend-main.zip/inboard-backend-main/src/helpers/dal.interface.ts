import { FilterQuery, PopulateOptions, QueryOptions, Document, Types, UpdateQuery } from 'mongoose';

export type NonLeanDocument<T> = Document<any, any, T> & T & { _id: string | Types.ObjectId; }
export type FindReturnType<T, isLean> = isLean extends true ? T : NonLeanDocument<T>;

interface IOptions extends QueryOptions {
  exposeSensitiveData?: boolean;
}

export interface IFindOptions<T, isLean extends boolean = boolean> {
  filter?: FilterQuery<T>;
  options?: IOptions;
  select?: string | object;
  populate?: PopulateOptions[] | PopulateOptions;
  sort?: string | object;
  skip?: number;
  limit?: number;
  lean?: isLean;
  paginate?: {
    documentsPerPage: number;
    page: number;
  };
}


export interface IBuildFindQuery<T> extends IFindOptions<T> {
  methodName?: 'findOne' | 'find';
}

export interface IUpdateOptions<T, isLean extends boolean = boolean> {
  filter?: FilterQuery<T>;
  update: UpdateQuery<T> & Partial<T>;
  options?: QueryOptions;
  select?: string | object;
  populate?: PopulateOptions | PopulateOptions[];
  sort?: string | object;
  lean?: isLean;
}

export interface IBuildUpdateQuery<T> extends IUpdateOptions<T> {
  methodName?: 'updateOne' | 'updateMany' | 'findOneAndUpdate';
}