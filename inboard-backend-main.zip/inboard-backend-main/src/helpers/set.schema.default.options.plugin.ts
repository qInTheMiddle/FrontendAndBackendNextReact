import { Schema } from 'mongoose';

function setSchemaDefaultOptionsPlugin (schema: Schema) {
  if (schema.get('excludeIndexes') == null) {
    schema.set('excludeIndexes', true);
  }

  schema.index({ createdAt: -1 });
  schema.set('timestamps', true);
  schema.set('toJSON', { virtuals: true });
  schema.set('toObject', { virtuals: true });
}

export default setSchemaDefaultOptionsPlugin;