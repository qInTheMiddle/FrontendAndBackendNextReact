import { DocumentDefinition, FilterQuery, Model, SaveOptions } from 'mongoose';
import { IBuildFindQuery, IBuildUpdateQuery, IFindOptions, IUpdateOptions, FindReturnType, NonLeanDocument } from '@helpers/dal.interface.js';
import { IMongo } from '@helpers/mongo.interface.js';
class DAL<T> {
  constructor (private model: Model<T>) { }

  public async findOne<isLean extends boolean = false> (findOptions: IFindOptions<T, isLean>): Promise<FindReturnType<T, isLean>> {
    findOptions = this._prepareFindArguments(findOptions);
    const { filter, select, options, populate, sort, skip, limit, lean } = findOptions;
    const query = this._buildFindQuery({ methodName: 'findOne', filter, options, select, populate, sort, skip, limit, lean });
    return await query.exec();
  }

  public async find<isLean extends boolean = false> (findOptions: IFindOptions<T, isLean>): Promise<FindReturnType<T, isLean>[]> {
    findOptions = this._prepareFindArguments(findOptions);
    const { filter, select, options, populate, sort, skip, limit, lean, paginate } = findOptions;
    const query = this._buildFindQuery({ methodName: 'find', filter, options, select, populate, sort, skip, limit, lean, paginate });
    return await query.exec();
  }

  private _buildFindQuery ({ methodName, filter, options, select, populate, sort, skip, limit, lean, paginate }: IBuildFindQuery<T>) {
    // @ts-expect-error
    const query = this.model[methodName](filter)
      .setOptions(options)
      .select(select)
      .populate(populate)
      .sort(sort)
      .skip(skip)
      .limit(limit);

    if (lean) {
      query.lean();
    }

    if (paginate) {
      const { documentsPerPage, page } = paginate;
      query.paginate({ documentsPerPage, page });
    }

    return query;
  }

  private _prepareFindArguments (findOptions) {
    findOptions = findOptions || {};
    findOptions.filter = findOptions.filter || {};
    findOptions.select = findOptions.select || {};
    findOptions.options = findOptions.options || {};
    findOptions.populate = findOptions.populate || null;
    findOptions.sort = findOptions.sort || {};
    findOptions.skip = findOptions.skip || null;
    findOptions.limit = findOptions.limit || null;
    findOptions.lean = findOptions.lean || false;

    return findOptions;
  }


  public async exists (findOptions: { filter?: FilterQuery<T> }): Promise<{ _id: IMongo['_id'] } | null> {
    findOptions = findOptions || {};
    const { filter } = findOptions;

    // @ts-expect-error
    return await this.model.findOne(filter).select('_id').lean().exec();
  }

  // eslint-disable-next-line max-len
  public async findOneAndUpdate<isLean extends boolean = false> (updateOptions: IUpdateOptions<T, isLean>): Promise<FindReturnType<T, isLean>> {
    updateOptions = this._prepareUpdateArguments(updateOptions);
    const { filter, update, select, options, populate, sort, lean } = updateOptions;
    const query = this._buildUpdateQuery({ methodName: 'findOneAndUpdate', filter, update, options, select, populate, sort, lean });
    return await query.exec();
  }

  private _buildUpdateQuery ({ methodName, filter, update, options, select, populate, sort, lean }: IBuildUpdateQuery<T>) {
    const query = this.model[methodName](filter, update, options)
      .select(select)
      // @ts-expect-error
      .populate(populate)
      .sort(sort);

    if (lean) {
      query.lean();
    }

    return query;
  }

  private _prepareUpdateArguments (updateOptions) {
    updateOptions = updateOptions || {};
    updateOptions.filter = updateOptions.filter || {};
    updateOptions.update = updateOptions.update || {};
    updateOptions.options = updateOptions.options || {};
    updateOptions.select = updateOptions.select || {};
    updateOptions.populate = updateOptions.populate || null;
    updateOptions.sort = updateOptions.sort || {};
    updateOptions.lean = updateOptions.lean || false;

    return updateOptions;
  }

  public async updateOne (updateOptions: IUpdateOptions<T>): Promise<any> {
    updateOptions = this._prepareUpdateArguments(updateOptions);
    const { filter, update, options } = updateOptions;
    const query = this._buildUpdateQuery({ methodName: 'updateOne', filter, update, options });
    return await query.exec();
  }

  public async updateMany (updateOptions: IUpdateOptions<T>): Promise<any> {
    updateOptions = this._prepareUpdateArguments(updateOptions);
    const { filter, update, options } = updateOptions;
    const query = this._buildUpdateQuery({ methodName: 'updateMany', filter, update, options });
    return await query.exec();
  }

  public async create (document: DocumentDefinition<Partial<T>>): Promise<NonLeanDocument<T>>;
  public async create (documents: DocumentDefinition<Partial<T>>[], options?: SaveOptions): Promise<NonLeanDocument<T>[]>;
  public async create (
    documentOrDocuments: DocumentDefinition<Partial<T>> | DocumentDefinition<Partial<T>>[],
    options?: SaveOptions): Promise<NonLeanDocument<T> | NonLeanDocument<T>[]> {
    if (Array.isArray(documentOrDocuments)) {
      return await this.model.create(documentOrDocuments, options) as any;
    }
    return await this.model.create(documentOrDocuments) as any;
  }
}

export default DAL;