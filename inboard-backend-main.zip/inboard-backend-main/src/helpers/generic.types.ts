export enum PaymentMethod {
  TAP = 'Tap',
  TABBY = 'tabby',
  TAMARA = 'tamara'
}