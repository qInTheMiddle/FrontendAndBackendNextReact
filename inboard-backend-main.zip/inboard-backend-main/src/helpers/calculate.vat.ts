import CONSTANTS from '@helpers/constants.js';
import * as Numbers from '@helpers/numbers.js';

function getVATFromAmountWithoutVAT (amountWithoutVAT: number, VAT_PERCENTAGE = getVATPercentage()) {
  const VAT = amountWithoutVAT * VAT_PERCENTAGE;
  return Numbers.toFixedNumber(VAT || 0);
}

function getVATFromAmountWithVAT (amountWithVAT: number, VAT_PERCENTAGE = getVATPercentage()) {
  const VAT = amountWithVAT - getOriginalAmount(amountWithVAT, VAT_PERCENTAGE);
  return Numbers.toFixedNumber(VAT || 0);
}

function getOriginalAmount (amountWithVAT: number, VAT_PERCENTAGE = getVATPercentage()) {
  const originalAmountMultiplier = 1 / (1 + VAT_PERCENTAGE);
  const originalAmount = originalAmountMultiplier * amountWithVAT;

  return Numbers.toFixedNumber(originalAmount || 0);
}

function addVATToAmount (amountWithoutVAT: number, VAT_PERCENTAGE = getVATPercentage()) {
  const amountWithVAT = amountWithoutVAT * (1 + VAT_PERCENTAGE);
  return Numbers.toFixedNumber(amountWithVAT || 0);
}

function getVATPercentage () {
  return CONSTANTS.VAT_PERCENTAGE;
}

export {
  getVATFromAmountWithoutVAT,
  getVATFromAmountWithVAT,
  getOriginalAmount,
  addVATToAmount,
  getVATPercentage
};