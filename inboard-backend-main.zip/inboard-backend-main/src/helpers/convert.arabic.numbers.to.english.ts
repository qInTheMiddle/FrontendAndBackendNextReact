const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';

function convertArabicNumbersToEnglish (stringOrNumber: string | number) {
  if (!(/[٠١٢٣٤٥٦٧٨٩]+/).test(stringOrNumber as string)) {
    return getValue(stringOrNumber);
  }

  stringOrNumber = String(stringOrNumber);

  stringOrNumber = stringOrNumber.split('').map((character) => {
    if (arabicNumbers.includes(character)) {
      return arabicNumbers.indexOf(character);
    }
    return character;
  }).join('');

  return getValue(stringOrNumber);
}

function getValue (stringOrNumber: string | number) {
  // TODO: what?
  if ((typeof stringOrNumber) === 'number') {
    return Number(stringOrNumber);
  }

  return stringOrNumber;
}

export default convertArabicNumbersToEnglish;