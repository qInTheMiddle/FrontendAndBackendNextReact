import { Request, Response, NextFunction } from 'express';
import reportError from '@helpers/report.error.js';

function makeCallback (providedFunction: Function) {
  return async function (req: Request, res: Response, next: NextFunction) {
    try {
      await providedFunction(req, res, next);
    } catch (err) {
      reportError(err, req, res);
    }
  };
}

export default makeCallback;