import { Request } from 'express';

function getIP (req: Request) {
  return req.header('cf-pseudo-ipv4') || req.header('cf-connecting-ip') || req.header('x-real-ip') || req.ip;
}

export default getIP;