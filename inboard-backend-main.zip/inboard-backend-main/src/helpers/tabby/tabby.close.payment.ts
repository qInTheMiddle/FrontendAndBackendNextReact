import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TABBY_SECRET_KEY } from '@helpers/env.js';
import { IPayment } from '@modules/payments/index.js';

async function closePayment ({ paymentId }: { paymentId: IPayment['tabby']['id'] }) {
  const response = await executeRequest({ paymentId });

  const isAlreadyClosed = response.body && response.body.error === 'already closed';
  if (isAlreadyClosed) {
    return { case: 1, message: 'Payment is already closed.' };
  }

  if (response.statusCode !== 200) {
    return { case: 2, message: 'Could not close payment.' };
  }

  const payment = response.body;

  return { case: 1, message: 'Payment is closed successfully.', payment };
}

async function executeRequest ({ paymentId }) {
  return await makeHttpRequest({
    url: `https://api.tabby.ai/api/v1/payments/${paymentId}/close`,
    method: 'POST',
    headers: { Authorization: `Bearer ${TABBY_SECRET_KEY}` },
    body: { },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}

export default closePayment;