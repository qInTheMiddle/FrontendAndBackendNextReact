import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TABBY_SECRET_KEY, NODE_ENV } from '@helpers/env.js';

const isTestEnvironment = NODE_ENV !== 'production';
const PAYMENTS_PER_PAGE = 20;

async function listTabbyPayments ({ startDate, endDate }: { startDate: Date, endDate: Date }) {
  let skip = 0;
  let hasMorePayments = true;
  const tabbyPayments = [];

  while (hasMorePayments) {
    const { body, statusCode } = await executeRequest({ startDate, endDate, skip });

    if (statusCode !== 200) {
      throw new Error('Could not list tabby payments.');
    }

    const { payments: paymentsFromResponse, pagination } = body;
    tabbyPayments.push(...paymentsFromResponse);

    skip += paymentsFromResponse.length;

    hasMorePayments = pagination.total_count !== 0 && tabbyPayments.length < pagination.total_count;
  }

  return filterPaymentsAccordingToEnvironment(tabbyPayments);
}

async function executeRequest ({ startDate, endDate, skip }) {
  return await makeHttpRequest({
    url: 'https://api.tabby.ai/api/v1/payments',
    method: 'GET',
    headers: { Authorization: `Bearer ${TABBY_SECRET_KEY}` },
    qs: {
      created_at__gte: startDate,
      created_at__lte: endDate,
      offset: skip,
      limit: PAYMENTS_PER_PAGE
    },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}

function filterPaymentsAccordingToEnvironment (tabbyPayments) {
  return tabbyPayments.filter(payment => payment.test === isTestEnvironment);
}

export default listTabbyPayments;