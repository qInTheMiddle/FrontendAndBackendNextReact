import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TABBY_SECRET_KEY } from '@helpers/env.js';
import { IPayment } from '@modules/payments/index.js';

async function getTabbyPayment ({ paymentId }: { paymentId: IPayment['tabby']['id'] }) {
  const res = await executeRequest({ paymentId });
  const { body: tabbyPayment, statusCode } = res;

  if (statusCode !== 200) {
    return { case: 3, message: 'Could not find tabby payment', tabbyPayment };
  }

  if (tabbyPayment.status !== 'AUTHORIZED') {
    return { case: 2, message: 'Unusuccessful tabby payment.', tabbyPayment };
  }

  return { case: 1, message: 'Found tabby payment successfully.', tabbyPayment };
}

async function executeRequest ({ paymentId }) {
  return await makeHttpRequest({
    url: `https://api.tabby.ai/api/v1/payments/${paymentId}`,
    method: 'GET',
    headers: { Authorization: `Bearer ${TABBY_SECRET_KEY}` },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}
export default getTabbyPayment;