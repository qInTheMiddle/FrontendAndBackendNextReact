import { makeHttpRequest } from '@helpers/make.http.request.js';
import * as Numbers from '@helpers/numbers.js';
import { TABBY_SECRET_KEY } from '@helpers/env.js';
import { IPayment } from '@modules/payments/index.js';

async function refundTabbyPayment ({ tabbyPaymentId, amount }: { tabbyPaymentId: IPayment['tabby']['id'], amount: number }) {
  const response = await executeRequest({ tabbyPaymentId, amount });
  const { body: payment, statusCode } = response;

  if (statusCode !== 200) {
    return { case: 2, message: 'Payment is not successful.', payment };
  }

  return { case: 1, message: 'Payment is successful.', payment };
}

async function executeRequest ({ tabbyPaymentId, amount }) {
  return await makeHttpRequest({
    url: `https://api.tabby.ai/api/v1/payments/${tabbyPaymentId}/refunds`,
    method: 'POST',
    headers: { Authorization: `Bearer ${TABBY_SECRET_KEY}` },
    body: {
      amount: Numbers.toFixedNumber(amount)
    },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}

export default refundTabbyPayment;