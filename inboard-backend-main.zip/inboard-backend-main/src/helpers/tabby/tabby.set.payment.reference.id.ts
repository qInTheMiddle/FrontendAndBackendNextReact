import { IApplication } from '@modules/applications/index.js';
import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TABBY_SECRET_KEY } from '@helpers/env.js';
import { IPayment } from '@modules/payments/index.js';

async function setTabbyPaymentReferenceId ({ tabbyPaymentId, referenceId }: { tabbyPaymentId: IPayment['tabby']['id'], referenceId: IApplication['customId'] }) {
  const response = await executeRequest({ tabbyPaymentId, referenceId });

  if (response.statusCode !== 200) {
    return { case: 2, message: 'Could not update Tabby payment.', tabbyResponse: response.body };
  }

  return { case: 1, message: 'Updated Tabby payment successfully.' };
}

async function executeRequest ({ tabbyPaymentId, referenceId }) {
  return await makeHttpRequest({
    url: `https://api.tabby.ai/api/v1/payments/${tabbyPaymentId}`,
    method: 'PUT',
    headers: { Authorization: `Bearer ${TABBY_SECRET_KEY}` },
    body: {
      order: {
        reference_id: referenceId
      }
    },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });

}

export default setTabbyPaymentReferenceId;