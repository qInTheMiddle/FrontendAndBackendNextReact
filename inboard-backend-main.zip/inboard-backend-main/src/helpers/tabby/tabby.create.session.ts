import { makeHttpRequest } from '@helpers/make.http.request.js';
import * as Numbers from '@helpers/numbers.js';
import CONSTANTS from '@helpers/constants.js';
import { NODE_ENV, TABBY_PUBLIC_KEY } from '@helpers/env.js';

async function getCheckoutSession ({
  amount,
  buyer,
  registeredSince,
  tax_amount,
  shipping_amount,
  reference_id,
  items,
  orderHistory
}: IGetCheckoutSessionParameters) {

  if (NODE_ENV !== 'production') {
    buyer['email'] = 'card.success@tabby.ai';
    buyer['phone'] = '00966500000001';
  }


  const { body: tabbySession, statusCode } = await executeRequest({
    amount, buyer, tax_amount, shipping_amount, reference_id, items, registeredSince, orderHistory
  });

  if (statusCode !== 200) {
    const err = new Error('Could not create a tabby session.');
    err.metadata = { arguments, statusCode, tabbySession };
    throw err;
  }

  return tabbySession;
}

async function executeRequest ({
  amount, buyer, tax_amount, shipping_amount,
  reference_id, items, registeredSince, orderHistory
}) {
  return await makeHttpRequest({
    url: 'https://api.tabby.ai/api/v2/checkout',
    method: 'POST',
    headers: { Authorization: `Bearer ${TABBY_PUBLIC_KEY}` },
    body: {
      payment: {
        amount,
        currency: 'SAR',
        buyer,
        order: {
          tax_amount: Numbers.toFixedNumber(tax_amount),
          shipping_amount: Numbers.toFixedNumber(shipping_amount),
          reference_id,
          items
        },
        buyer_history: {
          registered_since: registeredSince,
          loyalty_level: 0,
          wishlist_count: 0,
          is_social_networks_connected: false,
          is_phone_number_verified: true,
          is_email_verified: true
        },
        order_history: orderHistory
      },
      merchant_urls: {
        success: `${getRedirectURL()}?success=true`,
        failure: `${getRedirectURL()}?failed=true`,
        cancel: `${getRedirectURL()}?canceled=true`
      },
      lang: 'ar',
      merchant_code: 'inboardsau'
    },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}

function getRedirectURL () {
  return `${CONSTANTS.FRONTEND_DOMAIN}/payments/verify-tabby/`;
}

export default getCheckoutSession;

interface IGetCheckoutSessionParameters {
  amount: number;
  buyer: object;
  tax_amount: number;
  shipping_amount: number;
  reference_id: string;
  registeredSince: string;
  metadata?: {
    order_id: string;
  };
  items: any[],
  orderHistory: any[]
}