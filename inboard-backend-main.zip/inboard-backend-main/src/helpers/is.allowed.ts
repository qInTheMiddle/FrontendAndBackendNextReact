import { Request, Response, NextFunction } from 'express';
import passport from 'passport';
import User from '@modules/users/index.js';
import acl from '@helpers/acl.js';
import redisMemoize from '@helpers/redis.memoize.js';
import reportError from '@helpers/report.error.js';

const ONE_MINUTE = 60;
const memoizedGetPayload = redisMemoize({
  functionToMemoize: User.getAccessTokenPayload,
  cacheKey: 'user:getAccessTokenPayload',
  expirationTimeInSeconds: ONE_MINUTE
});

function isAllowed (req: Request, res: Response, next: NextFunction) {
  passport.authenticate('jwt', async (err, user) => {
    try {
      if (err) {
        throw err;
      }

      if (user) {
        req.user = await memoizedGetPayload({ filter: { _id: user._id } });
      }

      const roles = req.user?.roles || ['guest'];

      const isAllowed = await acl.areAnyRolesAllowed(roles, req.route.path, req.method.toLowerCase());


      if (isAllowed) {
        return next();
      }


      return res.status(401).json({ message: 'Unauthorized' });
    } catch (err) {
      reportError(err, req, res);
    }
  })(req, res, next);
}

export default isAllowed;