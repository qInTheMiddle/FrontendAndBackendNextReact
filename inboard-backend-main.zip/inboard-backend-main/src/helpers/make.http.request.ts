import type { Method, Headers, OptionsInit, RetryOptions } from 'got';
import { stringify } from 'qs';
import got from '@helpers/got.js';

interface IMakeHttpRequest {
  url: string;
  method: Method;
  qs?: object;
  throwHttpErrors?: boolean;
  body?: object;
  bodyType?: 'form' | 'buffer' | 'json';
  headers?: Headers;
  resolveWithFullResponse?: boolean;
  retry?: Partial<RetryOptions>;
  responseType?: 'buffer' | 'json'
}

export async function makeHttpRequest ({
  url,
  method,
  qs,
  throwHttpErrors = true,
  body,
  bodyType = 'json',
  headers = {},
  resolveWithFullResponse = false,
  retry,
  responseType = 'json'
}: IMakeHttpRequest): Promise<any> {
  const options = buildOptions();

  return await got(url, options);

  function buildOptions () {
    const options: OptionsInit = {
      method,
      responseType,
      resolveBodyOnly: resolveWithFullResponse === false,
      searchParams: stringify(qs),
      headers,
      throwHttpErrors
    };

    if (retry) {
      options.retry = retry;
    }

    if (method?.toUpperCase() !== 'GET') {
      injectBodyInOptions({ bodyType, body, options });
    }
    return options;
  }
}

function injectBodyInOptions ({ bodyType, body, options }) {
  const typesMap = {
    buffer: 'body',
    json: 'json',
    form: 'form'
  };

  const gotOptionsBodyField = typesMap[bodyType];
  if (!gotOptionsBodyField) {
    throw new Error(`Received unknown bodyType \`${bodyType}\`.`);
  }

  options[gotOptionsBodyField] = body;
}

export default { _makeHttpRequest: makeHttpRequest };