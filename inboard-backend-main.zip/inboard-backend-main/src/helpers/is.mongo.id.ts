import { IMongo } from '@helpers/mongo.interface.js';

function isMongoId (_id: IMongo['_id']) {
  if (!_id) {
    return false;
  }

  return /^[0-9a-fA-F]{24}$/.test(_id as string);
}

export default isMongoId;