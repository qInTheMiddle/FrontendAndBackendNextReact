import assert from 'node:assert';
import mongoose from 'mongoose';
import * as mongoUtils from '@helpers/mongo.utils.js';
const { ObjectId } = mongoose.Types;

describe('mongoUtils', () => {
  describe('and(...)', () => {
    it('is a function', () => {
      assert.strictEqual(typeof mongoUtils.and, 'function');
    });
    describe('throws an error if one parameter is not an object', () => {
      it('null', () => {
        assert.throws(() => {
          mongoUtils.and(null);
        }, { message: 'Expecting filter objects, received `null` instead.' });
      });
      it('undefined', () => {
        assert.throws(() => {
          mongoUtils.and(undefined);
        }, { message: 'Expecting filter objects, received `undefined` instead.' });
      });
      it('string', () => {
        assert.throws(() => {
          mongoUtils.and('hello');
        }, { message: 'Expecting filter objects, received `hello` instead.' });
      });
    });
    it('merges two filters', () => {
      const mergedFilter = mongoUtils.and({ _id: 1 }, { status: 'canceled' });
      assert.deepStrictEqual(
        mergedFilter,
        {
          $and: [
            { _id: 1 },
            { status: 'canceled' }
          ]
        }

      );
    });
    it('flattens `$and`s', () => {
      const mergedFilter = mongoUtils.and(
        { _id: 1, d: 'D' },
        {
          username: 'hafez',
          $and: [
            { status: 'canceled' }
          ]
        },
        {
          customerType: 'individual',
          $and: [
            { a: 'A' },
            { b: 'B', c: 'C' }
          ]
        }
      );
      assert.deepStrictEqual(
        mergedFilter,
        {
          $and: [
            { _id: 1, d: 'D' },
            { username: 'hafez' },
            { status: 'canceled' },
            { customerType: 'individual' },
            { a: 'A' },
            { b: 'B', c: 'C' }
          ]
        }

      );
    });
    // it('does not modify the parameters, clones them', () => {})
    it('ignores empty objects', () => {
      const mergedFilter = mongoUtils.and(
        {},
        { _id: 1 },
        { status: 'pending' }
      );

      assert.deepStrictEqual(
        mergedFilter,
        { $and: [{ _id: 1 }, { status: 'pending' }] }
      );
    });

    it('does not return $and if only one object is present', () => {
      const mergedFilter = mongoUtils.and(
        {},
        { _id: 1 }
      );

      assert.deepStrictEqual(
        mergedFilter,
        { _id: 1 }
      );
    });
  });

  describe('blockIfEmpty(...)', () => {
    it('sends a blocking filter when it receives an empty filter', () => {
      assert.deepStrictEqual(
        mongoUtils.blockIfEmpty({}),
        { _id: '0'.repeat(24) }
      );
    });
    it('returns the same filter if it\'s not empty', () => {
      const filter = { _id: 123 };
      assert.strictEqual(
        mongoUtils.blockIfEmpty(filter),
        filter
      );
    });
  });

  describe('injectIfChanged', () => {
    it('is a function', () => {
      assert.strictEqual(typeof mongoUtils.injectIfChanged, 'function');
    });

    it('injects a field if value has changed', () => {
      // Arrange
      const document = { name: 'A' };
      const changes: any = {};
      const newName = 'B';
      // Act
      mongoUtils.injectIfChanged(document, changes, 'name', newName);

      // Assert
      assert.strictEqual(changes.name, 'B');
    });

    it('ignores a field if value has not changed', () => {
      // Arrange
      const document = { name: 'A' };
      const changes: any = {};
      const newName = 'A';
      // Act
      mongoUtils.injectIfChanged(document, changes, 'name', newName);

      // Assert
      assert.strictEqual(changes.name, undefined);
    });

    it('works with nested paths', () => {
      // Arrange
      const document = { name: { last: 'A' } };
      const changes: any = {};
      const newLastName = 'B';
      // Act
      mongoUtils.injectIfChanged(document, changes, 'name.last', newLastName);

      // Assert
      assert.strictEqual(changes.name.last, 'B');
    });

    it('works with dates', () => {
      // Arrange
      const document = { createdAt: new Date('2020-01-01') };
      const changes: any = {};
      const newDate = new Date('2020-01-01');
      // Act
      mongoUtils.injectIfChanged(document, changes, 'createdAt', newDate);

      // Assert
      assert.strictEqual(changes.createdAt, undefined);
    });

    it('works with object ids and stringified ids', () => {
      // Arrange
      const document = { userId: new ObjectId('0'.repeat(24)) };
      const changes: any = {};
      const newUserId = '1'.repeat(24);
      // Act
      mongoUtils.injectIfChanged(document, changes, 'userId', newUserId);

      // Assert
      assert.strictEqual(changes.userId, newUserId);
    });

    it('works with booleans', () => {
      // Arrange
      const document = { isPayingCustomer: true, isHappy: false };
      const changes: any = {};
      const newIsPayingCustomer = false;
      const newIsHappy = false;

      // Act
      mongoUtils.injectIfChanged(document, changes, 'isPayingCustomer', newIsPayingCustomer);
      mongoUtils.injectIfChanged(document, changes, 'isHappy', newIsHappy);

      // Assert
      assert.strictEqual(changes.isPayingCustomer, newIsPayingCustomer);
      assert.strictEqual(changes.isHappy, undefined);
    });

    it('works with numbers', () => {
      // Arrange
      const document = { age: 26, balance: 100 };
      const changes: any = {};
      const newAge = 27;
      const newBalance = 100;

      // Act
      mongoUtils.injectIfChanged(document, changes, 'age', newAge);
      mongoUtils.injectIfChanged(document, changes, 'balance', newBalance);

      // Assert
      assert.strictEqual(changes.age, newAge);
      assert.strictEqual(changes.balance, undefined);
    });
  });

  describe('injectIfNullish(...)', () => {
    it('is a function', () => {
      assert.strictEqual(typeof mongoUtils.injectIfNullish, 'function');
    });
    it('injects when `null`', () => {
      assertValueIsInjected({ originalValue: null });
    });
    it('injects when `undefined`', () => {
      assertValueIsInjected({ originalValue: undefined });
    });

    it('injects nested paths', () => {
      // Arrange
      const document = {};
      const changes: any = {};
      const value = 27;

      // Act
      mongoUtils.injectIfNullish(document, changes, 'a.b', value);

      // Assert
      assert.strictEqual(changes.a.b, value);
    });

    it('does not overwrite `false`', () => {
      assertValueIsNotInjected({ originalValue: false });
    });
    it('does not overwrite `0`', () => {
      assertValueIsNotInjected({ originalValue: 0 });

    });
    it('does not overwrite `1`', () => {
      assertValueIsNotInjected({ originalValue: 1 });
    });
  });

  describe('makeDateWorkByDay(...)', () => {
    it('is a function', () => {
      assert.strictEqual(typeof mongoUtils.makeDateWorkByDay, 'function');
    });

    it('sets the date to the last millisecond for `$lt`', () => {
      // Arrange
      const filter: any = { AAA: { $lt: new Date('2021-05-26') } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$lt.toObject(),
        { years: 2021, months: 4, date: 26, hours: 23, minutes: 59, seconds: 59, milliseconds: 999 }
      );
    });
    it('sets the date to the first millisecond `$gt`', () => {
      // Arrange
      const filter: any = { AAA: { $gt: new Date('2021-05-26') } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$gt.toObject(),
        { years: 2021, months: 4, date: 26, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 }
      );
    });

    it('works with `$lt`', () => {
      // Arrange
      const filter: any = { AAA: { $lt: new Date('2021-05-26').valueOf() } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$lt.toObject(),
        { years: 2021, months: 4, date: 26, hours: 23, minutes: 59, seconds: 59, milliseconds: 999 }

      );
    });
    it('works with `$lte`', () => {
      // Arrange
      const filter: any = { AAA: { $lte: new Date('2021-05-26').toISOString() } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$lte.toObject(),
        { years: 2021, months: 4, date: 26, hours: 23, minutes: 59, seconds: 59, milliseconds: 999 }
      );
    });
    it('works with `$gt`', () => {
      // Arrange
      const filter: any = { AAA: { $gt: new Date('2021-05-26') } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$gt.toObject(),
        { years: 2021, months: 4, date: 26, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 }
      );
    });
    it('works with `$gte`', () => {
      // Arrange
      const filter: any = { AAA: { $gte: new Date('2021-05-26') } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$gte.toObject(),
        { years: 2021, months: 4, date: 26, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 }
      );
    });
    it('works with both `$gt` and `$lt`', () => {
      // Arrange
      const filter: any = {
        AAA: {
          $gt: new Date('2021-05-26'),
          $lt: new Date('2021-05-30')
        }
      };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$gt.toObject(),
        { years: 2021, months: 4, date: 26, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 }
      );
      assert.deepStrictEqual(
        filter.AAA.$lt.toObject(),
        { years: 2021, months: 4, date: 30, hours: 23, minutes: 59, seconds: 59, milliseconds: 999 }
      );
    });

    it('works with stringified dates', () => {
      // Arrange
      const filter: any = { AAA: { $gte: '2021-05-26' } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$gte.toObject(),
        { years: 2021, months: 4, date: 26, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 }
      );
    });
    it('works with stringified unix timestamps', () => {
      // Arrange
      const filter: any = { AAA: { $gte: new Date('2021-05-26').valueOf().toString() } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$gte.toObject(),
        { years: 2021, months: 4, date: 26, hours: 0, minutes: 0, seconds: 0, milliseconds: 0 }
      );
    });

    it('works with date objects', () => {
      // Arrange
      const filter: any = { AAA: { $lte: new Date('2021-05-26') } };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'AAA' });

      // Assert
      assert.deepStrictEqual(
        filter.AAA.$lte.toObject(),
        { years: 2021, months: 4, date: 26, hours: 23, minutes: 59, seconds: 59, milliseconds: 999 }
      );
    });

    it('does nothing when dateField isn\'t an object', () => {
      // Arrange
      const filter = { createdAt: new Date('2021-05-26') };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'createdAt' });

      // Assert
      assert.deepStrictEqual(filter, { createdAt: new Date('2021-05-26') });
    });
    it('does nothing when dateField is undefined', () => {
      // Arrange
      const filter = { createdAt: undefined };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'createdAt' });

      // Assert
      assert.deepStrictEqual(filter, { createdAt: undefined });
    });
    it('does nothing when dateField is null', () => {
      // Arrange
      const filter = { createdAt: null };

      // Act
      mongoUtils.makeDateWorkByDay({ filter, dateField: 'createdAt' });

      // Assert
      assert.deepStrictEqual(filter, { createdAt: null });
    });
  });

  describe('mongoUtils.generateDateRange(...)', () => {
    it('returns `$gte` when provided `startDate`', () => {
      // Arrange
      // Act
      const result = mongoUtils.generateDateRange({ startDate: new Date('2021-05-26') });

      // Assert
      assert.deepStrictEqual(result, { $gte: new Date('2021-05-26') });
    });
    it('returns `$lte` when provided `endDate`', () => {
      // Arrange
      // Act
      const result = mongoUtils.generateDateRange({ endDate: new Date('2021-05-26') });

      // Assert
      assert.deepStrictEqual(result, { $lte: new Date('2021-05-26') });
    });
    it('returns `$gte` and `$lte` when provided `startDate` and `endDate`', () => {
      // Arrange
      // Act
      const result = mongoUtils.generateDateRange({ startDate: new Date('2021-05-01'), endDate: new Date('2021-05-26') });

      // Assert
      assert.deepStrictEqual(result, { $gte: new Date('2021-05-01'), $lte: new Date('2021-05-26') });
    });
    it('returns `null` when nothing is provided', () => {
      // Arrange
      // Act
      const result = mongoUtils.generateDateRange({ });

      // Assert
      assert.deepStrictEqual(result, null);
    });
  });
});

function assertValueIsInjected ({ originalValue }) {
  // Arrange
  const document = { a: originalValue };
  const changes: any = {};
  const value = 27;

  // Act
  mongoUtils.injectIfNullish(document, changes, 'a', value);

  // Assert
  assert.strictEqual(changes.a, value);
}

function assertValueIsNotInjected ({ originalValue }) {
  // Arrange
  const document = { a: originalValue };
  const changes: any = {};
  const value = 27;

  // Act
  mongoUtils.injectIfNullish(document, changes, 'a', value);

  // Assert
  assert.strictEqual(changes.a, undefined);
}