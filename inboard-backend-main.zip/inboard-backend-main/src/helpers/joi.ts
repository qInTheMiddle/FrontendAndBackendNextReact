import Joi, { Root as JoiRoot, Schema, StringSchema, NumberSchema } from 'joi';
import Bourne from '@hapi/bourne';
import joiPasswordComplexity, { JoiPasswordComplexity } from 'joi-password-complexity';
import convertArabicNumbersToEnglish from '@helpers/convert.arabic.numbers.to.english.js';

interface ICustomJoi extends JoiRoot {
  mongoId(): StringSchema;
  mobile(): NumberSchema;
  password(): JoiPasswordComplexity;
  notTrimmedString(): StringSchema;
  englishString(): StringSchema;
  slug(): StringSchema;
}

const CustomJoi: ICustomJoi = Joi.defaults(setAbortEarlyToFalse)
  .extend(coerceStringifiedObject)
  .extend(coerceStringifiedArray)
  .extend(notTrimmedString)
  .extend(convertArabicNumbersToEnglishValidator)
  .extend(trimStrings)
  .extend(coerceBooleans)
  .extend(mongoIdValidator)
  .extend(mobileNumberValidator)
  .extend(passwordValidator)
  .extend(englishStringValidator)
  .extend(slug);


function setAbortEarlyToFalse (schema: Schema) {
  return schema.options({ abortEarly: false });
}

function notTrimmedString (joi: JoiRoot) {
  return {
    base: joi.string(),
    type: 'notTrimmedString'
  };
}
function trimStrings (joi: JoiRoot) {
  return {
    base: joi.string().trim(),
    type: 'string'
  };
}

function slug (joi: JoiRoot) {
  return {
    base: joi.string().regex(/^[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*$/),
    type: 'slug',
    coerce (value) {
      if (value === null || value === '') {
        return { value: undefined };
      }

      return { value };
    }
  };
}

function convertArabicNumbersToEnglishValidator (joi: JoiRoot) {
  return {
    base: joi.number(),
    type: 'number',
    coerce (value) {
      if (value == null || value === '') {
        return { value: undefined };
      } else if (typeof value === 'string') {
        const englishValue = Number(convertArabicNumbersToEnglish(value));

        if (isNaN(englishValue) || !value) {
          return { value };
        }

        return { value: englishValue };
      }

      return { value };
    }
  };
}

function englishStringValidator (joi: JoiRoot) {
  return {
    base: joi.string().regex(/^[-'`~!@#$%^&*()_|+=?;:'",.<>{}[\]\\/ a-z0-9]+$/),
    type: 'englishString'
  };
}


function coerceBooleans (joi: JoiRoot) {
  const convertToTrue = new Set([true, 'true', 1, '1', 'yes']);
  const convertToFalse = new Set([false, 'false', 0, '0', 'no']);

  return {
    base: joi.boolean(),
    type: 'boolean',
    coerce (value) {
      if (convertToTrue.has(value)) {
        return { value: true };
      }

      if (convertToFalse.has(value)) {
        return { value: false };
      }

      return { value };
    }
  };
}

function mongoIdValidator (joi: JoiRoot) {
  return {
    base: joi.string().regex(/^[0-9a-fA-F]{24}$/),
    type: 'mongoId',
    coerce (value) {
      if (value === null || value === '') {
        return { value: undefined };
      }

      return { value };
    }
  };
}

// having joi as an unused parameter is necessary here
// otherwise it will throw an error
function passwordValidator (joi: JoiRoot) {
  return {
    base: joiPasswordComplexity({
      min: 8, max: 30,
      lowerCase: 1, upperCase: 1, numeric: 1,
      requirementCount: 1
    }),
    type: 'password'
  };
}

function mobileNumberValidator (joi: JoiRoot) {
  return {
    base: joi.number().integer().min(500_000_000).max(600_000_000),
    type: 'mobile',
    coerce (value) {
      return { value: convertArabicNumbersToEnglish(value) };
    }
  };
}


function coerceStringifiedObject (joi: JoiRoot) {
  return {
    type: 'object',
    base: joi.object(),
    coerce: {
      from: 'string',
      method (value) {

        if (value[0] !== '{' && !/^\s*\{/.test(value)) {
          return;
        }

        try {
          return { value: Bourne.parse(value) };
        } catch (ignoreErr) { }
      }
    }
  };
}

function coerceStringifiedArray (joi: JoiRoot) {
  return {
    type: 'array',
    base: joi.array(),
    coerce: {
      from: 'string',
      method (value) {

        if (typeof value !== 'string' || value[0] !== '[' && !/^\s*\[/.test(value)) {
          return;
        }

        try {
          return { value: Bourne.parse(value) };
        } catch (ignoreErr) { }
      }
    }
  };
}

export default CustomJoi;