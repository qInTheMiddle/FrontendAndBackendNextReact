import cron from 'cron';
import cronsTrue from 'cronstrue';
import makeCronFunction from '@helpers/make.cron.function.js';
import { NODE_ENV, DISABLE_CRON, PORT } from '@helpers/env.js';
const isProduction = NODE_ENV === 'production';
const { CronJob } = cron;

function startCronJob ({
  pattern,
  functionToRun,
  logDescription = false,
  logOnStartAndEnd = false,
  disallowOverlap = true,
  isOnlyOnProduction = false
}: IStartCronJobParams) {
  if (
    (isOnlyOnProduction && isProduction === false) ||
    DISABLE_CRON === 'true' ||
    NODE_ENV === 'TEST' ||
    PORT !== '3000'
  ) {
    return;
  }

  const cronFunction = makeCronFunction({
    cronFunctionToRun: functionToRun,
    logOnStartAndEnd,
    disallowOverlap
  });

  const job = new CronJob(pattern, cronFunction);
  job.start();

  if (logDescription) {
    const patternDescription = cronsTrue.toString(pattern, { verbose: false });
    console.log(`Initialized ${functionToRun.name} on: ${patternDescription}.`);
  }
}

export default startCronJob;

interface IStartCronJobParams {
  pattern: string;
  functionToRun: Function;
  logDescription?: boolean;
  logOnStartAndEnd?: boolean;
  disallowOverlap?: boolean;
  isOnlyOnProduction?: boolean;
}