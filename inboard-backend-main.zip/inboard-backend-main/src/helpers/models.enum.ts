export enum Model {
  USER = 'User',
  OPPORTUNITY = 'Opportunity',
  APPLICATION = 'Application',
  PAYMENT = 'Payment',
  COUNTER = 'Counter',
  COMPANY = 'Company',
  PAYMENT_CAPTURE = 'PaymentCapture',
  INVOICE = 'Invoice',
  CREDIT_NOTE = 'CreditNote',
}