function analyzeSearchKey (searchKey: string) {
  const { customId, customIdType } = isCustomId(searchKey);
  const { isEmail: isValidEmail, email } = isEmail(searchKey);
  const { isMobileNumber: isValidMobileNumber, mobile } = isMobileNumber(searchKey);
  const { isArabic: isValidArabic, string: arabicString } = isArabic(searchKey);

  return {
    customId,
    customIdType,

    isEmail: isValidEmail,
    email,

    isMobileNumber: isValidMobileNumber,
    mobile,

    isArabic: isValidArabic,
    arabicString
  };
}

function isCustomId (string: string) {
  string = string?.trim?.();
  const { isMobileNumber: isValidMobileNumber } = isMobileNumber(string);
  if (isValidMobileNumber) {
    return { customIdType: null, customId: null };
  }

  const isBranchCustomId = /^BR\d+$/i.test(string);
  const isDirectOrderCustomId = /^DOC\d+$/i.test(string);
  const isShipmentCustomId = /^SPL\d+$/i.test(string);
  const isRequestCustomId = /^(RC|RB)\d+$/i.test(string);
  const isOrderCustomId = /^(OC|OB)\d+$/i.test(string);
  const isBusinessProfileCustomId = /^(BP)\d+$/i.test(string);
  const isInvoiceCustomId = /^INV\d+$/i.test(string);
  const isRefundRequest = /^RFR\d+$/i.test(string);
  const isRefundClaim = /^RFC\d+$/i.test(string);
  const isPaymentCapture = /^PC\d+$/i.test(string);
  const isCarService = /^CS\d+$/i.test(string);
  const isCarServicesLineItem = /^SI\d+$/i.test(string);

  const customIdType = getCustomIdType();
  const customId = customIdType && string.toUpperCase();

  return { customIdType, customId };

  function getCustomIdType (): CustomIdType {
    if (isRequestCustomId) {
      return 'request';
    } else if (isBranchCustomId) {
      return 'branch';
    } else if (isShipmentCustomId) {
      return 'shipment';
    } else if (isDirectOrderCustomId) {
      return 'direct-order';
    } else if (isOrderCustomId) {
      return 'order';
    } else if (isBusinessProfileCustomId) {
      return 'business-profile';
    } else if (isInvoiceCustomId) {
      return 'invoice';
    } else if (isRefundRequest) {
      return 'refund-request';
    } else if (isRefundClaim) {
      return 'refund-claim';
    } else if (isPaymentCapture) {
      return 'payment-capture';
    } else if (isCarService) {
      return 'car-service';
    } else if (isCarServicesLineItem) {
      return 'car-services-line-item';
    }

    return null;
  }
}
function isMobileNumber (string) {
  string = String(string);
  string = string.trim().replace(/\s/g, '');
  string = string.trim().replace(/^\+/g, '');
  string = String(Number(string));
  string = string.replace(/^966/, '');

  const matches = /^5\d{8}$/.test(string);
  return { isMobileNumber: matches, mobile: matches ? string : null };
}

function isEmail (string) {
  string = String(string).trim().toLowerCase();

  const matches = getEmailRegex().test(string);
  return { isEmail: matches, email: matches ? string : null };
}

function getEmailRegex () {
  // eslint-disable-next-line max-len
  return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
}


function isArabic (string) {
  string = String(string).trim();

  const matches = getArabicRegex().test(string);
  return { isArabic: matches, string: matches ? string : null };
}

function getArabicRegex () {
  return /[\u0600-\u06FF]/;
}

export default {
  analyzeSearchKey,
  isEmail,
  isMobileNumber,
  isArabic,
  isCustomId
};


export type CustomIdType = 'branch' | 'request' | 'shipment' | 'direct-order' | 'order' | 'business-profile' | 'invoice' | 'refund-request' | 'refund-claim' | 'payment-capture' | 'car-service' | 'car-services-line-item';