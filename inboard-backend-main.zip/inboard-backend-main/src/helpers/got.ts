import { got } from 'got';
import _ from 'lodash';
import * as Objects from '@helpers/objects.js';

const instance = got.extend({
  handlers: [
    (options, next) => {
      options.context = {};
      Error.captureStackTrace(options.context);
      return next(options);
    }
  ],
  hooks: {
    beforeError: [
      error => {
        const { response } = error;
        (error as any).metadata = { request: getDataForReporting(error.request.options), response: getDataForReporting(response) };
        error.stack += `\n${error.options.context.stack}`;
        if (response?.body) {
          error.message = `${response.statusCode} - ${Objects.safeJSONStringify(response.body)}`;
          (error as any).statusCode = response.statusCode;
          (error as any).error = response.body;
        }
        return error;
      }
    ]
  }
});

export default instance;


function getDataForReporting (requestOrResponse) {
  return _.pick(requestOrResponse, ['body', 'headers', 'statusCode', 'url', 'searchParams']);
}