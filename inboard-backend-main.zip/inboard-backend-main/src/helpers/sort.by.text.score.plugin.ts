import { Schema } from 'mongoose';
/**
 * This plugin is a fix for MongoDB 4.4+, because MongoDB now requires $text search
 * in order to select textScore and sort by it, we now select `score` and sort by it by default
 * if you want to bypass it, you can pass `bypassScoreSorting` as follows:
 * const branches = await Branch.dal.find({
 *   filter: { $text: { $search: 'المصنوري' } },
 *   options: { bypassScoreSorting: true },
 *   sort: '-createdAt'
 *  })
 *
 */

export default function sortByTextScorePlugin (schema: Schema) {
  schema.pre(['find', 'findOne'], sortByScoreIfUsingTextSearch);
}

function sortByScoreIfUsingTextSearch (next) {
  const filter = this.getFilter();
  const options = this.getOptions();

  if (filter?.$text) {
    this._fields = this._fields || {};
    this._fields.score = { $meta: 'textScore' };

    if (!options.bypassScoreSorting) {
      this.options.sort = this.options.sort || {};
      this.options.sort = {
        score: { $meta: 'textScore' },
        ...this.options.sort
      };
    }

  }

  next();
}