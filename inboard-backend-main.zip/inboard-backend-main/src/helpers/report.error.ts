import { Request, Response } from 'express';
import moment from 'moment';
import { CustomError, ValidationError } from '@helpers/errors.js';
import * as Objects from '@helpers/objects.js';
import { NODE_ENV, PORT } from '@helpers/env.js';
import sendSlack from '@helpers/send.slack.js';

async function reportError (err, req?: Request, res?: Response) {
  try {
    const statusCode = getStatusCode(err);
    res?.status(statusCode);

    sendJSONIfNoneSent(res, { message: err.customMessage || err.message });

    if (err instanceof CustomError && NODE_ENV === 'production') {
      return;
    }

    const text = buildErrorString(err, req);

    const isValidationError = err instanceof ValidationError;

    if (isValidationError && err.warn) {
      await sendSlack({ to: 'validationErrors', text });
    } else if (!isValidationError) {
      await sendSlack({ to: 'productionErrors', text });
    }

    if (NODE_ENV !== 'production') {
      console.log(text);
    }
  } catch (err) {
    console.log('Something went wrong with reportError function.');
    console.log(err);
    const text = buildErrorString(err);
    sendSlack({ to: 'productionErrors', text }).catch(console.error);
  }
}

function buildErrorString (err, req?: Request) {
  const requestInformationText = getRequestInformationText(req);
  const errorInformationText = appendErrorInformationText(err);

  let text = '```';
  if (requestInformationText) {
    text += requestInformationText;
  }
  text += errorInformationText;
  text += '```';

  return text;
}

function appendErrorInformationText (err) {
  return `
Reported on:
${moment().format('YYYY-MM-DD hh:mm:ss A')}

${(typeof err.stack) === 'object' ? Objects.safeJSONStringify(err.stack) : (err.stack || err.message || err)}
${(typeof err) === 'object' ? `\n${stringifyAndHideSecrets(err)}` : ''}
${(typeof err?.metadata) === 'object' ? `\n${stringifyAndHideSecrets(err.metadata)}` : ''}`;
}

function getRequestInformationText (req: Request) {
  if (!req) {
    return '';
  }
  return `
transactionId:
${req?.__logger?.transactionId}

req.url:
${req.url}

req.method:
${req.method}

req.params:
${stringifyAndHideSecrets(req.params)}

req.query:
${stringifyAndHideSecrets(req.query)}

req.body:
${stringifyAndHideSecrets(req.body)}

req.user:
${stringifyAndHideSecrets(req.user)}

userAgent:
${Objects.safeJSONStringify(req.device.parser.useragent)}

PORT:
${PORT}

App version:
${req.header('App-version')}
`;
}

function getStatusCode (err) {
  if (err instanceof ValidationError || err instanceof CustomError) {
    return 400;
  }

  return 500;
}

export default reportError;

function stringifyAndHideSecrets (value) {
  const maskedValue = hideSecrets(value);
  return Objects.safeJSONStringify(maskedValue);
}

function hideSecrets (value) {
  return Objects.maskSensitiveFields(value, /password|token|secret|auth|base64/i);
}

function sendJSONIfNoneSent (res: Response, responseBody) {
  if (!res?.headersSent) {
    res?.json(responseBody);
  }
}