import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.set(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('should store a key value pair', async () => {
    // Arrange
    // Act
    await redis.set('AAA', 'BBB');

    // Assert
    const size = await redis.dbsize();
    assert.strictEqual(size, 1);
  });

  it('should overwrite value for the same given key', async () => {
    // Arrange
    await redis.set('AAA', 'BBB');

    // Act
    await redis.set('AAA', 'CCC');

    // Assert
    const value = await redis.get('AAA');
    assert.strictEqual(value, 'CCC');
  });
});