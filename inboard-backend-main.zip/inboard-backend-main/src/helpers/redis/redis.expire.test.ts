import assert from 'node:assert';
import Bluebird from 'bluebird';
import { redis } from '@helpers/redis/index.js';

describe('redis.expire(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('returns null when key expires', async () => {
  // Arrange
    await redis.set('AAA', '123');

    // Act
    await redis.expire('AAA', 1);
    await Bluebird.delay(2000);
    const result = await redis.get('AAA');

    // Assert
    assert.strictEqual(result, null);
  });

  it('returns value when key hasn\'t expired', async () => {
    // Arrange
    await redis.set('AAA', '123');

    // Act
    await redis.expire('AAA', 10);
    const result = await redis.get('AAA');

    // Assert
    assert.strictEqual(result, '123');
  });
});