import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.unlink(...)', () => {
  it('should return 0 when no keys are deleted', async () => {
    // Arrange
    const keys = ['A', 'B', 'C'];
    // Act
    const deletedKeysNum = await redis.unlink(keys);

    // Assert
    assert.strictEqual(deletedKeysNum, 0);
  });

  it('should return 2 when 2 keys are deleted', async () => {
    // Arrange
    await redis.set('A', 'B');
    await redis.hset('AA', { AAA: 1, BBB: 2, CCC: 3 });
    await redis.set('AAA', 'BBB');

    // Act
    const deletedKeysNum = await redis.unlink(['A', 'AA']);

    // Assert
    assert.strictEqual(deletedKeysNum, 2);
  });
});