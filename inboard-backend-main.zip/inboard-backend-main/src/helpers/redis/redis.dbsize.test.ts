import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.dbsize()', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('should return 0 when redis db is empty', async () => {
    // Arrange
    // Act
    const size = await redis.dbsize();

    // Assert
    assert.strictEqual(size, 0);
  });

  it('should return 2 when 2 keys are inserted', async () => {
    // Arrange
    await redis.set('A', 'B');
    await redis.set('AA', 'BB');

    // Act
    const size = await redis.dbsize();

    // Assert
    assert.strictEqual(size, 2);
  });

  it('should return 1 when 2 keys are inserted and 1 is deleted', async () => {
    // Arrange
    await redis.set('A', 'B');
    await redis.set('AA', 'BB');
    await redis.unlink(['A']);

    // Act
    const size = await redis.dbsize();

    // Assert
    assert.strictEqual(size, 1);
  });
});