import Redis, { RedisOptions } from 'ioredis';
import { REDIS_HOST, REDIS_PORT, REDIS_DB_PASSWORD } from '@helpers/env.js';

const redisOptions = getRedisOptions();

const redis = new Redis(redisOptions);

export default redis;

function getRedisOptions (): RedisOptions {
  return {
    port: Number(REDIS_PORT) || 6379,
    host: REDIS_HOST || 'localhost',
    db: 0,
    password: REDIS_DB_PASSWORD
  };
}