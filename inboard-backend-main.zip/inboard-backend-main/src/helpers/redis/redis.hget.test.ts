import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.hget(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('should return null for a non-existing key field pair', async () => {
    // Arrange
    // Act
    const value = await redis.hget('AAA', 'BBB');

    // Assert
    assert.strictEqual(value, null);
  });

  it('should get value for an existing key field pair', async () => {
    // Arrange
    await redis.hset('AAA', { field1: 'BBB' });

    // Act
    const value = await redis.hget('AAA', 'field1');

    // Assert
    assert.strictEqual(value, 'BBB');
  });
});