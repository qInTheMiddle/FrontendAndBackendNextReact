import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.hdel(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('should return 0 when no fields are deleted', async () => {
    // Arrange
    const key = 'A';
    const fields = ['AAA', 'BBB', 'CCC'];
    // Act
    // @ts-expect-error
    const deletedKeysNum = await redis.hdel(key, fields);

    // Assert
    assert.strictEqual(deletedKeysNum, 0);
  });

  it('should return 2 when 2 fields are deleted', async () => {
    // Arrange
    await redis.hset('A', { AAA: 1, BBB: 2, CCC: 3 });

    // Act
    // @ts-expect-error
    const deletedFieldsNum = await redis.hdel('A', ['AAA', 'BBB']);

    // Assert
    assert.strictEqual(deletedFieldsNum, 2);
  });
});