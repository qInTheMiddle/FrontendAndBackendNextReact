import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.get(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('should return null for a non-existing key', async () => {
    // Arrange
    // Act
    const value = await redis.get('AAA');

    // Assert
    assert.strictEqual(value, null);
  });

  it('should return a value for an existing key', async () => {
    // Arrange
    await redis.set('AAA', 'BBB');

    // Act
    const value = await redis.get('AAA');

    // Assert
    assert.strictEqual(value, 'BBB');
  });
});