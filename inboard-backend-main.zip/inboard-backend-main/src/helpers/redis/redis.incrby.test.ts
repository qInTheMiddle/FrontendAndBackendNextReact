import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.hincrby(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('sets the value if hash key is not present', async () => {
    // Arrange
    const hashKey = 'hyperpayResultCodes';
    const hashField = 'ABC';

    // Act
    const result = await redis.hincrby(hashKey, hashField, 1);

    // Assert
    assert.strictEqual(result, 1);
  });

  it('increments the value if both hash key and field are present', async () => {
    // Arrange
    const hashKey = 'hyperpayResultCodes';
    const hashField = 'ABC';
    await redis.hset(hashKey, { [hashField]: 20 });


    // Act
    const result = await redis.hincrby(hashKey, hashField, 1);

    // Assert
    assert.strictEqual(result, 21);
  });

  it('increments more than one', async () => {
    // Arrange
    const hashKey = 'hyperpayResultCodes';
    const hashField = 'ABC';
    await redis.hset(hashKey, { [hashField]: 20 });


    // Act
    const result = await redis.hincrby(hashKey, hashField, 10);

    // Assert
    assert.strictEqual(result, 30);
  });
});