import assert from 'node:assert';
import { redis } from '@helpers/redis/index.js';

describe('redis.hset(...)', () => {
  beforeEach(async () => {
    await redis.flushdb();
  });

  it('should store a key object pair', async () => {
    // Arrange
    const key = 'AAA';
    const obj = { field1: 'BBB', field2: 'CCC' };

    // Act
    await redis.hset(key, obj);

    // Assert
    const size = await redis.dbsize();
    assert.strictEqual(size, 1);
  });

  it('should overwrite value for the same given key and field', async () => {
    // Arrange
    await redis.hset('AAA', { field1: 'BBB', field2: 'CCC' });

    // Act
    await redis.hset('AAA', { field1: '123' });

    // Assert
    const value = await redis.hget('AAA', 'field1');
    assert.strictEqual(value, '123');
  });

  it('should not overwrite other values when a certain key and field changes', async () => {
    // Arrange
    await redis.hset('AAA', { field1: 'BBB', field2: 'CCC' });

    // Act
    await redis.hset('AAA', { field1: '123' });

    // Assert
    const value = await redis.hget('AAA', 'field2');
    assert.strictEqual(value, 'CCC');
  });

  it('should add other field values to a key', async () => {
    // Arrange
    await redis.hset('AAA', { field1: 'BBB', field2: 'CCC' });

    // Act
    await redis.hset('AAA', { field3: '123', field4: '567' });

    // Assert
    const field1 = await redis.hget('AAA', 'field1');
    const field2 = await redis.hget('AAA', 'field2');
    const field3 = await redis.hget('AAA', 'field3');
    const field4 = await redis.hget('AAA', 'field4');
    assert.strictEqual(field1, 'BBB');
    assert.strictEqual(field2, 'CCC');
    assert.strictEqual(field3, '123');
    assert.strictEqual(field4, '567');
  });

  it('should add multiple key object pairs', async () => {
    // Arrange
    const key1 = 'AAA';
    const obj1 = { field1: 'BBB', field2: 'CCC' };
    const key2 = 'BBB';
    const obj2 = { field1: '123', field2: '567' };

    // Act
    await redis.hset(key1, obj1);
    await redis.hset(key2, obj2);

    // Assert
    const size = await redis.dbsize();
    assert.strictEqual(size, 2);
  });
});