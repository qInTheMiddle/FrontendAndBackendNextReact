import os from 'node:os';
import path from 'node:path';

const CONSTANTS = Object.freeze({
  TEMPLATE_NAME_TO_ID_MAP: Object.freeze({
    signupAndVerify: 'd-070b459bec444f29ad53d805a367e90a',
    emailVerification: 'd-fcbf3f4e705147e08f93633662c44a04',
    applicationPaid: 'd-edb34aa0dbca446f97c151fb96369fff',
    teamInterview: 'd-6e86dd7e6ae84e3985f2bbfb7f528e07',
    opportunityInterview: 'd-fb6e2cdc7b064766a981662d086ed29c',
    applicationAccepted: 'd-b7ea8ea8c8494b8882be3d4f39edb9d1',
    applicationRejected: 'd-187728bb3696465980c14524d5083801',
    opportunityPaid: 'd-591feefef1e54edfb4d5666e82669581',
    resetPassword: 'd-5e9e40a773f442e09e8206c50efcf775',
    invoice: 'd-8a108ae8d9d8485786f06b3965568ad9',
    creditNote: 'd-752320340f5345c587f81a6d1f5def77',
    proformaInvoice: 'd-8ced78dbff7a4d14aa0c5ae63b8a2ae2',
    companySignupAndVerify: 'd-2fa65f28c97d483da5f808abbb8511d2',
    companyEmailVerification: 'd-49536e24b1304dd4a7d5e70974735e0c',
    companyActivated: 'd-e5081171ff98476cabacac356193579e'
  }),
  FRONTEND_DOMAIN: 'https://inboard.sa',
  // FRONTEND_DOMAIN: 'http://localhost:3000',
  VAT_PERCENTAGE: 0.15,
  ASSETS_DIRECTORY_PATH: getAssetsDirectory(),
  S3_BUCKETS: {
    INBOARD: 'inboard-demo'
  }
});


function getAssetsDirectory () {
  const isWindows = os.platform() === 'win32';

  const assetsDirectory = `file:///${path.resolve('./views')}`;

  if (isWindows) {
    return assetsDirectory.replace(/\\/g, '/');
  }
  return assetsDirectory;
}

export default CONSTANTS;