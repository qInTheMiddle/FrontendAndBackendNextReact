import pdf, { CreateOptions } from 'html-pdf';

function htmlToPDFBuffer ({ html, pdfOptions }: { html: string, pdfOptions: CreateOptions }): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    pdf.create(html, { ...pdfOptions, localUrlAccess: true, childProcessOptions: {
      env: {
        OPENSSL_CONF: '/dev/null'
      }
    }
    }).toBuffer((err, buffer) => {
      if (err) {
        return reject(err);
      }
      resolve(buffer);
    });
  });
}

export default htmlToPDFBuffer;