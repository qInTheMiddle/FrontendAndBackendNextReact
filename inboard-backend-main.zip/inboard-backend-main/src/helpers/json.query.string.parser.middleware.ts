import { Request, Response, NextFunction } from 'express';

function JSONQueryStringParserMiddleware (req: Request, res: Response, next: NextFunction) {
  if (req.query.JSONQueryString == null) {
    return next();
  }

  const keys = Object.keys(req.query);

  if (keys.length > 1) {
    const nonJSONQueryStringKeys = keys.filter(key => key !== 'JSONQueryString');
    throw new Error(`Expecting a single field \`JSONQueryString\` with all the data as JSONString, received \`${nonJSONQueryStringKeys.join(', ')}\` as well. Add them to the JSON string.`);
  }

  try {
    req.query = JSON.parse(req.query.JSONQueryString as any);
  } catch (err) {
    throw new Error(`JSONQueryString expects valid JSON, received the following instead.\n${req.query.JSONQueryString}`);
  }

  next();
}

export default JSONQueryStringParserMiddleware;