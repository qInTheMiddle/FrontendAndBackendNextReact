import reportError from '@helpers/report.error.js';
import { IncomingWebhook, IncomingWebhookSendArguments } from '@slack/webhook';
import { NODE_ENV, SLACK_DEV_NOTIFICATIONS_WEBHOOK, SLACK_PRODUCTION_ERRORS_WEBHOOK, SLACK_VALIDATION_ERRORS_WEBHOOK } from '@helpers/env.js';

export interface ISendSlack {
  to: 'productionErrors' | 'validationErrors' | 'devNotifications';
  text: string;
  customId?: string;
  link?: string;
  attachmentsFields?: Array<{
    title: string;
    value: string;
    short: boolean;
  }>;
  attachmentColor?: 'good' | 'warning' | 'danger';
}

async function sendSlack ({ to, text, customId, link, attachmentsFields, attachmentColor }: ISendSlack) {
  try {
    if (NODE_ENV !== 'production' && to !== 'devNotifications') {
      return;
    }
    const webhookBody = {
      text,
      attachments: handleAttachments()
    };

    const webhook = getWebhook({ channelName: to });
    await webhook.send(webhookBody);
  } catch (err) {
    reportError(err);
  }

  function handleAttachments () {
    let attachments: IncomingWebhookSendArguments['attachments'];

    if (link && customId) {
      attachments = [{
        fallback: `${customId} ${link}`,
        actions: [{ type: 'button', text: customId, url: link }]
      }];
    }

    if (attachmentsFields?.length) {
      attachments = [{
        fallback: text,
        text,
        fields: attachmentsFields,
        color: attachmentColor
      }];
    }
    return attachments;
  }
}

function getWebhook ({ channelName }: { channelName: string }) {
  const webhook: IncomingWebhook = getAllWebhooks()[channelName];
  if (!webhook) {
    throw new Error(`No webhook URL registered for ${channelName}.`);
  }

  return webhook;
}


const allWebhooks = {
  productionErrors: generateWebhook(SLACK_PRODUCTION_ERRORS_WEBHOOK),
  validationErrors: generateWebhook(SLACK_VALIDATION_ERRORS_WEBHOOK),
  devNotifications: generateWebhook(SLACK_DEV_NOTIFICATIONS_WEBHOOK)

};
function getAllWebhooks () {
  return allWebhooks;
}

function generateWebhook (webhookURL) {
  return new IncomingWebhook(webhookURL || 'https://hooks.slack.com/services/PLACEHOLDER');
}
export default sendSlack;