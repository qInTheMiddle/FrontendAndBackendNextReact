import { Schema } from 'mongoose';
import Counter, { CounterFor, CounterPrefix } from '@modules/counters/index.js';

const usedDocumentsNames = [];

function injectCustomIdCreator<T> ({ schema, documentName, prefix }: IInjectCustomIdCreatorParams<T>) {
  const documentNameIsUsedBefore = usedDocumentsNames.includes(documentName);
  if (documentNameIsUsedBefore) {
    throw new Error(`Can not use the same document name twice. ${documentName}`);
  }

  usedDocumentsNames.push(documentName);

  schema.path('customId', { type: String, required: true, uppercase: true });
  schema.index({ customId: 1 }, { unique: true });
  schema.pre('validate', async function createCustomId () {
    if (!this.isNew) {
      return;
    }

    const doc = this;

    const { count } = await Counter.dal.findOneAndUpdate({
      filter: { counterFor: documentName },
      update: { $inc: { count: 1 } },
      options: { new: true, upsert: true },
      select: 'count',
      lean: true
    });

    (doc as any).customId = `${prefix.toUpperCase()}${count}`;
  });
}

export default injectCustomIdCreator;

interface IInjectCustomIdCreatorParams<T> {
  schema: Schema<T>;
  documentName: CounterFor;
  prefix: CounterPrefix;
}