import { randomUUID } from 'node:crypto';

function integer (min = 0, max = 1) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return min + Math.floor(Math.random() * (max - min + 1));
}

function float (min = 0, max = 1) {
  return min + Math.random() * (max - min);
}

export default {
  float,
  integer,
  uuid: randomUUID
};