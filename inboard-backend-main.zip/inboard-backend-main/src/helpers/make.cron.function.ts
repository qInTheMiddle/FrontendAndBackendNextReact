import reportError from '@helpers/report.error.js';
import * as CRON_STATE from '@helpers/cron.state.js';

function makeCronFunction ({
  cronFunctionToRun,
  logOnStartAndEnd,
  disallowOverlap
}: IMakeCronFunctionParams) {
  return async function () {
    if (CRON_STATE.IS_SERVER_SHUTTING_DOWN) {
      return;
    }

    if (CRON_STATE.RUNNING_CRON_JOBS.has(cronFunctionToRun) && disallowOverlap) {
      console.log(`${cronFunctionToRun.name} has been prevented from overlapping at ${new Date()}.`);
      return;
    }

    if (logOnStartAndEnd) {
      console.log(`Running ${cronFunctionToRun.name} ${new Date()}`);
    }

    CRON_STATE.RUNNING_CRON_JOBS.add(cronFunctionToRun);

    try {
      await cronFunctionToRun();
    } catch (err) {
      reportError(err);
    } finally {
      CRON_STATE.RUNNING_CRON_JOBS.delete(cronFunctionToRun);
      if (logOnStartAndEnd) {
        console.log(`Done with ${cronFunctionToRun.name} ${new Date()}`);
      }
    }
  };
}

export default makeCronFunction;

interface IMakeCronFunctionParams {
  cronFunctionToRun: Function;
  logOnStartAndEnd: boolean;
  disallowOverlap: boolean;
}