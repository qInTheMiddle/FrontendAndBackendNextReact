import { Schema } from 'mongoose';

function paginationPlugin (schema: Schema) {
  // @ts-expect-error
  schema.query.paginate = function ({ documentsPerPage, page }: { documentsPerPage: number, page: number }) {
    const numbersArePositive = documentsPerPage > 0 && page > 0;
    if (numbersArePositive === false) {
      return this;
    }

    const skipDocumentsCount = documentsPerPage * (page - 1);
    return this.skip(skipDocumentsCount).limit(documentsPerPage);
  };
}

export default paginationPlugin;