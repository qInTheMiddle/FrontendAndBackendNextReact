import _ from 'lodash';
import * as Objects from '@helpers/objects.js';
const { get } = _;

function groupBy<T> (items: T[], fields: string[] | string): T[][] {
  prepareParams();

  const groups = {};

  items.forEach((object) => {
    const groupValues = (fields as string[]).map(field => get(object, field));
    const groupKey = Objects.safeJSONStringify(groupValues);

    groups[groupKey] = groups[groupKey] || [];

    groups[groupKey].push(object);
  });

  return Object.values(groups);

  function prepareParams () {
    if (typeof fields === 'string') {
      fields = [fields];
    }

    if (!Array.isArray(fields)) {
      throw new Error('`fields` must be either a string or an array of strings.');
    }
  }
}

export default groupBy;