import createPayment from './tap.create.payment.js';
import verifyPayment from './tap.verify.payment.js';
import listPayments from './tap.list.payments.js';

export default {
  createPayment,
  verifyPayment,
  listPayments
};