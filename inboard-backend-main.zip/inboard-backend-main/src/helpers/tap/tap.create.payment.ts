import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TAP_TOKEN, TAP_URL, TAP_REDIRECTION_URL } from '@helpers/env.js';
import { IUser } from '@modules/users/index.js';
import { IApplication } from '@modules/applications/index.js';

async function createTapPayment ({
  amount,
  firstName,
  lastName,
  email,
  mobileCC,
  mobile,
  applicationId,
  paymentFor,
  userId
}: ICreateTapPayment) {

  const { statusCode, body } = await executeRequest({
    amount,
    firstName,
    lastName,
    email,
    mobileCC,
    mobile,
    applicationId,
    paymentFor,
    userId
  });

  if (statusCode !== 200) {
    return { statusCode, message: body.errors[0].description };
  }

  return { statusCode, paymentUrl: (body as createTapPaymentResponse).transaction.url };
}

export default createTapPayment;

async function executeRequest ({
  amount,
  firstName,
  lastName,
  email,
  mobileCC,
  mobile,
  applicationId,
  paymentFor,
  userId
}) {
  return await makeHttpRequest({
    url: `${TAP_URL}/charges`,
    method: 'POST',
    body: {
      amount,
      currency: 'SAR',
      customer: {
        first_name: firstName,
        last_name: lastName,
        email,
        phone: {
          country_code: mobileCC,
          number: mobile
        }
      },
      metadata: {
        applicationId,
        paymentFor,
        userId
      },
      source: { id: 'src_all' },
      redirect: { url: TAP_REDIRECTION_URL }
    },
    headers: {
      Authorization: `Bearer ${TAP_TOKEN}`
    },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}
interface ICreateTapPayment {
  amount: number;
  firstName: IUser['firstName'];
  lastName: IUser['lastName'];
  email: IUser['email'];
  mobileCC: IUser['mobileCC'];
  mobile: IUser['mobile'];
  applicationId: IApplication['_id'];
  paymentFor: string;
  userId: IUser['_id'];
}


interface createTapPaymentResponse {
  id: string;
  object: string;
  live_mode: boolean;
  api_version: string;
  method: string;
  status: string;
  amount: number;
  currency: string;
  threeDSecure: boolean;
  card_threeDSecure: boolean;
  save_card: boolean;
  merchant_id: string;
  product: string;
  metadata: {
    applicationId: string;
    paymentFor: string;
    userId: string;
  };
  transaction: {
    timezone: string;
    created: string;
    url: string;
    expiry: {
      period: number;
      type: string;
    };
    asynchronous: boolean;
    amount: number;
    currency: string;
  };
  response: {
    code: string;
    message: string;
  };
  receipt: {
    email: boolean;
    sms: boolean;
  };
  customer: {
    first_name: string;
    last_name: string;
    email: string;
    phone: {
      country_code: string
      number: string
    };
  }
  merchant: {
    id: string;
  };
  source: {
    object: string;
    id: string;
  };
  redirect: {
    status: string;
    url: string;
  };
  activities: Array<{
    id: string;
    object: string;
    created: number;
    status: string;
    currency: string;
    amount: number;
    remarks: string;
  }>;
  auto_reversed: boolean;
}