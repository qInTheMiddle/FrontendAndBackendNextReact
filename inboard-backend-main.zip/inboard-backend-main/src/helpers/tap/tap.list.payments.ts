import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TAP_URL, TAP_TOKEN } from '@helpers/env.js';
import { ITap } from '@modules/payments/index.js';

async function listTapPayments ({ status, startDate, endDate }) {
  let startingAfterPaymentId;
  let hasMorePayments = true;
  const tapPaymets: ITap[] = [];

  while (hasMorePayments) {
    const { statusCode, body } = await executeRequest({
      startingAfterPaymentId,
      status,
      startDate,
      endDate
    }) as { statusCode: number, body: IListTapPaymentsResponse };
    if (statusCode !== 200) {
      throw new Error('Could not list tap payments.');
    }

    hasMorePayments = body.has_more;

    tapPaymets.push(...body.charges);
    startingAfterPaymentId = body.charges[body.charges.length - 1].id;
  }

  return { tapPaymets };
}

export default listTapPayments;

async function executeRequest ({ startingAfterPaymentId, status, startDate, endDate }) {
  return await makeHttpRequest({
    url: `${TAP_URL}/charges/list`,
    method: 'POST',
    body: {
      period: {
        date: {
          from: startDate,
          to: endDate
        }
      },
      status,
      starting_after: startingAfterPaymentId,
      limit: 50
    },
    headers: { Authorization: `Bearer ${TAP_TOKEN}` },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}

interface IListTapPaymentsResponse {
  object: string,
  live_mode: boolean,
  count: number,
  total_count: number,
  has_more: boolean,
  api_version: string,
  charges: ITap[]
}