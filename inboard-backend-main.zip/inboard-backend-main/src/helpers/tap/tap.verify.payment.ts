import { makeHttpRequest } from '@helpers/make.http.request.js';
import { TAP_URL, TAP_TOKEN } from '@helpers/env.js';
import { ITap } from '@modules/payments/index.js';

async function getTapPayment ({ tapPaymentId }) {
  const { statusCode, body } = await executeRequest({ tapPaymentId });

  if (statusCode !== 200) {
    return { statusCode, message: body.errors[0].description };
  }
  if (body.status !== 'CAPTURED') {
    return { statusCode: 400, message: 'Payment failed.' };
  }

  return { statusCode, tapPayment: (body as ITap) };
}

export default getTapPayment;

async function executeRequest ({ tapPaymentId }) {
  return await makeHttpRequest({
    url: `${TAP_URL}/charges/${tapPaymentId}`,
    method: 'GET',
    headers: { Authorization: `Bearer ${TAP_TOKEN}` },
    throwHttpErrors: false,
    resolveWithFullResponse: true
  });
}