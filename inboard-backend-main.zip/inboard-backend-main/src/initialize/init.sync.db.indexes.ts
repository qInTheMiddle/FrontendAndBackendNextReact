import mongoose from 'mongoose';
import reportError from '@helpers/report.error.js';
import { PORT } from '@helpers/env.js';

if (PORT === '3000') {
  mongoose.syncIndexes().catch(reportError);
}