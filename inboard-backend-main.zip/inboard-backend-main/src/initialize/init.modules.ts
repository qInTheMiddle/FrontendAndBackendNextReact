import { Application } from 'express';
import acl from '@helpers/acl.js';
import applicationsInitialization from '@modules/applications/applications.initialize.js';
import opportunitiesInitialization from '@modules/opportunities/opportunities.initialize.js';
import companiesInitialization from '@modules/companies/companies.initialize.js';
import paymentsInitialization from '@modules/payments/payments.initialize.js';
import usersInitialization from '@modules/users/users.initialize.js';
import coreInitialization from '@modules/core/core.initialize.js';
import paymentCapturesInitialize from '@modules/payment.captures/payment.captures.initialize.js';
import invoicesInitialize from '@modules/invoices/invoices.initialize.js';
export default function (app: Application) {
  applicationsInitialization(app, acl);
  opportunitiesInitialization(app, acl);
  companiesInitialization(app, acl);
  paymentsInitialization(app, acl);
  usersInitialization(app, acl);
  coreInitialization(app, acl);
  paymentCapturesInitialize(app, acl);
  invoicesInitialize(app, acl);
}