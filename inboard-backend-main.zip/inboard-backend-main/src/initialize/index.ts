import { Application } from 'express';
import './init.env.js';
import './init.database.js';
import './init.auth.js';
import initExpress from './init.express.js';
import initModules from './init.modules.js';
import './init.sync.db.indexes.js';

export default function (app: Application) {
  initExpress(app);
  initModules(app);
}