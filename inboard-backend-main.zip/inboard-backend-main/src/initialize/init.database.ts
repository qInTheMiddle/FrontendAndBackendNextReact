import mongoose from 'mongoose';
import mongooseCastAggregationPlugin from 'mongoose-cast-aggregation';
import * as makeFixed from '@helpers/make.fixed.js';
import setIdToUndefinedIfFalsy from '@helpers/set.id.to.undefined.if.falsy.js';
import setSchemaDefaultOptionsPlugin from '@helpers/set.schema.default.options.plugin.js';
import sortByTexTScorePlugin from '@helpers/sort.by.text.score.plugin.js';
import paginationPlugin from '@helpers/pagination.plugin.js';
import { NODE_ENV, DB_CLUSTER, DB_USERNAME, DB_PASSWORD, DB_NAME } from '@helpers/env.js';

setMongooseOptions();

const mongoURI = getMongoURI();
const mongoOptions = getMongoOptions();

mongoose.connect(mongoURI, mongoOptions);

function setMongooseOptions () {
  mongoose.SchemaTypes.Number.set('set', makeFixed.floor);
  mongoose.SchemaTypes.ObjectId.set('set', setIdToUndefinedIfFalsy);
  mongoose.SchemaTypes.String.set('trim', true);
  mongoose.SchemaTypes.Boolean.set('default', false);

  mongoose.plugin(mongooseCastAggregationPlugin);
  mongoose.plugin(setSchemaDefaultOptionsPlugin);
  mongoose.plugin(sortByTexTScorePlugin);
  mongoose.plugin(paginationPlugin);
}

function getMongoURI () {
  let mongoURI;

  switch (NODE_ENV) {
    case 'TEST':
      mongoURI = 'mongodb://localhost:27017/inboard_test';
      break;
    case 'REMOTE_DEV':
    case 'production':
      mongoURI = `mongodb+srv://${DB_USERNAME}:${DB_PASSWORD}@${DB_CLUSTER}`;
      break;
    default:
      throw new Error(`Unknown node environment \`${NODE_ENV}\``);
  }
  return mongoURI;
}

function getMongoOptions () {
  let mongoOptions;

  switch (NODE_ENV) {
    case 'TEST':
    case 'REMOTE_DEV':
    case 'production':
      mongoOptions = {
        maxPoolSize: 1000,
        retryWrites: true,
        w: 'majority',
        dbName: DB_NAME
      };
      break;
    default:
      throw new Error(`Unknown node environment \`${NODE_ENV}\``);
  }
  return mongoOptions;
}