import passport from 'passport';
import passportJwt from 'passport-jwt';
import { JWT_SECRET_KEY } from '@helpers/env.js';

const { Strategy: JwtStrategy, ExtractJwt } = passportJwt;

const jwtStrategyOptions = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: JWT_SECRET_KEY,
  algorithms: ['HS256']
};

const jwtStrat = new JwtStrategy(jwtStrategyOptions, (payload, done) => {
  done(null, payload);
});

passport.use(jwtStrat);