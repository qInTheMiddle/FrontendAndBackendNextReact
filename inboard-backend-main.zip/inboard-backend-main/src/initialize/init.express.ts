import helmet from 'helmet';
import cors from 'cors';
import compress from 'compression';
import hbs from 'express-hbs';
import HandlebarsIntl from 'handlebars-intl';
import path from 'node:path';
import express, { Application } from 'express';
import morgan from 'morgan';
import passport from 'passport';
import expressDevice from 'express-device';
import makeCallback from '@helpers/make.callback.js';
import JSONQueryStringParserMiddleware from '@helpers/json.query.string.parser.middleware.js';
import Bluebird from 'bluebird';
import { NODE_ENV } from '@helpers/env.js';

export default function (app: Application) {
  app.use(cors({ origin: '*' }));
  if (NODE_ENV !== 'production') {
    app.use(morgan('tiny'));
  }

  app.renderAsync = Bluebird.promisify(app.render);

  app.disable('x-powered-by');
  app.use(passport.initialize());
  app.use(expressDevice.capture({ parseUserAgent: true }));
  app.use(helmet.xssFilter());
  app.use(helmet.noSniff());
  app.use(helmet.ieNoOpen());
  app.use(helmet.hsts({ maxAge: 6 * 30 * 24 * 60 * 60, includeSubDomains: true }));
  app.use(
    compress({
      filter: (req, res) => (/json|text|javascript|css|font|svg|js|mp3/).test(res.getHeader('Content-Type')),
      level: 9
    })
  );

  app.use('/fonts', express.static(path.resolve('views/assets/fonts/')));
  app.engine('hbs', hbs.express4({ extname: '.hbs' }));
  app.set('view engine', 'hbs');
  app.set('views', path.resolve('./views'));
  app.use(makeCallback(JSONQueryStringParserMiddleware));

  HandlebarsIntl.registerWith(hbs);


  hbs.registerHelper('inc', (value) => parseInt(value) + 1);
  hbs.registerHelper('for', (from, to, incr, block) => {
    let accum = '';
    for (let i = from; i < to; i += incr) {
      accum += block.fn(i);
    }
    return accum;
  });
}