import { Schema, CompileModelOptions, Model } from 'mongoose';
import { Model as ModelNames } from '@helpers/generic.types.js';

declare module 'mongoose' {
  interface Query {
    paginate({ documentsPerPage, page }: { documentsPerPage?: number, page?: number }): this;
  }

  function model<T> (
    name: ModelNames,
    schema?: Schema<T, any, any> | Schema<T & Document, any, any>,
    collection?: string,
    options?: CompileModelOptions
  ): Model<T>;
  function model<T, U, TQueryHelpers = {}> (
    name: ModelNames,
    schema?: Schema<T, U, TQueryHelpers>,
    collection?: string,
    options?: CompileModelOptions
  ): U;
}