interface Error {
  metadata?: object;
}