import { IActingUser } from '@modules/users/index.js';

declare module 'express' {
  interface Request {
    user?: IActingUser;
    app: Application;
    device?: any;
    __logger?: {
      transactionId?: string;
      options?: {
        includeResponse?: boolean;
      }
    }
  }

  interface Application {
    renderAsync?: (name: string, options?: object) => Promise<string>;
  }

}