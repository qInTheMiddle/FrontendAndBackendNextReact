const configuration = {
    title: undefined,
    titleTemplate: 'Inboard | %s',
    defaultTitle: 'Inboard - خبرات مهارية في شركات حقيقية',
    description: 'تخرج منها بخبرة عملية و تجارب حقيقية',
    openGraph: {
        url: 'https://inboard.sa/',
        type: 'website',
        title: 'Inboard',
        site_name: 'Inboard',
        description: 'Let the job search for you',
        images: [
            {
                url: 'https://inboard.sa/images/header-logo@3x.png',
                width: 150,
                height: 70,
                alt: 'Inboard'
            }
        ]
    },
    twitter: {
        handle: '@inboard',
        site: '@inboard',
        cardType: 'summary_large_image'
    }
};
export default configuration;