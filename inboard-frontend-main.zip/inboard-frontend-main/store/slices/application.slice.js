import { createSlice } from '@reduxjs/toolkit';

export const applicationsSlice = createSlice({
    name: 'application',
    initialState: {
        applicationId: '',
        opportunityId: '',
        status: ''
    },
    reducers: {
        setApplicationId(state, { payload }) {
            const { applicationId, opportunityId } = payload;
            state.applicationId = applicationId;
            state.opportunityId = opportunityId;
        },
        setApplicationStatus(state, { payload }) {
            state.direction = payload;
        }
    }
});

export const { setApplicationId, setApplicationStatus } = applicationsSlice.actions;

export default applicationsSlice.reducer;