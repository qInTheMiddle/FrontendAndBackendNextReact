import { createSlice } from '@reduxjs/toolkit';
import router from 'next/router';
import { GET } from 'utils';

export const AuthorizationSlize = createSlice({
    name: 'auth',
    initialState: {
        user: {},
        isLoggedIn: false,
        token: null
    },
    reducers: {
        setToken(state, { payload }) {
            state.token = payload;
            state.isLoggedIn = true;
            if (process.browser) {
                localStorage.setItem('inboardUserToken', payload);
            }
        },
        setUser(state, { payload }) {
            state.user = payload;
        },
        logoutUser(state) {
            if (process.browser) {
                localStorage.removeItem('inboardUserToken');
            }
            state.user = {};
            state.isLoggedIn = false;
            state.token = null;

            router.push('/');
        }
    }
});

export const { setToken, setUser, logoutUser } = AuthorizationSlize.actions;

export function loadUserProfileDetails (token) {
    return async function(dispatch) {
        const response = await GET({
            endpoint: '/api/applicant/user/view/',
            token,
            resolveWithFullResponse: true
        });
        if (response?.status === 200) {
            dispatch(setUser(response?.data?.user));

            return response?.data?.user;
        }

        return response;
    };
}

export function resetSlicesAndLogout () {
    return function (dispatch) {
        dispatch(logoutUser());
    };
}

export default AuthorizationSlize.reducer;