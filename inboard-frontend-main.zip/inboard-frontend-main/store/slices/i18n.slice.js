import { createSlice } from '@reduxjs/toolkit';

export const i18nSlice = createSlice({
    name: 'i18n',
    initialState: {
        defaultlocalization: 'ar',
        locale: 'ar',
        direction: 'rtl'
    },
    reducers: {
        setLocale(state, { payload }) {
            state.locale = payload;
        },
        setLocaleDirection(state, { payload }) {
            state.direction = payload;
        }
    }
});

export const { setLocale, setLocaleDirection } = i18nSlice.actions;

export default i18nSlice.reducer;