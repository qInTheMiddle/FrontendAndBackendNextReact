import { createSlice } from '@reduxjs/toolkit';

export const initialState = {};

export const UserSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {}
});

// export actions
// export const {} = UserSlice.actions;

export default UserSlice.reducer;