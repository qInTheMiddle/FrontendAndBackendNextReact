import { createSlice } from '@reduxjs/toolkit';
import { GET } from 'utils';


export const OpportonitiesSlice = createSlice({
    name: 'categories',
    initialState: {
        isLoadingRootOpportonities: true,
        rootOpportonities: []
    },
    reducers: {
        setRootOpportonities(state, { payload }) {
            state.rootOpportonities = payload;
        },
        setLoadingRootOpportonities(state, { payload }) {
            state.isLoadingRootOpportonities = payload;
        },
    }
});

// export actions
export const { setRootOpportonities, setLoadingRootOpportonities } = OpportonitiesSlice.actions;

export const loadRootOpportonities = () => async (dispatch) => {
    dispatch(setLoadingRootOpportonities(true));
    
    const res = await GET({
        endpoint: '/opportunities',
    });

    if(!res) return;
    
    dispatch(setRootOpportonities(res.data || []));

    dispatch(setLoadingRootOpportonities(false));
};

export default OpportonitiesSlice.reducer;
