import { combineReducers, configureStore, getDefaultMiddleware } from '@reduxjs/toolkit';
import { persistStore, persistReducer, FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
// import expireReducer from 'redux-persist-expire';

import i18nSlice from './slices/i18n.slice';
import AuthSlice from './slices/auth.slice';
import OpportonitiesSlice from './slices/opportonities.slice';
import ApplicationsSlice from './slices/application.slice';

const persistConfig = {
    key: 'root',
    version: 1,
    storage,
    whitelist: ['AuthSlice', 'i18nSlice', 'OpportonitiesSlice', 'ApplicationsSlice']
};

const persistedReducer = persistReducer(
    persistConfig,
    combineReducers({
        AuthSlice,
        i18nSlice,
        OpportonitiesSlice,
        ApplicationsSlice
    })
);

export const store = configureStore({
    reducer: persistedReducer,
    devTools: true,
    middleware: getDefaultMiddleware({
        immutableCheck: {},
        serializableCheck: {
            ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER]
        }
    })
});

export const persistor = persistStore(store);