const withPWA = require('next-pwa');
const runtimeCaching = require('next-pwa/cache');
const path = require('path');
// const prod = process.env.NODE_ENV === 'production';


// eslint-disable-next-line no-undef
module.exports = withPWA({
    i18n: {
        locales: ['ar', 'en'],
        defaultLocale: 'ar',
        localePath: path.resolve('./i18n/locales'), // TODO : test the value of this prop
        localeDetection: false
    },
    localePath: path.resolve('./i18n/locales'), // TODO : test the value of this prop
    pwa: {
        disable: true, // TODO : enable when needed
        dest: 'public',
        runtimeCaching
    },
    images: {
        domains: [
        ]
    }
});

const withAntdLess = require('next-plugin-antd-less');

module.exports = withAntdLess({
    // optional: you can modify antd less variables directly here
    modifyVars: {
        // eslint-disable-next-line max-len
        '@font-family': 'IBM Sans Arabic Regular,IBM Sans Arabic Medium,IBM Sans Arabic Bold,-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, Oxygen,Ubuntu, Cantarell, Fira Sans, Droid Sans, Helvetica Neue, sans-serif', // font-family
        '@primary-color': '#fa0e0d', // primary color for all components
        '@layout-header-background': '#ffffff', // background of header
        '@link-color': '#1890ff', // link color
        '@success-color': '#52c41a', // success state color
        '@warning-color': '#faad14', // warning state color
        '@error-color': '#f5222d', // error state color
        '@font-size-base': '14px', // major text font size
        '@heading-color': 'rgba(0, 0, 0, 0.85)', // heading text color
        '@text-color': 'rgba(0, 0, 0, 0.65)', // major text color
        '@text-color-secondary': 'rgba(0, 0, 0, 0.45)', // secondary text color
        '@disabled-color': 'rgba(0, 0, 0, 0.25)', // disable state color
        '@border-radius-base': '4px', // major border radius
        '@border-color-base': '#d9d9d9', // major border color
        '@box-shadow-base': '0 2px 8px rgba(0, 0, 0, 0.15)' // major shadow for layers
    },
    // Or better still you can specify a path to a file
    lessVarsFilePath: './styles/variables.less',
    // optional
    lessVarsFilePathAppendToEndOfContent: false,
    // optional https://github.com/webpack-contrib/css-loader#object
    cssLoaderOptions: {},

    // Other Config Here...

    webpack(config) {
        return config;
    }
});