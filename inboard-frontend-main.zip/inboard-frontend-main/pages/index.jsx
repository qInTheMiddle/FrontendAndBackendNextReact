import React from 'react';
import { FirstFold, HomeOpportunities, WhyInboard } from 'components';
import { GET } from 'utils';
function Home ({ opportunities }) {

    return (
        <div className="index-page">
            <FirstFold/>
            <HomeOpportunities opportunities={opportunities}/>
            <WhyInboard/>

        </div>
    );
}


export default Home;


export async function getServerSideProps() {

    const response = await GET({
        endpoint: '/api/applicant/opportunities/list/sortBy--availableSeats/4/1/'
    });

    if (!response) {
        return {
            props: {
                opportunities: []
            }
        };
    }

    const { opportunities = [] } = response;

    return {
        props: {
            opportunities
        }
    };
}