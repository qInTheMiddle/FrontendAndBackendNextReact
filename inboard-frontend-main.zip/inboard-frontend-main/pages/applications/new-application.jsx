import { Breadcrumb, Button, Steps, Typography } from 'antd';
import React, { useState, useEffect } from 'react';
import { GET, POST, ExtractLocaleField } from 'utils';
import translate from 'i18n/translate.js';
import { StepOne, StepTwo, StepThree, StepFour } from 'components';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { useIntl } from 'react-intl';
const { Title, Paragraph } = Typography;
const { Step } = Steps;

function NewApplication() {
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const { locale } = useIntl();
    const [tapPayment, setTapPayment] = useState({});
    const [tabbyPayment, setTabbyPayment] = useState({});
    const [stepsStatus, setStepsStatus] = useState({
        step0: { isLoading: false, isDisabled: false, isError: false },
        step1: { isLoading: false, isDisabled: false, isError: false },
        step2: { isLoading: false, isDisabled: false, isError: false },
        step3: { isLoading: false, isDisabled: false, isError: false }
    });
    const [current, setCurrent] = useState(0);
    const [opportunityData, setOpportunityData] = useState({ title: { arabic: '', english: '' } });
    const { opportunityDurationInDays = 30 } = opportunityData;

    const opportunityDurationInMonths = Math.floor(opportunityDurationInDays / 30) || 1;
    const router = useRouter();
    const { id, currentStep } = router.query;
    useEffect(() => {
        async function getOpportunityData() {
            const data = await GET({
                endpoint: `/api/applicant/opportunities/${id}/view/`,
                token: AuthSlice.token
            });
            if (!data?.opportunity) {
                router.push('/');
                return;
            }
            setOpportunityData(data.opportunity || {});
        }
        if (id) {
            getOpportunityData();
        }
    }, [id]);

    function applicationIdSetter(id) {
        async function getTapPayment() {
            const { data } = await POST({
                endpoint: '/api/applicant/payments/tap/create/',
                token: AuthSlice.token,
                data: {
                    applicationId: id
                },
                resolveWithFullResponse: true
            });
            console.log('data', data);
            if (data) {
                setTapPayment(data);
            }
        }
        async function getTabbyPayment() {
            const { data } = await POST({
                endpoint: '/api/applicant/payments/tabby/create/',
                token: AuthSlice.token,
                data: {
                    applicationId: id
                },
                resolveWithFullResponse: true
            });
            console.log('data', data);
            if (data) {
                setTabbyPayment(data);
            }
        }
        getTabbyPayment();
        getTapPayment();
    }

    function handleStatus({ step, status }) {
        const stepStatus = stepsStatus[`step${step}`];
        switch (status) {
        case 'completed':
            stepStatus.isLoading = false;
            stepStatus.isDisabled = false;
            stepStatus.isError = false;
            break;
        case 'loading':
            stepStatus.isLoading = true;
            stepStatus.isDisabled = true;
            break;
        case 'untouched':
            stepStatus.isDisabled = true;
            stepStatus.isLoading = false;
            break;

        default:
            stepStatus.isLoading = false;
            stepStatus.isDisabled = false;
            stepStatus.isError = false;
            break;
        }
        setStepsStatus({ ...stepsStatus, stepStatus });
    }
    const steps = [
        {
            title: translate('step_how_to_start'),
            description: translate('step_how_to_start_description_short'),
            content: <StepOne next={next} />
        },
        {
            title: translate('step_personal_information'),
            description: translate('step_personal_information_description_short'),
            content: <StepTwo next={next} prev={prev} />,
            disabled: true
        },
        {
            title: translate('step_professinal_information'),
            description: translate('step_professinal_information_description_short'),
            content: (
                <StepThree
                    next={next} prev={prev}
                    opportunityId={id}
                    duration={opportunityDurationInMonths}
                    setApplicationId={applicationIdSetter}
                />
            )
        },
        {
            title: translate('step_payment'),
            description: translate('step_payment_description_short'),
            content: <StepFour
                statusUpdater={handleStatus}
                tapPayment={tapPayment}
                tabbyPayment={tabbyPayment}
                applicationFees={opportunityData.applicationFees}
            />
        }
    ];

    function next() {
        setCurrent(current + 1);
    }

    function prev() {
        setCurrent(current - 1);
    }

    useEffect(() => {
        if (currentStep === 4) {
            setCurrent(3);
        }
    }, [currentStep]);

    return (
        <>
            <Breadcrumb style={{ margin: '10px auto', width: '100%', maxWidth: '1024px', padding: '10px' }}>
                <Breadcrumb.Item>
                    <Link href={'/'}>
                        <a>{translate('home')}</a>
                    </Link>
                </Breadcrumb.Item>
                {opportunityData ? (
                    <Breadcrumb.Item>
                        <Link href={`/opportunities/${opportunityData.slug}`}>
                            <a>{ExtractLocaleField(opportunityData.title, locale)}</a>
                        </Link>
                    </Breadcrumb.Item>
                ) : null}
                <Breadcrumb.Item>{translate('application_enroll')}</Breadcrumb.Item>
            </Breadcrumb>
            <div className="applications-view">
                <div className="container">
                    <Title level={3} style={{ textAlign: 'center' }}>
                        {translate('application_enroll')}
                    </Title>
                    <Paragraph style={{ textAlign: 'justify' }}>{translate('application_enroll_description')}</Paragraph>
                </div>

                <div className="container">
                    <>
                        <Steps current={current}>
                            {steps.map((item) => (
                                <Step key={item.title} title={item.title} description={item.description} />
                            ))}
                        </Steps>
                        <div>{steps[current].content}</div>
                    </>
                </div>
            </div>
        </>
    );
}

export default NewApplication;