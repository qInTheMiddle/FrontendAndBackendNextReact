import React from 'react';

function ApplicationsHome () {
    return (
        <div>
            nothing here
        </div>
    );
}


export default ApplicationsHome;