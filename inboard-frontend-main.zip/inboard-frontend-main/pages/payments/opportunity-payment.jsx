import { Breadcrumb, Button, Spin, Typography } from 'antd';
import React, { useEffect, useState } from 'react';
import { GET, POST, ExtractLocaleField } from 'utils';
import translate from 'i18n/translate.js';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import Link from 'next/link';
const { Title, Paragraph } = Typography;
const applicationInterface = {
    _id: '',
    userId: '',
    opportunityId: {
        _id: '',
        companyName: 'The Company',
        title: {
            arabic: '',
            english: ''
        }
    },
    applicationFees: 100,
    opportunityFees: 1100

};

export default function ConfirmedAppilcationPayment() {
    const router = useRouter();
    const { applicationId } = router.query;
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const [tapPayment, setTapPayment] = useState({});
    const [applicationData, setApplicationData] = useState(applicationInterface);

    async function getTapPayment() {
        const { data } = await POST({
            endpoint: '/api/applicant/payments/tap/create/',
            token: AuthSlice.token,
            data: {
                applicationId,
                paymentFor: 'opportunity-fees'
            },
            resolveWithFullResponse: true
        });
        if (data) {
            setTapPayment(data);
        }
    }

    useEffect(() => {
        async function getApplicationData() {
            const { data={} } = await GET({
                endpoint: `/api/applicant/applications/${applicationId}/view/`,
                token: AuthSlice.token,
                resolveWithFullResponse: true
            });
            setApplicationData(data?.application || {});

        }
        if (applicationId) {
            getApplicationData();
        }

    }, [applicationId]);

    useEffect(() => {

        if (applicationData._id) {
            getTapPayment();
            return;
        }
        if (!AuthSlice.token) {
            router.push('/login');
        }

    }, [applicationData]);


    return (
        <>
            <Breadcrumb style={{ margin: '10px auto', width: '100%', maxWidth: '1024px', padding: '10px' }}>
                <Breadcrumb.Item>
                    <Link href={'/'}>
                        <a >{translate('home')}</a>
                    </Link>
                </Breadcrumb.Item>
                <Breadcrumb.Item>
                    {
                        applicationData?._id ? <Link href={`/opportunities/${applicationData.opportunityId.slug}`}>
                            <a >
                                {ExtractLocaleField(applicationData.opportunityId.title) }
                            </a>
                        </Link> : null
                    }
                </Breadcrumb.Item>
                <Breadcrumb.Item>{translate('pay_opportunity_fees')}</Breadcrumb.Item>
            </Breadcrumb>
            <div className="payment-view">
                <div className="container">
                    {
                        applicationData?._id ? (
                            <>
                                <div className="opportunity-details">
                                    <Title level={3}>{ExtractLocaleField(applicationData.opportunityId.title)}</Title>
                                    <Paragraph>
                                        {
                                            translate('application_accepted', {
                                                opportunityTitle: ExtractLocaleField(applicationData.opportunityId.title),
                                                companyName: applicationData.opportunityId.companyId.name,
                                                opportunityFees: applicationData.opportunityFees - applicationData.applicationFees
                                            })
                                        }
                                    </Paragraph>
                                </div>
                                <div className="payment-link">

                                    {
                                        tapPayment.paymentUrl
                                            ?
                                            <Link href={tapPayment.paymentUrl} target={'_blank'} passHref>
                                                <Button type="primary link" size="large">
                                                    {translate('open_payment_page')}
                                                </Button>
                                            </Link>
                                            :
                                            <Link href={'#'} target={'_blank'} passHref>
                                                <Button type="primary link" size="large" disabled loading>
                                                    {translate('open_payment_page')}
                                                </Button>
                                            </Link>
                                    }
                                </div>
                            </>) : (<Spin/>)
                    }

                </div>
            </div>

        </>
    );
}