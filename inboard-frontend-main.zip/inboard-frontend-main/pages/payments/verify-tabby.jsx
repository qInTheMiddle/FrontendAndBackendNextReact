import { Result, Spin } from 'antd';
import React, { useEffect } from 'react';
import translate from 'i18n/translate';
import { POST } from 'utils';
import { useIntl } from 'react-intl';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
export default function VerifyPayment() {
    const router = useRouter();
    const intl = useIntl();

    const [paymentStatus, setPaymentStatus] = React.useState({ status: false, message: 'unknown_error' });
    const [loading, setLoading] = React.useState(true);
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const { token } = AuthSlice;
    const { payment_id: tabbyPaymentId, canceled, failed, success } = router.query;
    const paymentVerifySuccess = intl.formatMessage({ id: 'payment_verify_success' });
    const paymentVerifySuccessDescription = intl.formatMessage({ id: 'payment_verify_success_description' });
    const paymentVerifyFailed = intl.formatMessage({ id: 'payment_verify_failed' });

    useEffect(() => {


        async function fetchData() {
            const response = await POST({
                endpoint: '/api/applicant/payments/tabby/verify/',
                token,
                data: {
                    tabbyPaymentId
                }
            });
            const { paymentId = '', message = '' } = response;
            if (!tabbyPaymentId || !paymentId) {
                setPaymentStatus({ status: false, message });
                setLoading(false);
                return;
            }
            if (paymentId) {
                setPaymentStatus({ status: true, message: null });
            }
            setLoading(false);

        }

        if (!tabbyPaymentId) {
            setPaymentStatus({ status: false, message: 'unknown_error' });
            return;
        }

        if (canceled === 'true') {
            setPaymentStatus({ status: false, message: 'canceled' });
            setLoading(false);
            return;
        }

        if (failed === 'true') {
            setPaymentStatus({ status: false, message: 'failed' });
            setLoading(false);
            return;
        }


        fetchData();


    }, [canceled, failed, tabbyPaymentId, token]);




    return (
        <>
            <div className="payment-view">
                <div className="container">
                    {
                        loading ? (
                            <div className="loading">
                                <Spin />
                            </div>
                        ) : null
                    }
                    {!loading && !paymentStatus.status &&
                      <Result
                          status="error"
                          title={paymentVerifyFailed}
                          subTitle={translate(`tabby_payment_${paymentStatus.message}`)}

                      />
                    }
                    {!loading && paymentStatus.status &&
                    <Result
                        status="success"
                        title={paymentVerifySuccess}
                        subTitle={paymentVerifySuccessDescription}

                    />
                    }
                </div>

            </div>
        </>
    );
}