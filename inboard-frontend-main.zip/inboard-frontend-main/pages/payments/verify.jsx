import { Result, Spin } from 'antd';
import React, { useEffect } from 'react';
import translate from 'i18n/translate';
import { POST } from 'utils';
import { useIntl } from 'react-intl';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
export default function VerifyPayment() {
    const router = useRouter();
    const intl = useIntl();

    const [paymentStatus, setPaymentStatus] = React.useState({ status: false, message: 'unknown_error' });
    const [loading, setLoading] = React.useState(true);
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const { token } = AuthSlice;
    const { tap_id: tapPaymentId } = router.query;
    const paymentVerifySuccess = intl.formatMessage({ id: 'payment_verify_success' });
    const paymentVerifySuccessDescription = intl.formatMessage({ id: 'payment_verify_success_description' });
    const paymentVerifyFailed = intl.formatMessage({ id: 'payment_verify_failed' });

    useEffect(() => {


        async function fetchData() {
            const response = await POST({
                endpoint: '/api/applicant/payments/tap/verify/',
                token,
                data: {
                    tapPaymentId
                }
            });
            const { paymentId = '', message = '' } = response;
            if (message || !tapPaymentId) {
                setPaymentStatus({ status: false, message });
                setLoading(false);
                return;
            }
            if (paymentId) {
                setPaymentStatus({ status: true, message: null });
            }
            setLoading(false);

        }

        if (!tapPaymentId) {
            setPaymentStatus({ status: false, message: 'unknown_error' });
            return;
        }

        fetchData();


    }, [tapPaymentId, token]);




    return (
        <>
            <div className="payment-view">
                <div className="container">
                    {
                        loading ? (
                            <div className="loading">
                                <Spin />
                            </div>
                        ) : null
                    }
                    {!loading && paymentStatus.status === false &&
                      <Result
                          status="error"
                          title={paymentVerifyFailed}
                          subTitle={translate(paymentStatus.message)}

                      />
                    }
                    {!loading && paymentStatus.status === true &&
                    <Result
                        status="success"
                        title={paymentVerifySuccess}
                        subTitle={paymentVerifySuccessDescription}

                    />
                    }
                </div>

            </div>
        </>
    );
}