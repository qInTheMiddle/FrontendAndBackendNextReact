import { Typography, Button, Form, Input, message } from 'antd';
import { useRouter } from 'next/router';
import { POST } from 'utils';
import React from 'react';
import translate from 'i18n/translate';
import Link from 'next/link';
import { useDispatch } from 'react-redux';
import { setToken } from 'store/slices/auth.slice';
import { useIntl } from 'react-intl';
const { Title } = Typography;

export default function Login() {
    const dispatch = useDispatch();
    const router = useRouter();
    const intl = useIntl();
    const [isButtonDisabled, setIsButtonDisabled] = React.useState(true);
    function handleEvent (changedFields, allFields) {
        const areAllFieldsValid = allFields.every((field) => !field.errors?.length && field.value);
        if (areAllFieldsValid) {
            setIsButtonDisabled(false);
        }
    }

    async function onFinish (values) {

        const { email, password } = values;
        const loginResult = await POST({
            endpoint: '/api/applicant/user/login/',
            data: { email, password }
        });


        if (loginResult.accessToken) {
            if (typeof window !== 'undefined') {
                localStorage.setItem('inboardUserToken', loginResult.accessToken);
            }
            dispatch(setToken(loginResult.accessToken));
            router.push('/');
            return;
        }

        if (loginResult.message) {
            const errorMessage = intl.formatMessage({ id: loginResult.message || 'unknown_error' });
            message.error(errorMessage);
            return;
        }
    }

    return (
        <>
            <div className="auth-view">
                <div className="container">
                    <Title style={{ textAlign: 'center' }} level={3}>
                        {translate('login_title')}
                    </Title>
                </div>
                <div className="container">
                    <Form
                        name="register"
                        labelCol={{ span: 6 }}
                        wrapperCol={{ span: 16 }}
                        initialValues={{ remember: true }}
                        onFinish={onFinish}
                        onFieldsChange={handleEvent}>
                        <Form.Item
                            name="email"
                            label={translate('register_form_label_email')}
                            rules={[
                                {
                                    type: 'email',
                                    message: translate('register_form_error_email_not_valid')
                                },
                                {
                                    required: true,
                                    message: translate('register_form_error_email_required')
                                }
                            ]}>
                            <Input />
                        </Form.Item>
                        <Form.Item
                            name="password"
                            label={translate('register_form_label_password')}
                            rules={[
                                {
                                    required: true,
                                    message: translate('register_form_error_password_required')
                                }
                            ]}>
                            <Input.Password />
                        </Form.Item>
                        <Form.Item wrapperCol={{ span: 24 }} style={{ textAlign: 'center' }}>
                            <Button type="primary" htmlType="submit" disabled={isButtonDisabled}>
                                {translate('login_form_submit')}
                            </Button>
                        </Form.Item>
                        <Form.Item wrapperCol={{ span: 24 }} style={{ textAlign: 'center' }}>
                            <Link passHref href="/auth/register">
                                <Button type="link">{translate('login_form_new_account')}</Button>
                            </Link>
                            <Link passHref href="/auth/forgot-password">
                                <Button type="link">{translate('login_form_reset_password')}</Button>
                            </Link>
                        </Form.Item>
                        <Form.Item wrapperCol={{ span: 24 }} style={{ textAlign: 'center' }}>
                            <Link passHref href="/auth/email-verification">
                                <Button type="link">{translate('request_email_verification')}</Button>
                            </Link>
                        </Form.Item>
                    </Form>
                </div>
            </div>
        </>
    );
}