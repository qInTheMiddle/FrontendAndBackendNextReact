import { Button, Form, Input, Typography, message } from 'antd';
import React from 'react';
import translate from 'i18n/translate';
import { POST } from 'utils';
import { useIntl } from 'react-intl';
const { Title } = Typography;
export default function RequestEmailVerification() {
    const intl = useIntl();
    const [loading, setLoading] = React.useState(false);
    const [buttonDisabled, setButtonDisabled] = React.useState(false);
    const emailVerifyResent = intl.formatMessage({ id: 'email_verify_resent' });
    const unknownError = intl.formatMessage({ id: 'unknown_error' });
    const formEmailLabel = intl.formatMessage({ id: 'form_label_email' });

    async function onFinish (values) {

        setLoading(true);
        setButtonDisabled(true);

        const { email } = values;
        const response = await POST({
            endpoint: '/api/applicant/user/resend-email-verification/',
            data: { email },
            resolveWithFullResponse: true
        });
        setLoading(false);
        const { status } = response || {};

        if (status === 204) {
            setButtonDisabled(true);
            message.success(emailVerifyResent);
            return;
        }
        setButtonDisabled(false);

        message.error(unknownError);

    }


    return (
        <>
            <div className="auth-view">
                <div className="container">

                    <Title level={3}>
                        {translate('email_verify_resend')}
                    </Title>
                    <Form
                        onFinish={onFinish}
                        labelCol={{
                            span: 4
                        }}
                        wrapperCol={{
                            span: 10
                        }}
                        layout={'vertical'}>
                        <Form.Item name={'email'}
                            rules={[
                                {
                                    type: 'email',
                                    message: translate('register_form_error_email_not_valid')
                                },
                                {
                                    required: true,
                                    message: translate('register_form_error_email_required')
                                }
                            ]}
                        >
                            <Input type={'email'} placeholder={formEmailLabel}/>
                        </Form.Item>
                        <Form.Item>
                            <Button type="primary" htmlType="submit" disabled={buttonDisabled} className="verify-button" loading={loading}>
                                {translate('email_verify_resend_button')}</Button>
                        </Form.Item>
                    </Form>
                </div>

            </div>
        </>
    );
}