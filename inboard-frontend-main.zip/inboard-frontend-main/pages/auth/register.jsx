import { Typography, Button, Form, Input, Row, Col, Result } from 'antd';
import PasswordStrengthBar from 'react-password-strength-bar';
import React from 'react';
import translate from 'i18n/translate';
import { POST } from 'utils';
import { useIntl } from 'react-intl';
import Link from 'next/link';
const { Title } = Typography;

export default function Register() {
    const intl = useIntl();
    const [password, setPassword] = React.useState('');
    const [loading, setLoading] = React.useState(false);
    const [isRegistered, setIsRegistered] = React.useState(false);
    const [showForm, setShowForm] = React.useState(true);
    const [isValidPassword, setIsValidPassword] = React.useState(false);
    const registrationSuccess = intl.formatMessage({id: 'register_success_title'});
    const registrationSuccessDescription = intl.formatMessage({ id: 'register_success_description' });
    async function onFinish (values) {
        const { email, password, passwordConfirmation, firstName, lastName } = values;
        if (!isValidPassword) {
            return;
        }
        setLoading(true);
        if (typeof window !== 'undefined') {

            const registrationResults = await POST({
                endpoint: '/api/applicant/user/register/',
                data: { email, password, firstName, lastName },
                resolveWithFullResponse: true
            });

            if (registrationResults.status === 201) {
                setShowForm(false);
                setIsRegistered(true);
                return;
            }
            setLoading(false);
            return;
        }
    }

    return (
        <>
            <div className="auth-view">
                {
                    showForm?
                        <div className="container">
                            <Title style={{ textAlign: 'center' }} level={3}>
                                {translate('register_title')}
                            </Title>
                        </div>:null
                }
                <div className="container">
                    {
                        showForm ?<Form
                            name="register"
                            labelCol={{ span: 6 }}
                            wrapperCol={{ span: 16 }}
                            initialValues={{ remember: true }}
                            onFinish={onFinish}>
                            <Form.Item
                                name="firstName"
                                label={translate('register_form_label_first_name')}
                                rules={[
                                    {
                                        required: true,
                                        message: translate('register_form_error_first_name_required')
                                    }
                                ]}>
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="lastName"
                                label={translate('register_form_label_last_name')}
                                rules={[
                                    {
                                        required: true,
                                        message: translate('register_form_error_last_name_required')
                                    }
                                ]}>
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="email"
                                label={translate('register_form_label_email')}
                                rules={[
                                    {
                                        type: 'email',
                                        message: translate('register_form_error_email_not_valid')
                                    },
                                    {
                                        required: true,
                                        message: translate('register_form_error_email_required')
                                    }
                                ]}>
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="password"
                                label={translate('register_form_label_password')}
                                rules={[
                                    {
                                        required: true,
                                        message: translate('register_form_error_password_required')
                                    }
                                ]}>
                                <Input
                                    type="password"
                                    onChange={(event) => {
                                        const value = event && event.target && event.target.value;
                                        if (value) {
                                            setPassword(value);
                                        }
                                    }}/>
                            </Form.Item>
                            <Form.Item label={'فعالية كلمة المرور'} name="password">
                                <PasswordStrengthBar
                                    password={password}
                                    minLength={8}
                                    scoreWords={['ضعيفة جدا', 'ضعيفة', 'متوسطة', 'قوية', 'قوية جدا']}
                                    shortScoreWord={'كلمة المرور يجب أن تكون اكثر من 8 ارقام وحروف'}
                                    onChangeScore={score => {
                                        if (score) {
                                            setIsValidPassword(true);
                                            return;
                                        }
                                        setIsValidPassword(false);
                                    }}
                                />
                                <Row style={{ color: 'rgb(137, 135, 146)' }} gutter={[0, 8]}>
                                    <Col flex="100%">يجب أن تحتوي على حروف</Col>
                                    <Col flex="100%">يجب أن تحتوي على أرقام</Col>
                                </Row>
                            </Form.Item>
                            <Form.Item wrapperCol={{ span: 24 }} style={{ textAlign: 'center' }}>
                                <Button type="primary" htmlType="submit" loading={loading} disabled={!isValidPassword}>
                                    {translate('register_form_submit')}
                                </Button>
                            </Form.Item>
                        </Form> : null}
                    {
                        isRegistered ?
                            <div className="auth-view-success">
                                <Result
                                    status="success"
                                    title={registrationSuccess}
                                    subTitle={registrationSuccessDescription}
                                    extra={
                                        <Link passHref href="/">
                                            <Button type='primary link'>{translate('go_to_home')}</Button>
                                        </Link>}
                                />

                            </div>
                            :null
                    }
                </div>
            </div>
        </>
    );
}