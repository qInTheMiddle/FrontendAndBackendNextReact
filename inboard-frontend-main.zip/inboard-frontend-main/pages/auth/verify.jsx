import { Button, Form, Input, Result, Typography, message } from 'antd';
import React from 'react';
import translate from 'i18n/translate';
import { POST } from 'utils';
import { useIntl } from 'react-intl';
import Link from 'next/link';
const { Title } = Typography;
export default function VerifyEmail({ success, messageResponse }) {
    const intl = useIntl();
    const [formLoading, setFormLoading] = React.useState(false);
    const [formButtonDisabled, setFormButtonDisabled] = React.useState(false);
    const emailVerifySuccess = intl.formatMessage({ id: 'email_verify_success' });
    const emailVerifySuccessDescription = intl.formatMessage({ id: 'email_verify_success_description' });
    const emailVerifyFailed = intl.formatMessage({ id: 'email_verify_failed' });
    const emailVerifyResent = intl.formatMessage({ id: 'email_verify_resent' });

    const unknownError = intl.formatMessage({ id: 'unknown_error' });
    const formEmailLabel = intl.formatMessage({ id: 'form_label_email' });

    async function onFinish (values) {
        setFormLoading(true);
        setFormButtonDisabled(true);
        const { email } = values;
        const response = await POST({
            endpoint: '/api/applicant/user/resend-email-verification/',
            data: { email },
            resolveWithFullResponse: true
        });
        const { status } = response || {};
        setFormLoading(false);

        if (status === 204) {
            message.success(emailVerifyResent);
            setFormButtonDisabled(true);
            return;
        }
        setFormButtonDisabled(false);
        message.error(unknownError);

    }


    return (
        <>
            <div className="payment-verify-view">
                <div className="container">

                    {success ?

                        <Result
                            status="success"
                            title={emailVerifySuccess}
                            subTitle={emailVerifySuccessDescription}
                            extra={<Link passHref href="/"><Button type='primary link'>{translate('home')}</Button></Link>}
                        />:
                        <Result
                            status="error"
                            title={emailVerifyFailed}
                            subTitle={translate(messageResponse)}

                        >
                            <div className="desc">
                                <Title level={3}>
                                    {translate('email_verify_resend')}
                                </Title>
                                <Form onFinish={onFinish}
                                    labelCol={{
                                        span: 4
                                    }}
                                    wrapperCol={{
                                        span: 10
                                    }}
                                    layout={'vertical'}
                                >
                                    <Form.Item name={'email'}
                                        rules={[
                                            {
                                                type: 'email',
                                                message: translate('register_form_error_email_not_valid')
                                            },
                                            {
                                                required: true,
                                                message: translate('register_form_error_email_required')
                                            }
                                        ]}
                                    >
                                        <Input type={'email'} placeholder={formEmailLabel}/>
                                    </Form.Item>
                                    <Form.Item>
                                        <Button type="primary" htmlType="submit" disabled={formButtonDisabled} className="verify-button" loading={formLoading}>
                                            {translate('email_verify_resend_button')}</Button>
                                    </Form.Item>
                                </Form>
                            </div>
                        </Result>
                    }
                </div>

            </div>
        </>
    );
}

export async function getServerSideProps(context) {
    const { query } = context;
    const { emailVerificationToken } = query;
    const response = await POST({
        endpoint: '/api/applicant/user/verify-email/',
        data: { emailVerificationToken },
        resolveWithFullResponse: true
    });
    const messageResponse = 'unknown_error';

    if (!response) {
        return {
            props: {
                success: false,
                messageResponse
            }
        };
    }

    const { status } = response;

    if (status !== 204) {
        return {
            props: {
                success: false,
                messageResponse
            }
        };
    }

    return {
        props: {
            success: true,
            messageResponse: 'email_verify_success_description'
        }
    };
}