import { Button, Form, Input, Typography, message, Row, Col } from 'antd';
import React, { useEffect } from 'react';
import translate from 'i18n/translate';
import { POST } from 'utils';
import { useIntl } from 'react-intl';
import PasswordStrengthBar from 'react-password-strength-bar';
import { useRouter } from 'next/router';

const { Title } = Typography;

export default function SetNewPassword() {
    const intl = useIntl();
    const router = useRouter();
    const [loading, setLoading] = React.useState(false);
    const [password, setPassword] = React.useState('');
    const [buttonDisabled, setButtonDisabled] = React.useState(false);
    const [resetPasswordToken, setVerificationToken] = React.useState('');
    const passwordResetDone = intl.formatMessage({ id: 'email_verify_resent' });
    const unknownError = intl.formatMessage({ id: 'unknown_error' });

    const {query} = router;
    useEffect(() => {
        if (query.resetPasswordToken) {
            setVerificationToken(query.resetPasswordToken);
        }
    }, [query.resetPasswordToken]);

    async function onFinish (values) {

        setLoading(true);
        setButtonDisabled(true);

        const { password } = values;
        const response = await POST({
            endpoint: '/api/applicant/user/change-forgot-password/',
            data: { password, resetPasswordToken },
            resolveWithFullResponse: true
        });
        setLoading(false);
        const { status } = response || {};

        if (status === 204) {
            setButtonDisabled(true);
            message.success(passwordResetDone);
            return;
        }
        setButtonDisabled(false);

        message.error(unknownError);

    }


    return (
        <>
            <div className="auth-view">
                <div className="container">

                    <Title level={3}>
                        {translate('request_password_reset')}
                    </Title>
                    <Form onFinish={onFinish}
                        labelCol={{
                            span: 4
                        }}
                        wrapperCol={{
                            span: 10
                        }}
                        layout={'vertical'}
                    >
                        <Form.Item
                            name="password"
                            label={translate('register_form_label_password')}
                            rules={[
                                {
                                    required: true,
                                    message: translate('register_form_error_password_required')
                                }
                            ]}>
                            <Input
                                type="password"
                                onChange={(event) => {
                                    const value = event && event.target && event.target.value;
                                    if (value) {
                                        setPassword(value);
                                    }
                                }}/>
                        </Form.Item>
                        <Form.Item
                            name="confirm"
                            label={translate('register_form_label_password_confirm')}
                            dependencies={['password']}
                            hasFeedback
                            rules={[
                                {
                                    required: true,
                                    message: translate('register_form_error_password_confirm_required')
                                },
                                ({ getFieldValue }) => ({
                                    validator(_, value) {
                                        if (!value || getFieldValue('password') === value) {
                                            return Promise.resolve();
                                        }
                                        return Promise.reject(translate('register_form_error_password_not_matched'));
                                    }
                                })
                            ]}>
                            <Input type={'password'} />
                        </Form.Item>
                        <Form.Item label={'فعالية كلمة المرور'} name="password">
                            <>
                                <PasswordStrengthBar
                                    password={password}
                                    minLength={8}
                                    scoreWords={['ضعيفة جدا', 'ضعيفة', 'متوسطة', 'قوية', 'قوية جدا']}
                                    shortScoreWord={'كلمة المرور يجب أن تكون اكثر من 8 ارقام وحروف'}
                                />
                                <Row style={{ color: 'rgb(137, 135, 146)'}} gutter={[0, 8]}>
                                    <Col flex="100%">يجب أن تحتوي على حروف</Col>
                                    <Col flex="100%">يجب أن تحتوي على أرقام</Col>
                                </Row>
                            </>
                        </Form.Item>
                        <Form.Item>
                            <Button type="primary" htmlType="submit" disabled={buttonDisabled} className="verify-button" loading={loading}>
                                {translate('request_password_reset_save_new_password')}</Button>
                        </Form.Item>
                    </Form>
                </div>

            </div>
        </>
    );
}

export function getServerSideProps(context) {
    const { query } = context;
    const { resetPasswordToken } = query;

    if (resetPasswordToken) {
        return {
            props: {
                resetPasswordToken
            }
        };
    }

    return {
        redirect: {
            permanent: false,
            destination: '/'
        }
    };

}