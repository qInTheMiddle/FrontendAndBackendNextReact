import React from 'react';
import translate from 'i18n/translate';
import {Col, Row, Typography} from 'antd';
import ReactPlayer from 'react-player';

const {Paragraph, Title} = Typography;
function About () {
    return (
        <div className='about-view'>
            <div className="container">
                <Title level={1}>{translate('about_us_title')}</Title>
                <Row gutter={[16, 16]}>
                    <Col xs={{ span: 24 }} lg={{ span: 12 }}>
                        <Paragraph>
                            {translate('about_us_paragraph_1')}
                        </Paragraph>
                        <Paragraph>
                            {translate('about_us_paragraph_2')}
                        </Paragraph>
                    </Col>
                </Row>
                <Row gutter={[16, 16]}>
                    <Col xs={{span: 24}} lg={{span: 12}}>
                        <ReactPlayer
                            width='100%'
                            height='100%'
                            url='https://www.youtube.com/watch?v=XN91GAtRHl4'
                        />
                    </Col>
                </Row>
            </div>
        </div>
    );
}

export default About;