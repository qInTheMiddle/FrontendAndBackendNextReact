/* eslint-disable unicorn/consistent-function-scoping */
require('../styles/variables.less');
import { ConfigProvider, Drawer, Layout, Spin } from 'antd';
import '../styles/globals.css';
import '../styles/inboard.scss';
const { Content } = Layout;
import { useEffect, useState } from 'react';
import Head from 'next/head';
import Router, { useRouter } from 'next/router';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { store, persistor } from 'store';
import { I18nProvider } from 'i18n';
import { setLocale, setLocaleDirection } from '../store/slices/i18n.slice';
import { loadUserProfileDetails } from 'store/slices/auth.slice';
import { Header, Footer, Sider } from 'components';
import { useIsMobile, RudderInitialize } from 'utils';
import SEO from '../next-seo.config';
import { DefaultSeo } from 'next-seo';
const INTERCOM_APP_ID = 'hcjzdmlh';
import { IntercomProvider, useIntercom } from 'react-use-intercom';

function App ({ Component, pageProps }) {
    const dispatch = useDispatch();
    const router = useRouter();
    const locale = useSelector((state) => state.i18nSlice.locale);
    const {direction: localeDirection} = useSelector((state) => state.i18nSlice);
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const defaultlocalization = useSelector(
        (state) => state.i18nSlice.defaultlocalization
    );
    const [intercomProps, setIntercomProps] = useState({
        userId: AuthSlice.user._id, // User ID
        userHash: AuthSlice.user?.userHMAC,
        name: AuthSlice.user.firstName,
        email: AuthSlice.user.email
    });
    const mobileCheckingHook = useIsMobile();
    const [isMobile, updateIsMobileDevice] = useState(true);
    const [, setMounted] = useState(false);
    const [isOpen, setToggleStatus] = useState(false);

    function closeDrawer() {
        setToggleStatus(false);
    }
    function openDrawer() {
        setToggleStatus(true);
    }

    useEffect(() => {
        RudderInitialize();
    }, []);

    useEffect(() => {
        if (process.browser) {
            setMounted(true);
        }
    }, []);

    useEffect(() => {
        updateIsMobileDevice(mobileCheckingHook);
        setToggleStatus(false);
    }, [mobileCheckingHook]);

    useEffect(() => {
        if (process.browser) {
            const routerPath = router.asPath || '';
            const routerPathAsArray = routerPath.split('/')||[];
            const [pathName] = routerPathAsArray.filter((routerPathString) => !!routerPathString);
            const class_list = [];
            document.body.classList.forEach((cls) => {
                if (!cls.includes('-page')) {
                    class_list.push(cls);
                }
            });
            document.body.classList = class_list;

            if (pathName) {
                document.body.classList.add(`${pathName}-page`);
            }
        }
    }, [router]);
    useEffect(() => {
        if (process.browser) {
            function handleRouteChange () {
                window.rudderanalytics.page();
            }

            router.events.on('routeChangeComplete', handleRouteChange);
            return () => {
                router.events.off('routeChangeComplete', handleRouteChange);
            };
        }
    }, [router.events]);
    useEffect(() => {
        if (process.browser) {
            function appHeight () {
                const doc = document.documentElement;
                doc.style.setProperty(
                    '--viewport-height',
                    `${window.innerHeight}px`
                );
            }
            appHeight();
            window.addEventListener('resize', appHeight);
            return () => {
                window.removeEventListener('resize', appHeight);
            };
        }
    }, []);


    useEffect(() => {
        if (process.browser) {
            function setLang (lang) {
                dispatch(setLocale(lang));

                document.querySelector('html').setAttribute('lang', lang);
                const adjustLocaleDirection = lang === 'ar' ? 'rtl' : 'ltr';
                setLocaleDirection(adjustLocaleDirection);

                localStorage.setItem('inboardUserLocalization', lang);
                localStorage.setItem('inboardUserLocaleDirection', adjustLocaleDirection);
            }
            const userLocalization = localStorage.getItem('inboardUserLocalization');
            setLang(userLocalization || defaultlocalization);
        }

    }, [defaultlocalization, dispatch]);

    // Load user's data on app load and if the user is logged in
    useEffect(() => {
        if (AuthSlice.isLoggedIn) {

            dispatch(loadUserProfileDetails(AuthSlice.token));

            if (AuthSlice.user?._id) {
                setIntercomProps({
                    userId: AuthSlice.user._id, // User ID
                    userHash: AuthSlice.user?.userHMAC,
                    name: AuthSlice.user.firstName,
                    email: AuthSlice.user.email
                });
            }
        }
    }, [AuthSlice.isLoggedIn, AuthSlice.token, dispatch]);

    return (
        <I18nProvider locale={locale}>
            <ConfigProvider direction={localeDirection}>
                <IntercomProvider autoBoot appId={INTERCOM_APP_ID} autoBootProps={intercomProps} >
                    <Drawer className='inboard-sider' placement="left" visible={isOpen} onClose={closeDrawer}>
                        <Sider closeDrawer={closeDrawer}/>
                    </Drawer>
                    <Layout>
                        <Header openDrawer={openDrawer} closeDrawer={closeDrawer} isOpen={isOpen}/>
                        <Content className='site-layout-content'>
                            <Component {...pageProps} />
                        </Content>


                        <Footer/>
                    </Layout>

                    <div className="loading">
                        <Spin size="large" />
                    </div>
                </IntercomProvider>
            </ConfigProvider>
        </I18nProvider>
    );
}

export default function AppWrapper({ Component, pageProps }) {
    return (
        <>
            <DefaultSeo {...SEO} />
            <Head>
                <meta charSet="utf-8" />
                <link rel="icon" href="/favicons/favicon.ico?version=1.0" />
                <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png"/>
                <link rel="icon" type="image/png" sizes="32x32" href="/favicons/favicon-32x32.png"/>
                <link rel="icon" type="image/png" sizes="16x16" href="/favicons/favicon-16x16.png"/>
                <link rel="manifest" href="/site.webmanifest"/>
                <meta name="msapplication-TileColor" content="#da532c"/>
                <meta name="theme-color" content="#ffffff"/>
            </Head>

            <Provider store={store}>
                <PersistGate loading={null} persistor={persistor}>
                    {() => <App Component={Component} pageProps={pageProps} />}
                </PersistGate>
            </Provider>
        </>
    );
}

if (process.browser) {
    Router.onRouteChangeStart = () => {
        window.document.querySelector('.loading').style.display =
            'flex';
    };

    Router.onRouteChangeComplete = () => {
        window.document.querySelector('.loading').style.display =
            'none';
    };

    Router.onRouteChangeError = () => {
        window.document.querySelector('.loading').style.display =
            'none';
    };
}