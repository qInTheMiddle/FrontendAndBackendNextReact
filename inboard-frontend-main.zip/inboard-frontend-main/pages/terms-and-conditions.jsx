import React from 'react';
import {Typography} from 'antd';
import translate from 'i18n/translate';
const {Paragraph, Title} = Typography;
function TermsAndConditions () {

    return (
        <div className="terms-and-conditions-view">
            <div className="container">
                <Title level={2}>{translate('terms_and_conditions_title')}</Title>
                <Paragraph>
                    <ul>
                        <li>
                            {translate('terms_and_conditions_2')}
                        </li>
                        <li>
                            {translate('terms_and_conditions_3')}
                        </li>
                        <li>
                            {translate('terms_and_conditions_4')}
                        </li>
                        <li>
                            {translate('terms_and_conditions_5')}
                        </li>
                        <li>
                            {translate('terms_and_conditions_6')}
                        </li>
                        <li>
                            {translate('terms_and_conditions_7')}
                        </li>
                    </ul>
                </Paragraph>
            </div>
        </div>
    );
}


export default TermsAndConditions;