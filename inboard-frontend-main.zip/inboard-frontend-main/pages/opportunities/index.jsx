import { Breadcrumb, Button, Col, Pagination, Row, Typography } from 'antd';
import React, { useEffect } from 'react';
import { GET } from 'utils';
import translate from 'i18n/translate';
import { Opportunity } from 'components';
import Link from 'next/link';
import categories from 'i18n/enums/categories';
import { useIntl } from 'react-intl';
import { useRouter } from 'next/router';
import { NextSeo } from 'next-seo';
const { Title } = Typography;

export default function OpportonitiesList(props) {
    const { opportunities =[], currentPage, opportunitiesCount, pagesCount } = props;
    const {locale, formatMessage} = useIntl();
    const [currentCategory, setCurrentCategory] = React.useState('all');
    const [categoryLabel, setCategoryLabel] = React.useState('categories');
    const router = useRouter();
    const { query } = router;

    function changePage (page) {

        const { query } = router;
        router.push({
            pathname: '/opportunities',
            query: {
                ...query,
                page
            }
        });
    }

    useEffect(() => {
        setCurrentCategory(query.category);
    }, [query.category]);

    useEffect(() => {

        if (currentCategory === 'all' || !currentCategory || typeof currentCategory !== 'string') {
            const categoryLabel = formatMessage({id: 'categories'});
            setCategoryLabel(categoryLabel);
            return;
        }
        if (currentCategory) {
            const categoryLabel = formatMessage({id: currentCategory});
            setCategoryLabel(categoryLabel);
        }
    }, [currentCategory]);


    return (
        <>
            <NextSeo
                title={categoryLabel}
            />
            <Breadcrumb style={{ margin: '10px auto', width: '100%', maxWidth: '1024px', padding: '10px' }}>
                <Breadcrumb.Item><Link href={'/'}><a>{translate('home')}</a></Link></Breadcrumb.Item>
                <Breadcrumb.Item>{translate('opportunities')}</Breadcrumb.Item>
            </Breadcrumb>
            <div className="opportonities-view">
                <div className="container">
                    <div className="categories">
                        <Title level={3}>{translate('categories')}</Title>
                        <div className="categories-list">
                            <Link
                                href={'/opportunities'}
                                key={'all'}
                                passHref

                            >
                                <Button
                                    className="category"
                                    type="dashed link">
                                    {translate('all')}
                                </Button>
                            </Link>
                            {Object.entries(categories).map((category, index) => {
                                return (
                                    <Link
                                        href={`/opportunities?category=${category[0]}&page=1`}
                                        key={index}
                                        passHref

                                    >
                                        <Button
                                            className="category"
                                            type="dashed link">
                                            {category[1][locale]}
                                        </Button>
                                    </Link>
                                );
                            })}
                        </div>
                    </div>

                    {opportunities?.length ?
                        <Row gutter={[32, 32]} className="opportunities-list">
                            { opportunities.map((opportunity, index) =>
                                <Col xs={{ span: 24 }} lg={{ span: 12 }} key={index}>
                                    {' '}
                                    <Opportunity opportunity={opportunity} />
                                </Col>

                            )}
                        </Row>
                        :
                        <Row>
                            <div className="no-opportunities">{translate('no_opportunities')}</div>

                        </Row>
                    }
                    {
                        pagesCount > 1 ?
                            <Pagination
                                defaultCurrent={currentPage}
                                pageSize={6}
                                total={opportunitiesCount}
                                className="pagination"
                                showLessItems={true}
                                onChange={changePage} /> :
                            null
                    }
                </div>
            </div>
        </>
    );
}
export async function getServerSideProps(context) {
    const { query = {} } = context;
    const { page= 1, category } = query;
    const params = { category };

    const response = await GET({
        endpoint: `/api/applicant/opportunities/list/sortBy--availableSeats/6/${page}/`,
        options: { params }
    });

    if (!response) {
        return {
            props: { opportunities: [] }
        };
    }

    const { opportunities, opportunitiesCount, pagesCount } = response;

    return {
        props: {
            opportunities,
            opportunitiesCount,
            pagesCount,
            currentPage: page
        }

    };
}