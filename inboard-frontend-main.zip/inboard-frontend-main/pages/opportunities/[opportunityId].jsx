import React, { useEffect } from 'react';
import { GET, ExtractLocaleField } from 'utils';
import { NextSeo } from 'next-seo';
import { useRouter } from 'next/router';
import { Breadcrumb, Button, Descriptions, message, PageHeader, Tag, Typography } from 'antd';
import { useSelector } from 'react-redux';
import translate from 'i18n/translate';
import hoursToAmPm from 'i18n/hours.to.am.pm';
import Link from 'next/link';
import Script from 'next/script';
import { useIntl } from 'react-intl';
const { Title, Paragraph } = Typography;
export default function SingleOpportunity({ opportunity, host }) {
    const router = useRouter();
    const { route } = router;
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const {locale, formatMessage} = useIntl();
    const [isLoggedIn, setIsLoggedIn] = React.useState(false);
    const [opportunityTitle, setOpportunityTitle] = React.useState('');
    const [seatsLocalization, setSeatsLocalization] = React.useState('');
    const opportunityDurationInMonths = Math.floor(opportunity.opportunityDurationInDays / 30) || 1;
    const scriptRefArr = [];
    useEffect(() => {
        if (route) {
            const scripts = ['https://checkout.tabby.ai/tabby-promo.js'];

            for (const item of scripts) {
                loadScript(item);
            }
        }

        return () => {
            if (scriptRefArr.length > 0) {
                removeScript();
            }

        };

    }, [route]);

    function loadScript (src) {
        const script = document.createElement('script');
        script.src = src;
        script.async = true;
        if (!scriptRefArr.find(item => item.url === src)) {
            document.body.appendChild(script);
            scriptRefArr.push({ url: src, script });
        }
    }

    function removeScript () {
        scriptRefArr.forEach(item => {
            if (document.body.contains(item.script)) {
                document.body.removeChild(item.script);
            }
        });

    }
    useEffect(() => {
        if (opportunity.title) {
            const localizedTitle = ExtractLocaleField(opportunity?.title, locale);
            setOpportunityTitle(localizedTitle);
        }
    }, [opportunity.title]);

    useEffect(() => {
        if (AuthSlice.token) {
            setIsLoggedIn(true);
        }
    }, [AuthSlice.token]);

    function startApplication () {
        if (opportunity.availableSeats <= 0) {
            const opportunitySeatsFull = formatMessage({ id: 'opportunity_seats_full' });
            message.error(opportunitySeatsFull);
            return;
        }
        if (isLoggedIn) {
            router.push({
                pathname: '/applications/new-application/',
                query: { id: opportunity._id, title: ExtractLocaleField(opportunity.title, locale) }
            });
            return;
        }

        const pleaseLogin = formatMessage({ id: 'please_login' });
        message.warning(pleaseLogin, {
            position: 'top-right'
        });

        router.push({ pathname: '/auth/login' });
    }

    useEffect(() => {
        if (!opportunity.availableSeats) {
            const label = translate('zero_seats');
            setSeatsLocalization(label);
            return;
        }

        if (opportunity.availableSeats === 1) {
            const label = translate('one_seat', {seats: opportunity.availableSeats});
            setSeatsLocalization(label);
        }
        if (opportunity.availableSeats === 2) {
            const label = translate('two_seats', {seats: opportunity.availableSeats});
            setSeatsLocalization(label);
        }
        if (opportunity.availableSeats >= 3 && opportunity.availableSeats <= 10) {
            const label = translate('three_to_ten_seats', {seats: opportunity.availableSeats});
            setSeatsLocalization(label);
        }
        if (opportunity.availableSeats >= 11) {
            const label = translate('eleven_to_twenty_seats', {seats: opportunity.availableSeats});
            setSeatsLocalization(label);
        }
    }, [opportunity.availableSeats]);


    return (
        <>
            <NextSeo
                title={opportunityTitle}
                openGraph={{
                    url: host + router.asPath,
                    title: opportunityTitle,
                    images: [
                        {
                            url: opportunity?.companyId.logo,
                            width: 150,
                            height: 150,
                            alt: opportunityTitle
                        }
                    ]
                }}
            />
            <>
                <Breadcrumb style={{ margin: '10px auto', width: '100%', maxWidth: '1024px', padding: '10px' }}>
                    <Breadcrumb.Item>
                        <Link href={'/'}>
                            <a>{translate('home')}</a>
                        </Link>
                    </Breadcrumb.Item>
                    <Breadcrumb.Item>
                        <Link href={`/opportunities?category=${opportunity.category}`}>
                            <a>{translate(opportunity.category)}</a>
                        </Link>
                    </Breadcrumb.Item>
                    <Breadcrumb.Item>{opportunityTitle}</Breadcrumb.Item>
                </Breadcrumb>
                <div className="opportonities-view">
                    <PageHeader
                        className="opportunity-header"
                        ghost={false}
                        onBack={() => window.history.back()}
                        title={opportunityTitle}
                        avatar={{ src: opportunity.companyId.logo }}
                        subTitle={translate(opportunity.category)}
                        tags={opportunity.availableSeats <= 2 ?
                            <Tag color="red">{seatsLocalization}</Tag>
                            : <Tag color="green">{seatsLocalization}</Tag> }
                        extra={[
                            <Button key="apply_button" type="primary" onClick={startApplication}>
                                {translate('opportunity_enroll_now')}
                            </Button>
                        ]}>
                        <Descriptions column={{ xxl: 3, xl: 3, lg: 3, md: 2, sm: 1, xs: 1 }} bordered>
                            {opportunity.locationLink && opportunity.locationCity &&
                            <Descriptions.Item label={translate('opportunity_label_location')}>
                                <Link href={opportunity.locationLink} target={'_blank'}>
                                    <a>{translate(opportunity.locationCity.toLowerCase())}</a>
                                </Link>
                            </Descriptions.Item>
                            }
                            <Descriptions.Item label={translate('opportunity_label_career_level')}>
                                {translate(opportunity.careerLevel)}
                            </Descriptions.Item>
                            <Descriptions.Item label={translate('opportunity_label_duration')}>
                                {opportunityDurationInMonths} {translate('opportunity_label_months')}
                            </Descriptions.Item>
                            <Descriptions.Item label={translate('opportunity_label_application_fees')}>
                                {opportunity.applicationFees} {translate('currency')}
                            </Descriptions.Item>
                            <Descriptions.Item label={translate('opportunity_label_work_hours')}>
                                {opportunity.workHours ?
                                    <div style={{direction: 'ltr'}}>
                                        {hoursToAmPm(opportunity.workHours.from)} - {hoursToAmPm(opportunity.workHours.to)}
                                    </div>
                                    : translate('opportunity_label_no_work_hours')}
                            </Descriptions.Item>
                        </Descriptions>
                    </PageHeader>
                    <div className="opportunity-block">
                        <div id="TabbyPromo"></div>
                        <Script
                            src="https://checkout.tabby.ai/tabby-promo.js"
                            strategy='lazyOnload'
                            onLoad={() => {
                                // eslint-disable-next-line no-undef
                                new TabbyPromo({
                                    selector: '#TabbyPromo',
                                    currency: 'SAR',
                                    price: opportunity.applicationFees,
                                    installmentsCount: 4,
                                    lang: 'ar',
                                    source: 'service',
                                    publicKey: 'pk_f81185a2-57c5-422d-a56e-6a41bcf064db',
                                    merchantCode: 'inboardsau'
                                });
                                console.log('tabby loaded');
                            }}
                            onError={() => console.log('tabby error')}
                            onReady={() => {
                            // eslint-disable-next-line no-undef
                                new TabbyPromo({
                                    selector: '#TabbyPromo',
                                    currency: 'SAR',
                                    price: opportunity.applicationFees,
                                    installmentsCount: 4,
                                    lang: 'ar',
                                    source: 'service',
                                    publicKey: 'pk_f81185a2-57c5-422d-a56e-6a41bcf064db',
                                    merchantCode: 'inboardsau'
                                });
                                console.log('tabby loaded');
                            }
                            }
                        />
                    </div>
                    {opportunity?.description && <div className="opportunity-block">
                        <Title level={3}>{translate('opportunity_label_description')}</Title>
                        <div dangerouslySetInnerHTML={{__html: ExtractLocaleField(opportunity?.description, locale)}}></div>
                    </div>}
                    {opportunity?.companyId?.description && <div className="opportunity-block">
                        <Title level={3}>{translate('opportunity_label_company_information')}</Title>
                        <Paragraph>
                            <div dangerouslySetInnerHTML={{__html: ExtractLocaleField(opportunity?.companyId?.description, locale)}}></div>
                        </Paragraph>
                    </div>}
                </div>
            </>
        </>
    );
}

export async function getServerSideProps(context) {
    const response = await GET({
        endpoint: `/api/applicant/opportunities/${context.params.opportunityId}/view/`,
        resolveWithFullResponse: true
    });

    if (response.status !== 200) {
        return {
            notFound: true
        };
    }

    const { opportunity = {
        workHours: { from: '8', to: '16' }, title: {arabic: '', english: ''}, locationCity: ''
    } } = response.data;

    return {
        props: {
            host: `https://${context.req.headers.host}`,
            query: context.query,
            opportunity
        }
    };
}