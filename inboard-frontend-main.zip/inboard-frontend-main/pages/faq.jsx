import { Collapse, Typography } from 'antd';
import translate from 'i18n/translate';
import React from 'react';
const { Panel } = Collapse;
const { Title, Paragraph } = Typography;
function FAQ () {
    return (
        <div className='faq-view'>
            <div className="container">
                <Title level={2}>{translate('faq_title')}</Title>
                <Collapse defaultActiveKey={['faq_1']}>
                    <Panel header={translate('faq_header_1')} key={'faq_1'}>
                        <Paragraph>
                            {translate('faq_answer_1')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_2')} key={'faq_2'}>
                        <Paragraph>
                            {translate('faq_answer_2')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_3')} key={'faq_3'}>
                        <Paragraph>
                            {translate('faq_answer_3')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_4')} key={'faq_4'}>
                        <Paragraph>
                            {translate('faq_answer_4')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_5')} key={'faq_5'}>
                        <Paragraph>
                            {translate('faq_answer_5')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_6')} key={'faq_6'}>
                        <Paragraph>
                            {translate('faq_answer_6')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_7')} key={'faq_7'}>
                        <Paragraph>
                            {translate('faq_answer_7')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_8')} key={'faq_8'}>
                        <Paragraph>
                            {translate('faq_answer_8')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_9')} key={'faq_9'}>
                        <Paragraph>
                            {translate('faq_answer_9')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_10')} key={'faq_10'}>
                        <Paragraph>
                            {translate('faq_answer_10')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_11')} key={'faq_11'}>
                        <Paragraph>
                            {translate('faq_answer_11')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_12')} key={'faq_12'}>
                        <Paragraph>
                            {translate('faq_answer_12')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_13')} key={'faq_13'}>
                        <Paragraph>
                            {translate('faq_answer_13')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_14')} key={'faq_14'}>
                        <Paragraph>
                            {translate('faq_answer_14')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_15')} key={'faq_15'}>
                        <Paragraph>
                            {translate('faq_answer_15')}
                        </Paragraph>
                    </Panel>
                    <Panel header={translate('faq_header_16')} key={'faq_16'}>
                        <Paragraph>
                            {translate('faq_answer_16')}
                        </Paragraph>
                    </Panel>
                </Collapse>
            </div>
        </div>
    );
}

export default FAQ;