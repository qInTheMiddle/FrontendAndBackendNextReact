import { message } from 'antd';
import { parseString } from 'xml2js';
import { POST, GET } from './http';


async function GetS3Object(file, directory, uploadingStatus) {

    const formData = new FormData();


    let token = '';
    if (typeof window !== 'undefined') {
        token = localStorage.getItem('inboardUserToken');
    }
    if (!token) {
        uploadingStatus('error');
        return false;
    }

    uploadingStatus('loading');

    const s3ObjectResult = await GET({
        endpoint: '/api/upload/',
        token,
        options: {
            params: {
                filename: file.name,
                directory
            }
        },
        headers: {
            'Access-Control-Allow-Origin': '*',
            Accept: 'application/json'
        },
        resolveWithFullResponse: true
    });

    if (s3ObjectResult.status !== 200) {
        uploadingStatus('error');
        return false;
    }

    const s3Object = s3ObjectResult?.data;
    Object.keys(s3Object.params).forEach(key => {
        if (key !== 'content-type') {
            const value = s3Object.params[key];
            formData.append(key, value);
        }
    });

    await formData.append('file', file);



    return await postS3Object({ formData, responseData: s3Object, uploadingStatus });
}

async function postS3Object({ formData, responseData, uploadingStatus}) {

    const response = await POST({
        endpoint: responseData.endpoint_url,
        data: formData,
        resolveWithFullResponse: true
    });

    const parsedJSON = await new Promise((resolve, reject) => parseString(response.data, (err, result) => {
        if (err) {
            reject(err);
        } else {
            resolve(result);
        }
    }));
    const { PostResponse = {} } = parsedJSON;
    uploadingStatus('success');
    return PostResponse;

}

export default async function UploadFile(file, directory, uploadingStatus) {
    uploadingStatus('started');
    if (!file) {
        uploadingStatus('error');
        return;
    }

    return await GetS3Object(file, directory, uploadingStatus);
}