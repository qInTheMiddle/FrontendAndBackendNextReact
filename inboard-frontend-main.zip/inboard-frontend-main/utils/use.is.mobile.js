/* eslint-disable react-hooks/rules-of-hooks */
import { isMobile, deviceType, isIPad13 } from 'react-device-detect';
import { useState, useEffect } from 'react';

export default function UseIsMobile() {

    if (typeof window === 'undefined') {
        return false;
    }
    const [is_mobile, set_is_mobile] = useState(false);
    const [view_width, set_view_width] = useState(window?.innerWidth);

    useEffect(() => {
        set_is_mobile(isMobile && deviceType !== 'tablet' && !isIPad13);
    }, [isMobile]);

    useEffect(() => {
        if (!process.browser) {
            return;
        }

        function handleWindowResize () {
            set_view_width(window.innerWidth);
        }

        window.addEventListener('resize', handleWindowResize);
        return () => window.removeEventListener('resize', handleWindowResize);
    }, []);

    return is_mobile || view_width <= 765;
}