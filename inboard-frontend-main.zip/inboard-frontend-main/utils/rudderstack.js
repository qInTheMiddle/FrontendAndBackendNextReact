export default async function rudderInitialize() {
    if (!window || typeof window === 'undefined') {
        return;
    }
    window.rudderanalytics = await import('rudder-sdk-js');

    window.rudderanalytics.load('2CetKan9avPSZMuZVUOCzCuEAz4', 'https://inboardamqad.dataplane.rudderstack.com', {
        integrations: { All: true } // load call options
    });

    window.rudderanalytics.ready(() => {
    });
}