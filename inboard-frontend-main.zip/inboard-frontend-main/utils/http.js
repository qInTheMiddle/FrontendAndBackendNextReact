import axios from 'axios';
import { store } from 'store';
import { resetSlicesAndLogout } from 'store/slices/auth.slice';
import isValidURL from './is.valid.url';
import { message } from 'antd';

const BASE_URL = process.env.NEXT_PUBLIC_BASE_API_URL;

async function httpRequest (httpRequestPayload) {
    const { method, endpoint, data, token, headers, options, resolveWithFullResponse } = httpRequestPayload;

    const authorizationHeader = token ? { Authorization: `Bearer ${token}` }: {};

    let contentTypeHeader = {};
    if (process.browser && data instanceof FormData) {
        contentTypeHeader = {
            'Content-Type': 'multipart/form-data'
        };
    } else {
        contentTypeHeader = {
            'Content-Type': 'application/json'
        };
    }

    try {
        const res = await axios({
            method,
            headers: {
                ...authorizationHeader,
                ...headers,
                ...contentTypeHeader,
                platform: 'web'
            },
            url: isValidURL(endpoint) ? endpoint : `${BASE_URL}${endpoint}`,
            data,
            validateStatus: () => true,
            ...options
        }).then((res) => {
            if (resolveWithFullResponse) {
                return res;
            }
            return res.data || res;
        });

        return res;
    } catch (err) {

        if (process.browser) {
            if (
                err?.response?.status === 401 ||
                err?.response?.status_code === 401
            ) {
                store.dispatch(resetSlicesAndLogout());
            }
            if (
                err?.response?.status === 400 ||
                err?.response?.status === 422
            ) {
                const errors = Object.keys(err?.response?.data?.errors || {});

                if (errors.length) {
                    errors.forEach((key) => {
                        const single_err = err?.response?.data?.errors[key][0];
                        message.warn(single_err, {
                            position: 'top-right'
                        });
                    });
                } else {
                    message.warn(err?.message);
                }
            }
        }

        return err;
    }
}

export function GET (httpRequestPayload) {
    return httpRequest({ ...httpRequestPayload, method: 'get' });
}
export function POST (httpRequestPayload) {
    return httpRequest({ ...httpRequestPayload, method: 'post' });
}
export function PATCH (httpRequestPayload) {
    return httpRequest({ ...httpRequestPayload, method: 'patch' });
}
export function PUT (httpRequestPayload) {
    return httpRequest({ ...httpRequestPayload, method: 'put' });
}
export function DELETE (httpRequestPayload) {
    return httpRequest({ ...httpRequestPayload, method: 'delete' });
}