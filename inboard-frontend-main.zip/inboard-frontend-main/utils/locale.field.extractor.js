function localeFieldExtractor(object, appLocale = 'ar') {

    const locale = appLocale === 'ar' ? 'arabic' : 'english';
    const localeField = object && object[locale];

    if (localeField) {
        return localeField;
    }

    return object[Object.keys(object)[0]] ||'no-value';
}
export default localeFieldExtractor;