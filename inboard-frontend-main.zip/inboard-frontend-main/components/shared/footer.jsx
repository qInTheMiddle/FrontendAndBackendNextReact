/* eslint-disable max-len */
import { Layout } from 'antd';
import React from 'react';
const { Footer: AntFooter } = Layout;
import translate from 'i18n/translate';
import Image from 'next/image';
import Link from 'next/link';
export default function Footer() {
    return (
        <>
            <AntFooter className='inboard-footer'>
                <div>
                    <Image layout='fixed' src='/images/inboard-gray-logo@2x.png' alt='inboard' width={'88px'} height={'44px'} />
                </div>
                <div className='footer-side'>
                    <Link href='/terms-and-conditions'>
                        <a>{translate('footer_terms_and_conditions')}</a>
                    </Link>
                    <Link href='https://twitter.com/inboardsa' target={'_blank'}>
                        <a>
                            <Image layout='fixed' src='/images/twitter.png' alt='inboard' width={'24px'} height={'24px'} />
                            <span>{translate('footer_twitter')}</span>
                        </a>
                    </Link>
                    <Link href='https://instagram.com/inboard.sa' target={'_blank'}>
                        <a>
                            <Image layout='fixed' src='/images/instagram.png' alt='inboard' width={'24px'} height={'24px'} />
                            <span>{translate('footer_instagram')}</span>
                        </a>
                    </Link>
                    <Link href='https://wa.me/966558578827' target={'_blank'}>
                        <a>
                            <Image layout='fixed' src='/images/whatsapp.png' alt='inboard' width={'24px'} height={'24px'} />
                            <span>{translate('footer_whatsapp')}</span>
                        </a>
                    </Link>
                    <div>
                        {translate('footer_copyrights')}
                    </div>
                </div>
            </AntFooter>
        </>
    );
}