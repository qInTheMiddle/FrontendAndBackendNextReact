/* eslint-disable max-len */
import { Card, Image, Tag, Typography } from 'antd';
import React from 'react';
import translate from 'i18n/translate';
import Link from 'next/link';
import { ExtractLocaleField } from 'utils';
import { useSelector } from 'react-redux';
import hoursToAmPm from 'i18n/hours.to.am.pm';

const { Text } = Typography;
export default function Opportunity({ opportunity, isHomePage }) {
    const locale = useSelector((state) => state.i18nSlice.locale);
    const {
        title ={arabic: '', english: ''},
        companyId ={logo: ''},
        locationCity,
        locationLink,
        careerLevel,
        opportunityDurationInDays = 30,
        workHours,
        availableSeats,
        category,
        slug,
        applicationFees
    } = opportunity;

    const opportunityDurationInMonths = Math.floor(opportunityDurationInDays / 30) || 1;

    let loading = false;

    if (!opportunity) {
        loading = true;
    }

    return (
        <>
            <Card
                headStyle={{ fontSize: '1.5rem', fontWeight: 'bold' }}
                title={
                    <>
                        <div>{ExtractLocaleField(title, locale)}</div>
                        { availableSeats < 2 ?
                            <Tag color={availableSeats ? 'red' :'grey'} style={{ marginTop: '0.5rem' }}>
                                {
                                    availableSeats === 0 ?
                                        translate('zero_seats')
                                        :
                                        translate('one_seat', {seats: opportunity.availableSeats})
                                }
                            </Tag>
                            : null
                        }
                    </>
                }
                loading={loading}
                style={{ borderRadius: '16px', border: 'none' }}
                extra={
                    <>
                        <Text style={{margin: 'auto 5px'}}>{translate(category)}</Text>
                        <Image layout='fixed' src={companyId.logo} alt="example" width={'40px'} height={'40px'} preview={false} />
                    </>
                }
                className={availableSeats?'opportunity-card':'opportunity-card opportunity-card-full'}
            >

                <ul className='information-list'>
                    {locationLink? <li className='location'>
                        <Link href={locationLink} target={'_blank'}>
                            <a>{translate(locationCity.toLowerCase())}</a>
                        </Link>
                    </li>:null}
                    <li className='careerLevel'>
                        {translate(careerLevel)}
                    </li>
                    <li className='duration'>
                        {opportunityDurationInMonths} {translate('opportunity_label_months')}
                    </li>
                    {workHours ?
                        <li className='workhours'>
                            {hoursToAmPm(workHours.from)} - {hoursToAmPm(workHours.to)}
                        </li> : null
                    }
                    <li className='fees'>
                        {translate('opportunity_label_application_fees')} {applicationFees} {translate('currency')}
                    </li>
                </ul>

                <div className={isHomePage ? 'card-footer' :'card-footer card-footer-inside'}>
                    <Link href={`/opportunities/?category=${category}` } >
                        <a className='explore-more'>{translate('opportunity_explore_more')}</a>
                    </Link>
                    <Link href={`/opportunities/${slug}`} >
                        <a className='enroll-now'> {translate('opportunity_enroll_now')}</a>
                    </Link>
                </div>

            </Card>
        </>
    );
}