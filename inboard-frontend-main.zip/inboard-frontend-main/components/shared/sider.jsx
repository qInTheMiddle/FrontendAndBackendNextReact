/* eslint-disable max-len */
import { Button, Menu } from 'antd';
import React, { useEffect } from 'react';
import translate from 'i18n/translate';
import Link from 'next/link';

import { useDispatch, useSelector } from 'react-redux';
import { resetSlicesAndLogout } from 'store/slices/auth.slice';
import { setLocale, setLocaleDirection } from 'store/slices/i18n.slice';
export default function InboardSider({closeDrawer}) {
    const [isLoggedIn, setIsLoggedIn] = React.useState(false);
    const dispatch = useDispatch();
    const AuthSlice = useSelector((state) => state.AuthSlice);

    function logout () {
        dispatch(resetSlicesAndLogout());
        setIsLoggedIn(false);
    }
    useEffect(() => {
        if (AuthSlice.isLoggedIn) {
            setIsLoggedIn(true);
        }
    }, [AuthSlice.isLoggedIn]);

    function setLang () {
        if (process.browser) {
            const userLocalization = localStorage.getItem('inboardUserLocalization');
            const language = userLocalization === 'ar' ? 'en' : 'ar';
            const localeDirection = language === 'ar' ? 'rtl' : 'ltr';
            document.querySelector('html').setAttribute('lang', language);
            dispatch(setLocale(language));
            dispatch(setLocaleDirection(localeDirection));
            localStorage.setItem('inboardUserLocalization', language);
            localStorage.setItem('inboardUserLocaleDirection', localeDirection);
        }
    }
    const siderItems = [
        {
            key: 'side_home',
            label: (
                <Link href={'/'}><a>{translate('home')}</a></Link>
            )
        },
        {
            key: 'sider_1',
            label: (
                <Link href={'/#secondFold'}><a>{translate('headers_seekers')}</a></Link>
            )

        },
        {
            key: 'sider_2',
            label: (
                <Link href={'/#ourPartners'}><a>{translate('headers_partners')}</a></Link>
            )

        },
        {
            key: 'sider_3',
            label: (
                <Link href={'/faq'}><a>{translate('headers_faq')}</a></Link>
            )
        },
        {
            key: 'sider_4',
            label: (
                <Link href={'/about'}><a>{translate('headers_aboutus')}</a></Link>
            )
        },
        {
            key: 'sider_5',
            label: (
                <Link href="/opportunities">
                    <a>{translate('work_with_experts')}</a>
                </Link>
            )
        },
        (!isLoggedIn ?
            {
                key: 'sider_login',
                label: (
                    <Link href="/auth/login">
                        <a>{translate('login_title')}</a>
                    </Link>
                )
            } : {
                key: 'sider_profile',
                label: (
                    <Link href="/profile">
                        <a> {translate('my_profle')}</a>
                    </Link>
                )
            }, {
            key: 'sider_logout',
            label: (
                <Button onClick={logout} danger>
                    {translate('logout')}
                </Button>
            )
        }),
        {
            key: 'sider_switch_locale',
            label: (
                <Button type="secondary" className="inboard-header-button-language" onClick={setLang}>
                    {translate('switch_language')}
                </Button>
            )
        }
    ];





    return (



        <Menu
            theme="light"
            mode="vertical"
            items={siderItems} className="menu-side"
            onClick={closeDrawer} />




    );
}