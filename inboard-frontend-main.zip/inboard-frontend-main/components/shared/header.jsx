/* eslint-disable max-len */
import { Menu, Layout, Button } from 'antd';
import React, { useEffect } from 'react';
const { Header } = Layout;
import translate from 'i18n/translate';
import { useDispatch, useSelector } from 'react-redux';
import { setLocale, setLocaleDirection } from 'store/slices/i18n.slice';
import Link from 'next/link';
import Image from 'next/image';
import { resetSlicesAndLogout } from 'store/slices/auth.slice';
import { MenuFoldOutlined, MenuUnfoldOutlined } from '@ant-design/icons';
import { useIsMobile } from 'utils';
export default function InboardHeader({openDrawer, closeDrawer, isOpen}) {
    const dispatch = useDispatch();
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const [isLoggedIn, setIsLoggedIn] = React.useState(false);
    const [collapsed, setCollapsed] = React.useState(isOpen);
    const mobileCheck = useIsMobile();
    const [isMobile, setIsMobile] = React.useState(true);

    useEffect(() => {
        setIsMobile(mobileCheck);
    }, [mobileCheck]);

    useEffect(() => {
        if (AuthSlice.isLoggedIn) {
            setIsLoggedIn(true);
        }
    }, [AuthSlice.isLoggedIn]);


    function logout () {
        dispatch(resetSlicesAndLogout());
        setIsLoggedIn(false);
    }
    const headerItems = [
        {
            key: 'home',
            label: (
                <Link href={'/'}><a>{translate('home')}</a></Link>
            )
        },
        {
            key: 1,
            label: (
                <Link href={'/#secondFold'}><a>{translate('headers_seekers')}</a></Link>
            )

        },
        {
            key: 2,
            label: (
                <Link href={'/#ourPartners'}><a>{translate('headers_partners')}</a></Link>
            )

        },
        {
            key: 3,
            label: (
                <Link href={'/faq'}><a>{translate('headers_faq')}</a></Link>
            )
        },
        {
            key: 4,
            label: (
                <Link href={'/about'}><a>{translate('headers_aboutus')}</a></Link>
            )
        }
    ];

    function setLang () {
        if (process.browser) {
            const userLocalization = localStorage.getItem('inboardUserLocalization');
            const language = userLocalization === 'ar' ? 'en' : 'ar';
            const localeDirection = language === 'ar' ? 'rtl' : 'ltr';
            document.querySelector('html').setAttribute('lang', language);
            dispatch(setLocale(language));
            dispatch(setLocaleDirection(localeDirection));
            localStorage.setItem('inboardUserLocalization', language);
            localStorage.setItem('inboardUserLocaleDirection', localeDirection);
        }
    }

    return (
        <>
            <Header className="header" >
                <Link href="/">
                    <a className="logo">
                        <Image src="/images/header-logo@2x.png" alt="inboard" width={'88px'} height={'44px'} layout='fixed' />
                    </a>
                </Link>

                {
                    isMobile ?

                        <Button type='ghost'
                            icon={collapsed ? <MenuUnfoldOutlined/> : <MenuFoldOutlined/>}
                            onClick={openDrawer}/>

                        :
                        <>
                            <Menu
                                theme="light"
                                mode="horizontal"
                                items={headerItems} className="menu" />


                            <Button href="/opportunities" type="primary link" className="header-button inboard-header-button">
                                {translate('work_with_experts')}
                            </Button>
                            {!isLoggedIn ? (
                                <Link href="/auth/login" passHref>
                                    <Button type="link" className='header-button' >
                                        {translate('login_title')}
                                    </Button>
                                </Link>
                            ) : (<>
                                <Link passHref href="/profile">
                                    <Button type="link" className='header-button' >
                                        {translate('my_profle')}
                                    </Button>
                                </Link>
                                <Button className='header-button' onClick={logout} danger>
                                    {translate('logout')}
                                </Button>
                            </>
                            )}
                            <Button type="secondary" className="header-button inboard-header-button-language" onClick={setLang}>
                                {translate('switch_language')}
                            </Button>

                        </>
                }
            </Header>
        </>
    );
}