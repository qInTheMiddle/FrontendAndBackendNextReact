/* eslint-disable max-len */
import React, { useEffect, useState, useCallback } from 'react';
import translate from 'i18n/translate';
import _debounce from 'lodash/debounce';
import { InboxOutlined } from '@ant-design/icons';
import { Typography, Upload, message, Input, Form, Select, Alert, Button } from 'antd';
import { UploadFile, POST, GET, PUT } from 'utils';
import moment from 'moment';
import { useSelector } from 'react-redux';
import { useIntl } from 'react-intl';
import workExperienceDuration from 'i18n/enums/work.experience.duration';
const { Title, Paragraph } = Typography;
const { Dragger } = Upload;
const { TextArea } = Input;
const formDataDefault = {
    attachment: '',
    yearsOfExperience: '0',
    opportunityId: '',
    cvUrl: '',
    expectedGoals: ''
};
export default function StepThree({ opportunityId, setApplicationId, next, prev }) {
    const [fileList, setFileList] = useState([]);
    const [isFormFieldsUpdated, setIsFormFieldsUpdated] = useState(false);
    const [formData, setFormData] = useState(formDataDefault);
    const [fileUrl, setFileUrl] = useState('');
    const [applicationId, setApplicationIdInner] = useState('');
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const [form] = Form.useForm();
    const [currentUploadingStatus, setUploadingStatus] = useState({
        status: 'not-started', alertType: 'info', message: 'form_progress_uploading_uploading'
    });
    const intl = useIntl();
    const { formatMessage, locale } = intl;

    const [isLoading, setIsLoading] = useState(false);
    const [isDisabled, setIsDisabled] = useState(false);
    const [isError, setIsError] = useState(false);
    const [isValid, setIsValid] = useState(false);


    function handleStatus(value) {
        switch (value) {
        case 'completed':
            setIsLoading(false);
            setIsDisabled(false);
            setIsError(false);
            break;
        case 'loading':
            setIsLoading(true);
            setIsDisabled(true);
            break;
        case 'untouched':
            setIsLoading(false);
            setIsDisabled(true);
            break;

        default:
            setIsLoading(false);
            setIsDisabled(false);
            setIsError(false);
            break;
        }
    }
    function handleEvent(changedFields, allFields) {
        setIsValid(false);
        const areAllFieldsValid = allFields.every((field) => !field.errors?.length && field.value);
        if (areAllFieldsValid) {
            setIsValid(true);
            setIsDisabled(false);
            handleStatus('complete');
        }
    }

    async function verifyAndSaveFunction() {
        if (!isValid) {
            return;
        }
        handleStatus('loading');

        const formData = { ...form.getFieldsValue() };
        if (formData.cvUrl) {
            delete formData.attachment;
        }




        const data = {
            application: {
                ...formData,
                opportunityId
            }
        };

        const applicationFieldUpdate = await POST({
            endpoint: '/api/applicant/applications/add/',
            token: AuthSlice.token, data,
            resolveWithFullResponse: true
        });

        if (applicationFieldUpdate.status !== 201) {
            handleStatus('untouched');
            return;

        }

        const successfulSubmission = formatMessage({ id: 'form_data_saved_successfully' });
        setApplicationId(applicationFieldUpdate.data?.applicationId);
        setApplicationIdInner(applicationFieldUpdate.data?.applicationId);
        handleStatus('completed');
        message.success(successfulSubmission);
        next();
        return;


    }


    useEffect(() => {
        async function getData() {
            handleStatus('loading');
            const applicationData = await GET({ endpoint: `/api/applicant/applications/${opportunityId}/view/`, token: AuthSlice.token });
            if (!applicationData?.application) {
                handleStatus('untouched');
                return;
            }

            setFormData(applicationData.application);
            form.setFieldsValue({...applicationData.application, attachment: 'file'});
            const areAllFieldsValid = form.getFieldsError().every((field) => !field.errors?.length);
            if (areAllFieldsValid) {
                setIsValid(true);
            }
            const currentFormData = form.getFieldsValue();
            delete currentFormData.attachment;

            const formDataFilled = Object.values(currentFormData).every((value) => value);
            if (formDataFilled) {
                setIsFormFieldsUpdated(true);
                handleStatus('completed');
                return;
            }
            handleStatus('untouched');

        }

        if (!isFormFieldsUpdated) {
            getData();
        }

    }, []);

    function uploadingStatus(status) {
        switch (status) {
        case 'error':
            setUploadingStatus({status: 'not-started', alertType: 'error', message: 'error_uploading_file'});
            break;
        case 'started':
            setUploadingStatus({status: 'started', alertType: 'warning', message: 'form_progress_uploading_started'});
            break;
        case 'uploading':
            setUploadingStatus({status: 'uploading', alertType: 'warning', message: 'form_progress_uploading_uploading'});
            break;
        case 'success':
            setUploadingStatus({status: 'success', alertType: 'success', message: 'form_progress_uploading_success'});
            break;
        }


    }

    const draggerProprties = {
        name: 'file',
        multiple: false,
        fileList,
        onChange(info) {
            let fileList = [...info.fileList];
            fileList = fileList.slice(-1);
            setFileList(fileList);
        },
        async beforeUpload(file) {
            const allowedDocumentsMimeTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            const isDocument = allowedDocumentsMimeTypes.includes(file.type);
            if (!isDocument) {
                message.error(formatMessage({ id: 'form_error_cv_worng_format' }));
                return;
            }
            const isLessThan5MB = file.size / 1024 / 1024 < 5;
            if (!isLessThan5MB) {
                message.error(formatMessage({ id: 'form_error_cv_size' }));
                return;
            }
            const { _id: userId='unknown-user-id' } = AuthSlice.user;
            const date = moment().format('YYYY-MM-DD');

            const directory = `${userId}/cvs/${date}`;

            const uploadedFileResults = await UploadFile(file, directory, uploadingStatus);

            if (!uploadedFileResults || !uploadedFileResults?.Location?.length) {
                message.error(formatMessage({ id: 'unknown_error' }));
                return;
            }
            const decodedFileUrl = decodeURIComponent(uploadedFileResults.Location[0]);
            setFileUrl(decodedFileUrl);
            form.setFieldsValue({ cvUrl: decodedFileUrl });

            const currentFormData = form.getFieldsValue();
            delete currentFormData.attachment;

            const formDataFilled = Object.values(currentFormData).every((value) => value);
            if (formDataFilled) {
                setIsValid(true);
                handleStatus('completed');
                return;
            }
            return false;

        }
    };


    return (
        <>
            <div className="steps-content">
                <Title level={3}>{translate('step_professinal_information')}</Title>
                <Paragraph>
                    {translate('step_professinal_information_description')}
                </Paragraph>
                <div className='form'>
                    <Form
                        form={form}
                        labelCol={{
                            span: 4
                        }}
                        wrapperCol={{
                            span: 10
                        }}
                        layout="vertical"
                        initialValues={{
                            yearsOfExperience: formData.yearsOfExperience,
                            expectedGoals: formData.expectedGoals,
                            cvUrl: formData.cvUrl,
                            attachment: 'file'
                        }}
                        onFieldsChange={handleEvent}
                    >
                        <Form.Item labelWrap label={translate('form_label_duration')} name={'yearsOfExperience'} rules={[
                            {
                                required: true,
                                message: translate('form_error_expectation_required')
                            }
                        ]} >
                            <Select>
                                {
                                    Object.entries(workExperienceDuration).map((item, index) => (
                                        <Select.Option value={item[0]} key={index}>{item[1][locale]}</Select.Option>
                                    ))
                                }
                            </Select>
                        </Form.Item>

                        <Form.Item labelWrap label={translate('form_label_why_applying')} name={'expectedGoals'} rules={[
                            {
                                required: true,
                                message: translate('form_error_expectation_required')
                            }
                        ]} >
                            <TextArea showCount maxLength={500} rows={4} />
                        </Form.Item>
                        <Form.Item hidden={true}
                            name={'cvUrl'}
                            rules={[{ required: true }]}

                        >
                            <Input value={fileUrl}/>
                        </Form.Item>
                        <Form.Item label={translate('form_label_upload_cv')} name={'attachment'} >
                            <>       <Dragger {...draggerProprties}>
                                <p className="ant-upload-drag-icon">
                                    <InboxOutlined />
                                </p>
                                <p className="ant-upload-text">
                                    {translate('form_label_upload_drop_zone')}
                                </p>
                                <p className="ant-upload-hint">
                                    {translate('form_label_upload_drop_zone_hint')}
                                </p>
                            </Dragger>
                            {
                                currentUploadingStatus.status !== 'not-started' ?
                                    <Alert
                                        showIcon
                                        message={translate(currentUploadingStatus.message)}
                                        type={currentUploadingStatus.alertType}
                                    />
                                    :null
                            }
                            </>
                        </Form.Item>
                    </Form>
                </div>
            </div>
            <div className="steps-action">
                <Button style={{ margin: '0 8px' }} onClick={() => prev()}>
                    {translate('previous')}
                </Button>
                <Button
                    type="primary"
                    onClick={() => verifyAndSaveFunction()}
                    loading={isLoading}
                    disabled={isDisabled || !isValid}>
                    {translate('next')}
                </Button>
            </div>
        </>
    );
}