/* eslint-disable max-len */
import { Typography, message, DatePicker, Form, Input, Select, Button } from 'antd';
import React, { useEffect, useState } from 'react';
import { GET, PUT } from 'utils';
import translate from 'i18n/translate';
import { useSelector } from 'react-redux';
import { useIntl } from 'react-intl';
import countries from 'i18n/enums/countries';
import moment from 'moment';
const { Title, Paragraph } = Typography;
const formDataDefault = {
    firstName: '',
    lastName: '',
    mobile: 0,
    dateOfBirth: '',
    gender: '',
    nationality: ''
};

export default function StepTwo({ next, prev }) {
    const AuthSlice = useSelector((state) => state.AuthSlice);
    const [formData, setFormData] = useState(formDataDefault);
    const [form] = Form.useForm();
    const intl = useIntl();
    const { locale } = intl;
    const [isFormFieldsUpdated, setIsFormFieldsUpdated] = useState(false);

    const [isLoading, setIsLoading] = useState(false);
    const [isDisabled, setIsDisabled] = useState(false);
    const [isError, setIsError] = useState(false);
    const [isValid, setIsValid] = useState(false);
    function handleEvent(changedFields, allFields) {
        setIsValid(false);
        const areAllFieldsValid = allFields.every((field) => !field.errors?.length && field.value);
        if (areAllFieldsValid) {
            setIsValid(true);
            setIsDisabled(false);
        }
    }
    function submitForm() {
        handleStatus('loading');
        const formData = { ...form.getFieldsValue() };
        const data = {
            ...formData,
            mobileCC: '966',
            mobile: Number(formData.mobile)
        };
        updateUserProfile(data);
    }

    function handleStatus(value) {
        switch (value) {
        case 'completed':
            setIsLoading(false);
            setIsDisabled(false);
            setIsError(false);
            break;
        case 'loading':
            setIsLoading(true);
            setIsDisabled(true);
            break;
        case 'untouched':
            setIsLoading(false);
            setIsDisabled(true);
            break;

        default:
            setIsLoading(false);
            setIsDisabled(false);
            setIsError(false);
            break;
        }
    }

    async function updateUserProfile(data) {
        const userProfileUpdate = await PUT({
            endpoint: '/api/applicant/user/update/',
            token: AuthSlice.token,
            data,
            resolveWithFullResponse: true
        });
        if (userProfileUpdate.status === 204) {
            const successfulSubmission = intl.formatMessage({ id: 'form_data_saved_successfully' });
            message.success(successfulSubmission);
            handleStatus('completed');
            next();
            return;
        }
        handleStatus('untouched');
    }

    const dateOfBirthPlaceHolder = intl.formatMessage({ id: 'form_date_picker_placeholder' });

    useEffect(() => {
        async function getData() {
            handleStatus('loading');
            const userProfile = await GET({ endpoint: '/api/applicant/user/view/', token: AuthSlice.token });
            if (!userProfile?.user) {
                handleStatus('untouched');
                return;
            }

            if (userProfile.user.dateOfBirth) {
                userProfile.user.dateOfBirth = moment(userProfile.user.dateOfBirth);
            }
            setFormData(userProfile.user);
            form.setFieldsValue(userProfile.user);
            form.validateFields();
            const areAllFieldsValid = form.getFieldsError().every((field) => !field.errors?.length);
            if (areAllFieldsValid) {
                setIsValid(true);
            }

            const formDataFilled = Object.values(form.getFieldsValue()).every((value) => value);
            if (formDataFilled) {
                setIsFormFieldsUpdated(true);
                handleStatus('completed');
                return;
            }
            handleStatus('untouched');
        }
        if (!isFormFieldsUpdated) {
            getData();
        }
    }, []);

    return (
        <>
            <div className="steps-content">
                <Title level={3}>{translate('step_personal_information')}</Title>
                <Paragraph>{translate('step_personal_information_description')}</Paragraph>
                <Form
                    labelCol={{
                        span: 4
                    }}
                    wrapperCol={{
                        span: 10
                    }}
                    form={form}
                    layout="vertical"
                    initialValues={{
                        firstName: formData.firstName,
                        lastName: formData.lastName,
                        mobile: formData.mobile,
                        dateOfBirth: formData.dateOfBirth ? moment(formData.dateOfBirth) : '',
                        gender: formData.gender,
                        nationality: formData.nationality
                    }}
                    onFieldsChange={handleEvent}>
                    <Form.Item
                        name={'firstName'}
                        label={translate('form_label_first_name')}
                        rules={[
                            {
                                required: true,
                                message: translate('form_error_first_name_required')
                            }
                        ]}>
                        <Input />
                    </Form.Item>
                    <Form.Item
                        name={'lastName'}
                        label={translate('form_label_last_name')}
                        rules={[
                            {
                                required: true,
                                message: translate('form_error_last_name_required')
                            }
                        ]}>
                        <Input />
                    </Form.Item>
                    <Form.Item
                        name={'gender'}
                        label={translate('form_label_gender')}
                        rules={[
                            {
                                required: true,
                                message: translate('form_error_gender_required')
                            }
                        ]}>
                        <Select>
                            <Select.Option value="male" key={'male'}>{translate('male')}</Select.Option>
                            <Select.Option value="female" key={'female'}>{translate('female')}</Select.Option>
                        </Select>
                    </Form.Item>
                    <Form.Item
                        name={'nationality'}
                        label={translate('form_label_nationality')}
                        rules={[
                            {
                                required: true,
                                message: translate('form_error_nationality_required')
                            }
                        ]}>
                        <Select>
                            {Object.entries(countries).map((item, index) => (
                                <Select.Option value={item[0]} key={index}>
                                    {item[1][locale]}
                                </Select.Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item
                        name={'dateOfBirth'}
                        label={translate('form_label_date_of_birth')}
                        rules={[
                            {
                                required: true,
                                message: translate('form_error_date_of_birth_required')
                            }
                        ]}>
                        <DatePicker placeholder={dateOfBirthPlaceHolder} />
                    </Form.Item>

                    <Form.Item
                        name="mobile"
                        label={translate('form_label_mobile_number')}
                        rules={[
                            {
                                pattern: /^[\d]{0,9}$/,
                                message: translate('form_error_mobile_number_length')
                            },
                            {
                                required: true,
                                message: translate('form_error_mobile_number_invalid'),
                                len: 9,
                                min: 500_000_000,
                                max: 600_000_000
                            }
                        ]}>
                        <Input
                            className="ltr-force"
                            type={'number'}
                            maxLength={9}
                            min={500_000_000}
                            max={600_000_000}
                            addonAfter="+966"
                            placeholder="512345678"
                        />
                    </Form.Item>
                </Form>
            </div>
            <div className="steps-action">
                <Button style={{ margin: '0 8px' }} onClick={() => prev()}>
                    {translate('previous')}
                </Button>
                <Button
                    type="primary"
                    onClick={() => submitForm()}
                    loading={isLoading}
                    disabled={isDisabled || !isValid}>
                    {translate('next')}
                </Button>
            </div>
        </>
    );
}