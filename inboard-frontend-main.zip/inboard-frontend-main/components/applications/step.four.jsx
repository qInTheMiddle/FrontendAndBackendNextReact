/* eslint-disable max-len */
import { Spin, Typography } from 'antd';
const { Title, Paragraph } = Typography;
import React from 'react';
import translate from 'i18n/translate';
import Link from 'next/link';
import Image from 'next/image';

export default function StepFour({ tapPayment, tabbyPayment, applicationFees }) {

    return (
        <>
            <Title level={3}>{translate('step_payment')}</Title>
            <Paragraph>
                {translate('step_payment_description', {applicationFees})}
            </Paragraph>

            <Title level={4}>{translate('payment_methods')}</Title>
            <ul className='payment-methods'>
                <li>
                    {
                        tapPayment.paymentUrl ?
                            <Link href={tapPayment.paymentUrl} target={'_blank'} passHref>
                                <a>
                                    <Image layout='fixed' src="/images/tap.png" width={50} height={50} alt={translate('open_payment_page')} />
                                    <Typography.Text style={{padding: '5px'}} strong>{translate('open_payment_page')}</Typography.Text>
                                </a>
                            </Link> :
                            <div className='rejected-payment'>
                                <Image layout='fixed' src="/images/tap.png" width={50} height={50} alt={translate('pay_with_cards')} />
                                <Typography.Text style={{padding: '5px'}} strong>{translate('open_payment_page')} <Spin ></Spin></Typography.Text>
                            </div>
                    }
                </li>
                <li>
                    { tabbyPayment.installmentsWebUrl ?
                        <Link href={tabbyPayment.installmentsWebUrl} target={'_blank'} passHref>
                            <a>
                                <>
                                    <Image layout='fixed' src="/images/tabby-badge.png" width={50} height={20} alt={translate('open_payment_page_tabby')} />
                                    <Typography.Text style={{padding: '5px'}} strong>{translate('open_payment_page_tabby')}</Typography.Text>
                                </>
                                {tabbyPayment.rejectionReason ?

                                    <Paragraph>
                                        {translate('pay_with_tabby_rejection_description')}
                                    </Paragraph>:<></>
                                }
                            </a>
                        </Link> : <>
                            <div className='rejected-payment'>
                                <Image layout='fixed' src="/images/tabby-badge.png" width={50} height={20} alt={translate('open_payment_page_tabby')} />
                                <Typography.Text style={{padding: '5px'}} strong>
                                    {translate('open_payment_page_tabby')}
                                    {!tabbyPayment.rejectionReason && <Spin ></Spin>}
                                </Typography.Text>
                            </div>
                            {tabbyPayment.rejectionReason ?
                                <Paragraph style={{padding: '5px', color: 'red'}}>
                                    {translate('pay_with_tabby_rejection_description')}
                                </Paragraph>:<></>
                            }
                        </>
                    }
                </li>
            </ul>

        </>
    );
}