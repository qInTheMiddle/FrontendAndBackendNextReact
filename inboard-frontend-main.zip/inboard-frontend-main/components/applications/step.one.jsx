/* eslint-disable max-len */
import { Typography, Button } from 'antd';
import React from 'react';
import translate from 'i18n/translate';
const { Title, Paragraph } = Typography;


export default function StepOne({ next }) {
    return (
        <>
            <div className="steps-content">
                <Title level={3}>{translate('step_how_to_start')}</Title>
                <Paragraph>{translate('step_how_to_start_description')}</Paragraph>
            </div>
            <div className="steps-action">
                <Button type="primary" onClick={() => next()}>
                    {translate('next')}
                </Button>
            </div>
        </>
    );
}