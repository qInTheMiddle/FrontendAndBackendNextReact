import React from 'react';
import { Opportunity } from 'components';
import translate from 'i18n/translate';
import { Typography, Col, Row, Button } from 'antd';
import Link from 'next/link';

const { Title } = Typography;

export default function HomeOpportunities(props) {
    const { opportunities = [] } = props;

    return (
        <>
            <div className='opportunities-fold' id='secondFold'>
                <div className="container">

                    <Title level={3} style={{ marginBottom: '20px' }}>{translate('second_fold_title')}</Title>
                    <Row gutter={[32, 32]}>
                        {opportunities.map((opportunity, index) =>
                            <Col xs={{ span: 24 }} lg={{ span: 12 }} key={index}>
                                <Opportunity opportunity={opportunity} isHomePage={true}/>
                            </Col>
                        )}
                    </Row>

                    <Link href={'/opportunities'} passHref>
                        <Button type='primary link' size='large'>
                            {translate('second_fold_call')}
                        </Button>
                    </Link>
                </div>


            </div>
        </>
    );
}