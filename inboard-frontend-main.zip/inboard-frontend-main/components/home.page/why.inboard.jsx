import { Row, Col, Typography } from 'antd';
import React from 'react';
const { Title } = Typography;
import translate from 'i18n/translate';
export default function WhyInboard() {
    return (
        <>
            <div className='why-inboard-fold' id='thirdFold'>
                <div className="container">

                    <Title level={3} style={{ marginBottom: '20px' }}>{translate('third_fold_title')}</Title>
                    <Row gutter={[16, 16]}>
                        <Col xs={{ span: 24 }} lg={{ span: 8 }} >
                            <div className="why-card">
                                <div className="card-text">{translate('first_why_inboard')}</div>
                            </div>
                        </Col>
                        <Col xs={{ span: 24 }} lg={{ span: 8 }} >
                            <div className="why-card red">
                                <div className="card-text">{translate('second_why_inboard')}</div>
                            </div>
                        </Col>
                        <Col xs={{ span: 24 }} lg={{ span: 8 }} >
                            <div className="why-card">
                                <div className="card-text">{translate('third_why_inboard')}</div>
                            </div>
                        </Col>
                    </Row>
                </div>


            </div>
        </>
    );
}