import { Button, Image, Typography } from 'antd';
import React from 'react';
import translate from 'i18n/translate';
import Link from 'next/link';
const { Title, Paragraph } = Typography;

export default function FirstFold() {
    return (
        <>
            <div className='first-fold-container' id='firstFold'>
                <div className='first-fold-content'>
                    <div className='first-fold-side-text'>
                        <Title>{translate('first_fold_head')}</Title>
                        <Paragraph>
                            {translate('first_fold_p1')}<br/>
                            {translate('first_fold_p2')}<br/>
                        </Paragraph>
                        <Link href={'/opportunities'} passHref>
                            <Button type='primary link' size='large'>{translate('work_with_experts')}</Button>
                        </Link>
                    </div>
                </div>
                <div className="first-fold-logos" id="ourPartners">
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-01.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-02.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-03.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-04.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-05.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-06.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-07.png"
                    />
                    <Image
                        layout='fixed'
                        alt='here is an alt'
                        preview={false}
                        src="/images/providers-09.png"
                    />
                </div>
            </div>
        </>
    );
}