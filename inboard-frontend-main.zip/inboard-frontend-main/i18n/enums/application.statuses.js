const applicationStatus = {
    draft: { en: 'Draft', ar: 'مسودة' },
    'awaiting-application-payment': { en: 'Awaiting Application Payment', ar: 'بإنتظار دفع رسوم التقديم' },
    'paid-application-fees': { en: 'Processing', ar: 'جاري معالجة الطلب' },
    'awaiting-interview': { en: 'Awaiting Interview', ar: 'بانتظار المقابلة الشخصية' },
    'awaiting-opportunity-fees-payment': { en: 'Awaiting Opportunity Fees Payment', ar: 'بانتظار دفع رسوم الفرصة' },
    accepted: { en: 'Accepted', ar: 'مقبول' },
    rejected: { en: 'Rejected', ar: 'مرفوض' }
};
export default applicationStatus;