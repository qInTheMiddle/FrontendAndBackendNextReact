const countries = {
    'Saudi Arabia': { en: 'Saudi Arabia', ar: 'المملكة العربية السعودية' },
    'United Arab Emirates': { en: 'United Arab Emirates', ar: 'الامارات العربية المتحدة' },
    Bahrain: { en: 'Bahrain', ar: 'البحرين' },
    Kuwait: { en: 'Kuwait', ar: 'الكويت' },
    Algeria: { en: 'Algeria', ar: 'الجزائر' },
    Qatar: { en: 'Qatar', ar: 'قطر' },
    Oman: { en: 'Oman', ar: 'عمان' },
    Egypt: { en: 'Egypt', ar: 'مصر' },
    Jordan: { en: 'Jordan', ar: 'الاردن' },
    Palestine: { en: 'Palestine', ar: 'فلسطين' },
    'Syrian Arab Republic': { en: 'Syrian Arab Republic', ar: 'سوريا' },
    Lebanon: { en: 'Lebanon', ar: 'لبنان' },
    Yemen: { en: 'Yemen', ar: 'اليمن' },
    Morocco: { en: 'Morocco', ar: 'المغرب' },
    Iraq: { en: 'Iraq', ar: 'العراق' },
    Tunisia: { en: 'Tunisia', ar: 'تونس' }
};

export default countries;