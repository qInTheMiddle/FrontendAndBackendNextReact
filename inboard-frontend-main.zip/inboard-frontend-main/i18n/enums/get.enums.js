import careerLevels from './career.levels';
import educationLevels from './education.levels';
import countries from './countries';
import categories from './categories';
import applicationStatus from './application.statuses';
import cities from './cities';
import workExperienceDuration from './work.experience.duration';
export default function GetEnums (dataName, locale) {
    const enums = {
        careerLevels,
        educationLevels,
        countries,
        categories,
        applicationStatus,
        cities,
        workExperienceDuration
    };

    const entries = {};
    Object.entries(enums[dataName]).forEach((item) => {
        entries[item[0]]=item[1][locale];
    });

    return entries;

}