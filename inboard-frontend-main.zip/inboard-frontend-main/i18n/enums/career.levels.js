const careerLevels = {
    'entry-level': { en: 'Entry-Level', ar: 'مبتدئ' },
    'mid-level': { en: 'Mid-Level', ar: 'متوسط' },
    'senior-level': { en: 'Senior-Level', ar: 'متقدم' }
};
export default careerLevels;