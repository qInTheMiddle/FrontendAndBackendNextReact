const cities = {
    riyadh: { en: 'Riyadh', ar: 'الرياض' },
    jeddah: { en: 'Jeddah', ar: 'جدة' },
    mekkah: { en: 'Mekkah', ar: 'مكة المكرمة' },
    alkhobar: { en: 'AlKhobar', ar: 'الخبر' },
    dammam: { en: 'Dammam', ar: 'الدمام' },
    dahran: { en: 'Dahran', ar: 'الظهران' }
};

export default cities;