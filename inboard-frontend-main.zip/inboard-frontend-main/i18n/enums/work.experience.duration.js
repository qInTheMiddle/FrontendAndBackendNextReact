const workExperienceDuration = {
    0: {en: 'No prior experiece', ar: 'لم اعمل من قبل'},
    '0-1 years': {en: '0-1 years', ar: 'سنة أو أقل'},
    '1-3 years': {en: '1-3 years', ar: 'من 1 إلى 3 سنوات'},
    '3+ years': {en: '3+ years', ar: 'أكثر من 3 سنوات'}
};
export default workExperienceDuration;