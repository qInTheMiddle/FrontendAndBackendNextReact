const educationLevels = {
    'high-school': { en: 'High School', ar: 'الثانوية العامة' },
    'some-college-no-degree': { en: 'Some college no degree', ar: 'كلية بدون درجة اكاديمية' },
    'bachelors-degree': { en: 'Bachelor\'s Degree', ar: 'بكالوريوس' },
    'masters-degree': { en: 'Master\'s Degree', ar: 'ماستر' },
    phd: { en: 'PHD', ar: 'دكتوراه' }
};
export default educationLevels;