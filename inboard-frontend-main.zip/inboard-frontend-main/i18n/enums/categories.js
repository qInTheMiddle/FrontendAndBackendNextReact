const categories = {
    creative: { en: 'creative', ar: 'المجال الإبداعي' },
    'digital-marketing': { en: 'digital-marketing', ar: 'التسويق الرقمي' },
    production: { en: 'production', ar: 'الانتاج' },
    marketing: { en: 'marketing', ar: 'التسويق' },
    sales: { en: 'sales', ar: 'المبيعات' },
    advertising: { en: 'advertising', ar: 'الدعاية و الاعلان' },
    'project-management': { en: 'project-management', ar: 'إدارة المشاريع' },
    accounting: { en: 'accounting', ar: 'المحاسبة' },
    'event-management': { en: 'event-management', ar: 'إدارة الفعاليات' },
    'public-relations': { en: 'public-relations', ar: 'العلاقات العامة' },
    'human-resources': { en: 'human-resources', ar: 'الموارد البشرية' },
    'business-administration': { en: 'business-administration', ar: 'إدارة الأعمال' }
};

export default categories;