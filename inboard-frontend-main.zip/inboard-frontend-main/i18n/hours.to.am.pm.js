import moment from 'moment';
export default function hoursToAmPm (hours) {

    if (!hours) {
        return '';
    }

    const totalHoursInSeconds = moment.utc(hours*3600*1000);

    return moment(totalHoursInSeconds).format('hh:mmA');
}