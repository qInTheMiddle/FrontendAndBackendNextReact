export const LOCALES = {
    ENGLISH: 'en',
    ARABIC: 'ar',
};
