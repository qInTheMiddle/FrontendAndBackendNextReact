import en from './en';
import ar from './ar';

const messages = {
    ...en,
    ...ar
};

export default messages;