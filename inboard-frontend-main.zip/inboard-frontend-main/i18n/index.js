// DOCS : https://github.com/isaachinman/next-i18next
export { default as I18nProvider } from './provider';
export { LOCALES } from './locales';